From U8Public Require Import public_unit_goal public_unit_proof_auto public_unit_proof_manual.

Module VC_Correctness : VC_Correct.
  Include arrays_strategy_proof.
  Include public_unit_proof_auto.
  Include public_unit_proof_manual.
End VC_Correctness.
