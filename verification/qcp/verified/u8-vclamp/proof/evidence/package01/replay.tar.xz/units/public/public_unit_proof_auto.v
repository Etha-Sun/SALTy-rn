Require Import Coq.ZArith.ZArith.
Require Import Coq.Bool.Bool.
Require Import Coq.Strings.String.
Require Import Coq.Strings.Ascii.
Require Import Coq.Lists.List.
Require Import Coq.Classes.RelationClasses.
Require Import Coq.Classes.Morphisms.
Require Import Coq.micromega.Psatz.
Require Import Coq.Sorting.Permutation.
From AUXLib Require Import int_auto Axioms Feq Idents ListLib VMap.
Require Import SetsClass.SetsClass. Import SetsNotation.
From SimpleC.SL Require Import Mem SeparationLogic.
From U8Public Require Import public_unit_goal.
Require Import Logic.LogicGenerator.demo932.Interface.
Local Open Scope Z_scope.
Local Open Scope sets.
Local Open Scope string_scope.
Local Open Scope list.
Import Snaive_C_Rules64.
Require Import FullU8.U8Logic FullU8.U8KernelLogic.
Local Open Scope sac.

Lemma proof_of_equivalent_safety_wit_1 : equivalent_safety_wit_1.
Proof. Admitted. 

Lemma proof_of_equivalent_safety_wit_2 : equivalent_safety_wit_2.
Proof. Admitted. 

Lemma proof_of_equivalent_entail_wit_1 : equivalent_entail_wit_1.
Proof. Admitted. 

Lemma proof_of_equivalent_entail_wit_2 : equivalent_entail_wit_2.
Proof. Admitted. 

Lemma proof_of_equivalent_return_wit_1 : equivalent_return_wit_1.
Proof. Admitted. 

Lemma proof_of_equivalent_partial_solve_wit_1_pure : equivalent_partial_solve_wit_1_pure.
Proof. Admitted. 

Lemma proof_of_equivalent_partial_solve_wit_1 : equivalent_partial_solve_wit_1.
Proof. Admitted. 

Lemma proof_of_equivalent_partial_solve_wit_2_pure : equivalent_partial_solve_wit_2_pure.
Proof. Admitted. 

Lemma proof_of_equivalent_partial_solve_wit_2 : equivalent_partial_solve_wit_2.
Proof. Admitted. 

Lemma proof_of_equivalent_partial_solve_wit_3 : equivalent_partial_solve_wit_3.
Proof. Admitted. 

Lemma proof_of_equivalent_partial_solve_wit_4 : equivalent_partial_solve_wit_4.
Proof. Admitted. 

