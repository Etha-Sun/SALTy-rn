typedef unsigned long long size_t;
/*@ Import Coq Require Import FullU8.U8Logic */
/*@ Extern Coq (u8_vl:Z->Z) */
size_t __riscv_vsetvl_e8m8(size_t n)
/*@ Require 0<n && n<=18446744073709551615 Ensure __return==u8_vl(n) && 0<__return && __return<=128 && __return<=n */
{if(n<128)return n;return 128;}
