Goal False. Proof. exact I. Qed.
