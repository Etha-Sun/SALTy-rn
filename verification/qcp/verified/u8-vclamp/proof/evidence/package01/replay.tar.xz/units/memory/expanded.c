typedef unsigned long long size_t;
typedef unsigned char uint8_t;
typedef unsigned int uint32_t;
/*@ Import Coq Require Import FullU8.U8Logic FullU8.U8KernelLogic */
/*@ Extern Coq (UCharArray::full:Z->Z->list Z->Assertion) (UCharArray::seg:Z->Z->Z->list Z->Assertion)
 (UCharArray::undef_full:Z->Z->Assertion) (UCharArray::undef_seg:Z->Z->Z->Assertion)
 (u8_prefix_n:Z->Z) (u8_prefix_list:Z->Z->list Z->list Z) (u8_suffix_list:Z->Z->list Z->list Z)
 (u8_phase_all:Z->Z->Z->list Z->list Z) (u8_bound:Z->Z) */
/*@ include strategies "arrays.strategies" */
/*@ Import Coq Require Import FullU8.Packed32Model */
/*@ Extern Coq (pack4:Z->Z->Z->Z->Z) (lane_load:list Z->Z->Z->Z) (word_load:list Z->Z->Z->Z) */
uint32_t qcp_pack4(unsigned char a,unsigned char b,unsigned char c,unsigned char d)
/*@ Require 0<=a && a<=255 && 0<=b && b<=255 && 0<=c && c<=255 && 0<=d && d<=255 Ensure __return==pack4(a,b,c,d) && 0<=__return && __return<=4294967295 */
;
unsigned char qcp_load_lane(const unsigned char*p,size_t vl,size_t i)
/*@ With (A:list Z) (n:Z) Require 0<vl && vl<=128 && vl<=n && n<=18446744073709551615 && 0<=i && i<128 && UCharArray::full(p,n,A)
 Ensure UCharArray::full(p,n,A) * (__return==lane_load(A,vl,i) && 0<=__return && __return<=255) */
{if(i<vl)return p[i];return 0;}
uint32_t qcp_load_word(const unsigned char*p,size_t vl,size_t wi)
/*@ With (A:list Z) (n:Z) Require 0<vl && vl<=128 && vl<=n && n<=18446744073709551615 && 0<=wi && wi<32 && UCharArray::full(p,n,A)
 Ensure UCharArray::full(p,n,A) * (__return==word_load(A,vl,wi) && 0<=__return && __return<=4294967295) */
{return qcp_pack4(qcp_load_lane(p,vl,4*wi),qcp_load_lane(p,vl,4*wi+1),qcp_load_lane(p,vl,4*wi+2),qcp_load_lane(p,vl,4*wi+3));}
