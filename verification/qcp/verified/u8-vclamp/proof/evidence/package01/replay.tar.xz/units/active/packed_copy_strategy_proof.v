Require Import Coq.ZArith.ZArith.
Require Import Coq.Bool.Bool.
Require Import Coq.Lists.List.
Require Import Coq.Strings.String.
Require Import Coq.micromega.Psatz.
From SimpleC.SL Require Import SeparationLogic.
From FullU8 Require Import packed_copy_strategy_goal.
Import Snaive_C_Rules64.
Require Import FullU8.Packed32Layout.
Local Open Scope Z_scope.
Local Open Scope sac.
Local Open Scope string.

Lemma packed_copy_strategy1_correctness : packed_copy_strategy1.
  pre_process_default.
Admitted.
