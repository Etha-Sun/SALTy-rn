From FullU8 Require Import arrays_strategy_goal arrays_strategy_proof.

Module arrays_Strategy_Correctness : arrays_Strategy_Correct.
  Include arrays_strategy_proof.
End arrays_Strategy_Correctness.
