Require Import Coq.ZArith.ZArith.
Require Import Coq.Bool.Bool.
Require Import Coq.Strings.String.
Require Import Coq.Strings.Ascii.
Require Import Coq.Lists.List.
Require Import Coq.Classes.RelationClasses.
Require Import Coq.Classes.Morphisms.
Require Import Coq.micromega.Psatz.
Require Import Coq.Sorting.Permutation.
From AUXLib Require Import int_auto Axioms Feq Idents ListLib VMap.
Require Import SetsClass.SetsClass. Import SetsNotation.
From SimpleC.SL Require Import Mem SeparationLogic.
From MemoryCodecVC Require Import unit_goal.
From MemoryCodecVC Require Import unit_proof_auto.
Require Import Logic.LogicGenerator.demo932.Interface.
Local Open Scope Z_scope.
Local Open Scope sets.
Local Open Scope string_scope.
Local Open Scope list.
Import Snaive_C_Rules64.
Require Import FullU8.U8Logic FullU8.U8KernelLogic.
Require Import FullU8.Packed32Model.
Local Open Scope sac.

Lemma proof_of_qcp_load_lane_return_wit_1_split_goal_1 : qcp_load_lane_return_wit_1_split_goal_1.
Proof. Abort.

Lemma proof_of_qcp_load_lane_return_wit_1 : qcp_load_lane_return_wit_1.
Proof. Admitted. 

Lemma proof_of_qcp_load_lane_return_wit_2_split_goal_1 : qcp_load_lane_return_wit_2_split_goal_1.
Proof. Abort.

Lemma proof_of_qcp_load_lane_return_wit_2_split_goal_2 : qcp_load_lane_return_wit_2_split_goal_2.
Proof. Abort.

Lemma proof_of_qcp_load_lane_return_wit_2_split_goal_3 : qcp_load_lane_return_wit_2_split_goal_3.
Proof. Abort.

Lemma proof_of_qcp_load_lane_return_wit_2 : qcp_load_lane_return_wit_2.
Proof. Admitted. 

Lemma proof_of_qcp_load_word_return_wit_1_split_goal_1 : qcp_load_word_return_wit_1_split_goal_1.
Proof. Abort.

Lemma proof_of_qcp_load_word_return_wit_1 : qcp_load_word_return_wit_1.
Proof. Admitted. 

