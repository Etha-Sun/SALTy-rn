Require Import Coq.ZArith.ZArith.
Require Import Coq.Bool.Bool.
Require Import Coq.Lists.List.
Require Import Coq.Strings.String.
Require Import Coq.micromega.Psatz.
From SimpleC.SL Require Import SeparationLogic.
From FullU8 Require Import arrays_strategy_goal.
Import Snaive_C_Rules64.
Require Import FullU8.U8Logic FullU8.U8KernelLogic.
Local Open Scope Z_scope.
Local Open Scope sac.
Local Open Scope string.

Lemma arrays_strategy1_correctness : arrays_strategy1.
  pre_process_default.
Admitted.

Lemma arrays_strategy4_correctness : arrays_strategy4.
  pre_process_default.
Admitted.

Lemma arrays_strategy40_correctness : arrays_strategy40.
  pre_process_default.
Admitted.

Lemma arrays_strategy101_correctness : arrays_strategy101.
  pre_process_default.
Admitted.

Lemma arrays_strategy102_correctness : arrays_strategy102.
  pre_process_default.
Admitted.

Lemma arrays_strategy103_correctness : arrays_strategy103.
  pre_process_default.
Admitted.

Lemma arrays_strategy105_correctness : arrays_strategy105.
  pre_process_default.
Admitted.

Lemma arrays_strategy106_correctness : arrays_strategy106.
  pre_process_default.
Admitted.

Lemma arrays_strategy107_correctness : arrays_strategy107.
  pre_process_default.
Admitted.

Lemma arrays_strategy108_correctness : arrays_strategy108.
  pre_process_default.
Admitted.

Lemma arrays_strategy150_correctness : arrays_strategy150.
  pre_process_default.
Admitted.

Lemma arrays_strategy151_correctness : arrays_strategy151.
  pre_process_default.
Admitted.

Lemma arrays_strategy200_correctness : arrays_strategy200.
  pre_process_default.
Admitted.

Lemma arrays_strategy201_correctness : arrays_strategy201.
  pre_process_default.
Admitted.

Lemma arrays_strategy202_correctness : arrays_strategy202.
  pre_process_default.
Admitted.

Lemma arrays_strategy203_correctness : arrays_strategy203.
  pre_process_default.
Admitted.

Lemma arrays_strategy204_correctness : arrays_strategy204.
  pre_process_default.
Admitted.

Lemma arrays_strategy205_correctness : arrays_strategy205.
  pre_process_default.
Admitted.

Lemma arrays_strategy220_correctness : arrays_strategy220.
  pre_process_default.
Admitted.

Lemma arrays_strategy221_correctness : arrays_strategy221.
  pre_process_default.
Admitted.

Lemma arrays_strategy104_correctness : arrays_strategy104.
  pre_process_default.
Admitted.

Lemma arrays_strategy2_correctness : arrays_strategy2.
  pre_process_default.
Admitted.

Lemma arrays_strategy3_correctness : arrays_strategy3.
  pre_process_default.
Admitted.

Lemma arrays_strategy11_correctness : arrays_strategy11.
  pre_process_default.
Admitted.

Lemma arrays_strategy12_correctness : arrays_strategy12.
  pre_process_default.
Admitted.

Lemma arrays_strategy14_correctness : arrays_strategy14.
  pre_process_default.
Admitted.

Lemma arrays_strategy18_correctness : arrays_strategy18.
  pre_process_default.
Admitted.

Lemma arrays_strategy26_correctness : arrays_strategy26.
  pre_process_default.
Admitted.
