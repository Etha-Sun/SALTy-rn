#define QCP_IMPLEMENT___riscv_vmaxu_vx_u8m8
#include "packed.h"
vuint8m8_t __riscv_vmaxu_vx_u8m8(vuint8m8_t a,unsigned char x,size_t vl)
/*@ With (x0:Z) (x1:Z) (x2:Z) (x3:Z) (x4:Z) (x5:Z) (x6:Z) (x7:Z) (x8:Z) (x9:Z) (x10:Z) (x11:Z) (x12:Z) (x13:Z) (x14:Z) (x15:Z) (x16:Z) (x17:Z) (x18:Z) (x19:Z) (x20:Z) (x21:Z) (x22:Z) (x23:Z) (x24:Z) (x25:Z) (x26:Z) (x27:Z) (x28:Z) (x29:Z) (x30:Z) (x31:Z) Require 0<vl && vl<=128 && 0<=x && x<=255 && store(&(a.w0),unsigned int,x0) * store(&(a.w1),unsigned int,x1) * store(&(a.w2),unsigned int,x2) * store(&(a.w3),unsigned int,x3) * store(&(a.w4),unsigned int,x4) * store(&(a.w5),unsigned int,x5) * store(&(a.w6),unsigned int,x6) * store(&(a.w7),unsigned int,x7) * store(&(a.w8),unsigned int,x8) * store(&(a.w9),unsigned int,x9) * store(&(a.w10),unsigned int,x10) * store(&(a.w11),unsigned int,x11) * store(&(a.w12),unsigned int,x12) * store(&(a.w13),unsigned int,x13) * store(&(a.w14),unsigned int,x14) * store(&(a.w15),unsigned int,x15) * store(&(a.w16),unsigned int,x16) * store(&(a.w17),unsigned int,x17) * store(&(a.w18),unsigned int,x18) * store(&(a.w19),unsigned int,x19) * store(&(a.w20),unsigned int,x20) * store(&(a.w21),unsigned int,x21) * store(&(a.w22),unsigned int,x22) * store(&(a.w23),unsigned int,x23) * store(&(a.w24),unsigned int,x24) * store(&(a.w25),unsigned int,x25) * store(&(a.w26),unsigned int,x26) * store(&(a.w27),unsigned int,x27) * store(&(a.w28),unsigned int,x28) * store(&(a.w29),unsigned int,x29) * store(&(a.w30),unsigned int,x30) * store(&(a.w31),unsigned int,x31) Ensure store(&(__return.w0),unsigned int,word_max(x0,x,vl,0)) * store(&(__return.w1),unsigned int,word_max(x1,x,vl,1)) * store(&(__return.w2),unsigned int,word_max(x2,x,vl,2)) * store(&(__return.w3),unsigned int,word_max(x3,x,vl,3)) * store(&(__return.w4),unsigned int,word_max(x4,x,vl,4)) * store(&(__return.w5),unsigned int,word_max(x5,x,vl,5)) * store(&(__return.w6),unsigned int,word_max(x6,x,vl,6)) * store(&(__return.w7),unsigned int,word_max(x7,x,vl,7)) * store(&(__return.w8),unsigned int,word_max(x8,x,vl,8)) * store(&(__return.w9),unsigned int,word_max(x9,x,vl,9)) * store(&(__return.w10),unsigned int,word_max(x10,x,vl,10)) * store(&(__return.w11),unsigned int,word_max(x11,x,vl,11)) * store(&(__return.w12),unsigned int,word_max(x12,x,vl,12)) * store(&(__return.w13),unsigned int,word_max(x13,x,vl,13)) * store(&(__return.w14),unsigned int,word_max(x14,x,vl,14)) * store(&(__return.w15),unsigned int,word_max(x15,x,vl,15)) * store(&(__return.w16),unsigned int,word_max(x16,x,vl,16)) * store(&(__return.w17),unsigned int,word_max(x17,x,vl,17)) * store(&(__return.w18),unsigned int,word_max(x18,x,vl,18)) * store(&(__return.w19),unsigned int,word_max(x19,x,vl,19)) * store(&(__return.w20),unsigned int,word_max(x20,x,vl,20)) * store(&(__return.w21),unsigned int,word_max(x21,x,vl,21)) * store(&(__return.w22),unsigned int,word_max(x22,x,vl,22)) * store(&(__return.w23),unsigned int,word_max(x23,x,vl,23)) * store(&(__return.w24),unsigned int,word_max(x24,x,vl,24)) * store(&(__return.w25),unsigned int,word_max(x25,x,vl,25)) * store(&(__return.w26),unsigned int,word_max(x26,x,vl,26)) * store(&(__return.w27),unsigned int,word_max(x27,x,vl,27)) * store(&(__return.w28),unsigned int,word_max(x28,x,vl,28)) * store(&(__return.w29),unsigned int,word_max(x29,x,vl,29)) * store(&(__return.w30),unsigned int,word_max(x30,x,vl,30)) * store(&(__return.w31),unsigned int,word_max(x31,x,vl,31)) */
{vuint8m8_t r;r.w0=qcp_word_max(a.w0,x,vl,0);
r.w1=qcp_word_max(a.w1,x,vl,1);
r.w2=qcp_word_max(a.w2,x,vl,2);
r.w3=qcp_word_max(a.w3,x,vl,3);
r.w4=qcp_word_max(a.w4,x,vl,4);
r.w5=qcp_word_max(a.w5,x,vl,5);
r.w6=qcp_word_max(a.w6,x,vl,6);
r.w7=qcp_word_max(a.w7,x,vl,7);
r.w8=qcp_word_max(a.w8,x,vl,8);
r.w9=qcp_word_max(a.w9,x,vl,9);
r.w10=qcp_word_max(a.w10,x,vl,10);
r.w11=qcp_word_max(a.w11,x,vl,11);
r.w12=qcp_word_max(a.w12,x,vl,12);
r.w13=qcp_word_max(a.w13,x,vl,13);
r.w14=qcp_word_max(a.w14,x,vl,14);
r.w15=qcp_word_max(a.w15,x,vl,15);
r.w16=qcp_word_max(a.w16,x,vl,16);
r.w17=qcp_word_max(a.w17,x,vl,17);
r.w18=qcp_word_max(a.w18,x,vl,18);
r.w19=qcp_word_max(a.w19,x,vl,19);
r.w20=qcp_word_max(a.w20,x,vl,20);
r.w21=qcp_word_max(a.w21,x,vl,21);
r.w22=qcp_word_max(a.w22,x,vl,22);
r.w23=qcp_word_max(a.w23,x,vl,23);
r.w24=qcp_word_max(a.w24,x,vl,24);
r.w25=qcp_word_max(a.w25,x,vl,25);
r.w26=qcp_word_max(a.w26,x,vl,26);
r.w27=qcp_word_max(a.w27,x,vl,27);
r.w28=qcp_word_max(a.w28,x,vl,28);
r.w29=qcp_word_max(a.w29,x,vl,29);
r.w30=qcp_word_max(a.w30,x,vl,30);
r.w31=qcp_word_max(a.w31,x,vl,31);
return r;}
