typedef unsigned long long size_t;
typedef unsigned char uint8_t;
typedef unsigned int uint32_t;
/*@ Import Coq Require Import FullU8.U8Logic FullU8.Packed32Model */
/*@ Extern Coq (pack4:Z->Z->Z->Z->Z) (word_byte:Z->Z->Z) (u8_min:Z->Z->Z) (u8_max:Z->Z->Z) (active_min:Z->Z->Z->Z->Z) (active_max:Z->Z->Z->Z->Z) (word_min:Z->Z->Z->Z->Z) (word_max:Z->Z->Z->Z->Z) */
uint32_t qcp_pack4(unsigned char a,unsigned char b,unsigned char c,unsigned char d)
/*@ Require 0<=a && a<=255 && 0<=b && b<=255 && 0<=c && c<=255 && 0<=d && d<=255 Ensure __return==pack4(a,b,c,d) && 0<=__return && __return<=4294967295 */
;
unsigned char qcp_word_byte(uint32_t w,uint32_t lane)
/*@ Require 0<=lane && lane<4 Ensure __return==word_byte(w,lane) && 0<=__return && __return<=255 */
;
unsigned char qcp_u8_min(unsigned char x,unsigned char y)
/*@ Require emp Ensure __return==u8_min(x,y) */
{if(x<y)return x;return y;}
unsigned char qcp_u8_max(unsigned char x,unsigned char y)
/*@ Require emp Ensure __return==u8_max(x,y) */
{if(x<y)return y;return x;}
unsigned char qcp_active_min(unsigned char x,unsigned char y,size_t vl,size_t i)
/*@ Require 0<=x && x<=255 && 0<=y && y<=255 && 0<vl && vl<=128 && 0<=i && i<128 Ensure __return==active_min(x,y,vl,i) && 0<=__return && __return<=255 */
{if(i<vl)return qcp_u8_min(x,y);return x;}
unsigned char qcp_active_max(unsigned char x,unsigned char y,size_t vl,size_t i)
/*@ Require 0<=x && x<=255 && 0<=y && y<=255 && 0<vl && vl<=128 && 0<=i && i<128 Ensure __return==active_max(x,y,vl,i) && 0<=__return && __return<=255 */
{if(i<vl)return qcp_u8_max(x,y);return x;}
uint32_t qcp_word_min(uint32_t w,unsigned char y,size_t vl,size_t wi)
/*@ Require 0<=y && y<=255 && 0<vl && vl<=128 && 0<=wi && wi<32 Ensure __return==word_min(w,y,vl,wi) && 0<=__return && __return<=4294967295 */
{return qcp_pack4(qcp_active_min(qcp_word_byte(w,0),y,vl,4*wi+0),qcp_active_min(qcp_word_byte(w,1),y,vl,4*wi+1),qcp_active_min(qcp_word_byte(w,2),y,vl,4*wi+2),qcp_active_min(qcp_word_byte(w,3),y,vl,4*wi+3));}
uint32_t qcp_word_max(uint32_t w,unsigned char y,size_t vl,size_t wi)
/*@ Require 0<=y && y<=255 && 0<vl && vl<=128 && 0<=wi && wi<32 Ensure __return==word_max(w,y,vl,wi) && 0<=__return && __return<=4294967295 */
{return qcp_pack4(qcp_active_max(qcp_word_byte(w,0),y,vl,4*wi+0),qcp_active_max(qcp_word_byte(w,1),y,vl,4*wi+1),qcp_active_max(qcp_word_byte(w,2),y,vl,4*wi+2),qcp_active_max(qcp_word_byte(w,3),y,vl,4*wi+3));}
