From FullU8 Require Import u8_copy_strategy_goal u8_copy_strategy_proof.

Module u8_copy_Strategy_Correctness : u8_copy_Strategy_Correct.
  Include u8_copy_strategy_proof.
End u8_copy_Strategy_Correctness.
