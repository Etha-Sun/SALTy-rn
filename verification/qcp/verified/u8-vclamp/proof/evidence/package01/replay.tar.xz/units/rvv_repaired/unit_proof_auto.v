Require Import Coq.ZArith.ZArith.
Require Import Coq.Bool.Bool.
Require Import Coq.Strings.String.
Require Import Coq.Strings.Ascii.
Require Import Coq.Lists.List.
Require Import Coq.Classes.RelationClasses.
Require Import Coq.Classes.Morphisms.
Require Import Coq.micromega.Psatz.
Require Import Coq.Sorting.Permutation.
From AUXLib Require Import int_auto Axioms Feq Idents ListLib VMap.
Require Import SetsClass.SetsClass. Import SetsNotation.
From SimpleC.SL Require Import Mem SeparationLogic.
From FullU8 Require Import unit_goal.
Require Import Logic.LogicGenerator.demo932.Interface.
Local Open Scope Z_scope.
Local Open Scope sets.
Local Open Scope string_scope.
Local Open Scope list.
Import Snaive_C_Rules64.
Require Import FullU8.Packed32Layout.
Require Import FullU8.U8Logic FullU8.U8KernelLogic.
Require Import FullU8.Packed32Model.
Local Open Scope sac.

Lemma proof_of_qcp_assert_safety_wit_1 : qcp_assert_safety_wit_1.
Proof. Admitted. 

Lemma proof_of_qcp_assert_entail_wit_1 : qcp_assert_entail_wit_1.
Proof. Admitted. 

Lemma proof_of_qcp_assert_entail_wit_2 : qcp_assert_entail_wit_2.
Proof. Admitted. 

Lemma proof_of_qcp_assert_return_wit_1 : qcp_assert_return_wit_1.
Proof. Admitted. 

Lemma proof_of_test_rvv_safety_wit_1 : test_rvv_safety_wit_1.
Proof. Admitted. 

Lemma proof_of_test_rvv_safety_wit_2 : test_rvv_safety_wit_2.
Proof. Admitted. 

Lemma proof_of_test_rvv_safety_wit_3 : test_rvv_safety_wit_3.
Proof. Admitted. 

Lemma proof_of_test_rvv_safety_wit_4 : test_rvv_safety_wit_4.
Proof. Admitted. 

Lemma proof_of_test_rvv_safety_wit_5 : test_rvv_safety_wit_5.
Proof. Admitted. 

Lemma proof_of_test_rvv_safety_wit_6 : test_rvv_safety_wit_6.
Proof. Admitted. 

Lemma proof_of_test_rvv_safety_wit_7 : test_rvv_safety_wit_7.
Proof. Admitted. 

Lemma proof_of_test_rvv_safety_wit_8 : test_rvv_safety_wit_8.
Proof. Admitted. 

Lemma proof_of_test_rvv_safety_wit_9 : test_rvv_safety_wit_9.
Proof. Admitted. 

Lemma proof_of_test_rvv_safety_wit_10 : test_rvv_safety_wit_10.
Proof. Admitted. 

Lemma proof_of_test_rvv_safety_wit_11 : test_rvv_safety_wit_11.
Proof. Admitted. 

Lemma proof_of_test_rvv_safety_wit_12 : test_rvv_safety_wit_12.
Proof. Admitted. 

Lemma proof_of_test_rvv_safety_wit_13 : test_rvv_safety_wit_13.
Proof. Admitted. 

Lemma proof_of_test_rvv_safety_wit_14 : test_rvv_safety_wit_14.
Proof. Admitted. 

Lemma proof_of_test_rvv_safety_wit_15 : test_rvv_safety_wit_15.
Proof. Admitted. 

Lemma proof_of_test_rvv_safety_wit_16 : test_rvv_safety_wit_16.
Proof. Admitted. 

Lemma proof_of_test_rvv_partial_solve_wit_1 : test_rvv_partial_solve_wit_1.
Proof. Admitted. 

Lemma proof_of_test_rvv_partial_solve_wit_2 : test_rvv_partial_solve_wit_2.
Proof. Admitted. 

Lemma proof_of_test_rvv_partial_solve_wit_3 : test_rvv_partial_solve_wit_3.
Proof. Admitted. 

Lemma proof_of_test_rvv_partial_solve_wit_4 : test_rvv_partial_solve_wit_4.
Proof. Admitted. 

Lemma proof_of_test_rvv_partial_solve_wit_5 : test_rvv_partial_solve_wit_5.
Proof. Admitted. 

Lemma proof_of_test_rvv_partial_solve_wit_6_pure : test_rvv_partial_solve_wit_6_pure.
Proof. Admitted. 

Lemma proof_of_test_rvv_partial_solve_wit_6 : test_rvv_partial_solve_wit_6.
Proof. Admitted. 

Lemma proof_of_test_rvv_partial_solve_wit_7_pure : test_rvv_partial_solve_wit_7_pure.
Proof. Admitted. 

Lemma proof_of_test_rvv_partial_solve_wit_7 : test_rvv_partial_solve_wit_7.
Proof. Admitted. 

Lemma proof_of_test_rvv_partial_solve_wit_8 : test_rvv_partial_solve_wit_8.
Proof. Admitted. 

Lemma proof_of_test_rvv_partial_solve_wit_9 : test_rvv_partial_solve_wit_9.
Proof. Admitted. 

Lemma proof_of_test_rvv_partial_solve_wit_10 : test_rvv_partial_solve_wit_10.
Proof. Admitted. 

Lemma proof_of_test_rvv_partial_solve_wit_11 : test_rvv_partial_solve_wit_11.
Proof. Admitted. 

Lemma proof_of_test_rvv_partial_solve_wit_12 : test_rvv_partial_solve_wit_12.
Proof. Admitted. 

Lemma proof_of_test_rvv_partial_solve_wit_13 : test_rvv_partial_solve_wit_13.
Proof. Admitted. 

Lemma proof_of_test_rvv_partial_solve_wit_14 : test_rvv_partial_solve_wit_14.
Proof. Admitted. 

Lemma proof_of_test_rvv_partial_solve_wit_15 : test_rvv_partial_solve_wit_15.
Proof. Admitted. 

Lemma proof_of_test_rvv_partial_solve_wit_16 : test_rvv_partial_solve_wit_16.
Proof. Admitted. 

Lemma proof_of_test_rvv_partial_solve_wit_17 : test_rvv_partial_solve_wit_17.
Proof. Admitted. 

Lemma proof_of_test_rvv_partial_solve_wit_18 : test_rvv_partial_solve_wit_18.
Proof. Admitted. 

Lemma proof_of_test_rvv_partial_solve_wit_19 : test_rvv_partial_solve_wit_19.
Proof. Admitted. 

Lemma proof_of_test_rvv_partial_solve_wit_20 : test_rvv_partial_solve_wit_20.
Proof. Admitted. 

Lemma proof_of_test_rvv_partial_solve_wit_21 : test_rvv_partial_solve_wit_21.
Proof. Admitted. 

Lemma proof_of_test_rvv_partial_solve_wit_22 : test_rvv_partial_solve_wit_22.
Proof. Admitted. 

Lemma proof_of_test_rvv_partial_solve_wit_23 : test_rvv_partial_solve_wit_23.
Proof. Admitted. 

Lemma proof_of_test_rvv_partial_solve_wit_24_pure : test_rvv_partial_solve_wit_24_pure.
Proof. Admitted. 

Lemma proof_of_test_rvv_partial_solve_wit_24 : test_rvv_partial_solve_wit_24.
Proof. Admitted. 

Lemma proof_of_test_rvv_partial_solve_wit_25_pure : test_rvv_partial_solve_wit_25_pure.
Proof. Admitted. 

Lemma proof_of_test_rvv_partial_solve_wit_25 : test_rvv_partial_solve_wit_25.
Proof. Admitted. 

Lemma proof_of_test_rvv_partial_solve_wit_26_pure : test_rvv_partial_solve_wit_26_pure.
Proof. Admitted. 

Lemma proof_of_test_rvv_partial_solve_wit_26 : test_rvv_partial_solve_wit_26.
Proof. Admitted. 

Lemma proof_of_test_rvv_partial_solve_wit_27_pure : test_rvv_partial_solve_wit_27_pure.
Proof. Admitted. 

Lemma proof_of_test_rvv_partial_solve_wit_27 : test_rvv_partial_solve_wit_27.
Proof. Admitted. 

Lemma proof_of_test_rvv_partial_solve_wit_28 : test_rvv_partial_solve_wit_28.
Proof. Admitted. 

Lemma proof_of_test_rvv_partial_solve_wit_29 : test_rvv_partial_solve_wit_29.
Proof. Admitted. 

Lemma proof_of_test_rvv_partial_solve_wit_30 : test_rvv_partial_solve_wit_30.
Proof. Admitted. 

Lemma proof_of_test_rvv_partial_solve_wit_31 : test_rvv_partial_solve_wit_31.
Proof. Admitted. 

Lemma proof_of_test_rvv_partial_solve_wit_32 : test_rvv_partial_solve_wit_32.
Proof. Admitted. 

Lemma proof_of_test_rvv_partial_solve_wit_33 : test_rvv_partial_solve_wit_33.
Proof. Admitted. 

Lemma proof_of_test_rvv_partial_solve_wit_34 : test_rvv_partial_solve_wit_34.
Proof. Admitted. 

Lemma proof_of_test_rvv_partial_solve_wit_35 : test_rvv_partial_solve_wit_35.
Proof. Admitted. 

Lemma proof_of_test_rvv_partial_solve_wit_36 : test_rvv_partial_solve_wit_36.
Proof. Admitted. 

Lemma proof_of_test_rvv_partial_solve_wit_37 : test_rvv_partial_solve_wit_37.
Proof. Admitted. 

Lemma proof_of_test_rvv_partial_solve_wit_38 : test_rvv_partial_solve_wit_38.
Proof. Admitted. 

Lemma proof_of_test_rvv_partial_solve_wit_39 : test_rvv_partial_solve_wit_39.
Proof. Admitted. 

Lemma proof_of_test_rvv_partial_solve_wit_40_pure : test_rvv_partial_solve_wit_40_pure.
Proof. Admitted. 

Lemma proof_of_test_rvv_partial_solve_wit_40 : test_rvv_partial_solve_wit_40.
Proof. Admitted. 

Lemma proof_of_test_rvv_partial_solve_wit_41_pure : test_rvv_partial_solve_wit_41_pure.
Proof. Admitted. 

Lemma proof_of_test_rvv_partial_solve_wit_41 : test_rvv_partial_solve_wit_41.
Proof. Admitted. 

