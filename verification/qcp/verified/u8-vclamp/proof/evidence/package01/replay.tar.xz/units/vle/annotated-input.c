#define QCP_IMPLEMENT___riscv_vle8_v_u8m8
#include "packed.h"
vuint8m8_t __riscv_vle8_v_u8m8(const unsigned char*p,size_t vl)
/*@ With (A:list Z) (n:Z) Require 0<vl && vl<=128 && vl<=n && n<=18446744073709551615 && UCharArray::full(p,n,A) Ensure UCharArray::seg(p,0,vl,sublist(0,vl,A)) * UCharArray::full(p+vl,n-vl,sublist(vl,n,A)) * store(&(__return.w0),unsigned int,word_load(A,vl,0)) * store(&(__return.w1),unsigned int,word_load(A,vl,1)) * store(&(__return.w2),unsigned int,word_load(A,vl,2)) * store(&(__return.w3),unsigned int,word_load(A,vl,3)) * store(&(__return.w4),unsigned int,word_load(A,vl,4)) * store(&(__return.w5),unsigned int,word_load(A,vl,5)) * store(&(__return.w6),unsigned int,word_load(A,vl,6)) * store(&(__return.w7),unsigned int,word_load(A,vl,7)) * store(&(__return.w8),unsigned int,word_load(A,vl,8)) * store(&(__return.w9),unsigned int,word_load(A,vl,9)) * store(&(__return.w10),unsigned int,word_load(A,vl,10)) * store(&(__return.w11),unsigned int,word_load(A,vl,11)) * store(&(__return.w12),unsigned int,word_load(A,vl,12)) * store(&(__return.w13),unsigned int,word_load(A,vl,13)) * store(&(__return.w14),unsigned int,word_load(A,vl,14)) * store(&(__return.w15),unsigned int,word_load(A,vl,15)) * store(&(__return.w16),unsigned int,word_load(A,vl,16)) * store(&(__return.w17),unsigned int,word_load(A,vl,17)) * store(&(__return.w18),unsigned int,word_load(A,vl,18)) * store(&(__return.w19),unsigned int,word_load(A,vl,19)) * store(&(__return.w20),unsigned int,word_load(A,vl,20)) * store(&(__return.w21),unsigned int,word_load(A,vl,21)) * store(&(__return.w22),unsigned int,word_load(A,vl,22)) * store(&(__return.w23),unsigned int,word_load(A,vl,23)) * store(&(__return.w24),unsigned int,word_load(A,vl,24)) * store(&(__return.w25),unsigned int,word_load(A,vl,25)) * store(&(__return.w26),unsigned int,word_load(A,vl,26)) * store(&(__return.w27),unsigned int,word_load(A,vl,27)) * store(&(__return.w28),unsigned int,word_load(A,vl,28)) * store(&(__return.w29),unsigned int,word_load(A,vl,29)) * store(&(__return.w30),unsigned int,word_load(A,vl,30)) * store(&(__return.w31),unsigned int,word_load(A,vl,31)) */
{vuint8m8_t r;r.w0=qcp_load_word(p,vl,0);
r.w1=qcp_load_word(p,vl,1);
r.w2=qcp_load_word(p,vl,2);
r.w3=qcp_load_word(p,vl,3);
r.w4=qcp_load_word(p,vl,4);
r.w5=qcp_load_word(p,vl,5);
r.w6=qcp_load_word(p,vl,6);
r.w7=qcp_load_word(p,vl,7);
r.w8=qcp_load_word(p,vl,8);
r.w9=qcp_load_word(p,vl,9);
r.w10=qcp_load_word(p,vl,10);
r.w11=qcp_load_word(p,vl,11);
r.w12=qcp_load_word(p,vl,12);
r.w13=qcp_load_word(p,vl,13);
r.w14=qcp_load_word(p,vl,14);
r.w15=qcp_load_word(p,vl,15);
r.w16=qcp_load_word(p,vl,16);
r.w17=qcp_load_word(p,vl,17);
r.w18=qcp_load_word(p,vl,18);
r.w19=qcp_load_word(p,vl,19);
r.w20=qcp_load_word(p,vl,20);
r.w21=qcp_load_word(p,vl,21);
r.w22=qcp_load_word(p,vl,22);
r.w23=qcp_load_word(p,vl,23);
r.w24=qcp_load_word(p,vl,24);
r.w25=qcp_load_word(p,vl,25);
r.w26=qcp_load_word(p,vl,26);
r.w27=qcp_load_word(p,vl,27);
r.w28=qcp_load_word(p,vl,28);
r.w29=qcp_load_word(p,vl,29);
r.w30=qcp_load_word(p,vl,30);
r.w31=qcp_load_word(p,vl,31);
return r;}
