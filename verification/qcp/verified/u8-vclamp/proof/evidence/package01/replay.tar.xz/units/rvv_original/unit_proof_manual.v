Require Import Coq.ZArith.ZArith.
Require Import Coq.Bool.Bool.
Require Import Coq.Strings.String.
Require Import Coq.Strings.Ascii.
Require Import Coq.Lists.List.
Require Import Coq.Classes.RelationClasses.
Require Import Coq.Classes.Morphisms.
Require Import Coq.micromega.Psatz.
Require Import Coq.Sorting.Permutation.
From AUXLib Require Import int_auto Axioms Feq Idents ListLib VMap.
Require Import SetsClass.SetsClass. Import SetsNotation.
From SimpleC.SL Require Import Mem SeparationLogic.
From FullU8 Require Import unit_goal.
From FullU8 Require Import unit_proof_auto.
Require Import Logic.LogicGenerator.demo932.Interface.
Local Open Scope Z_scope.
Local Open Scope sets.
Local Open Scope string_scope.
Local Open Scope list.
Import Snaive_C_Rules64.
Require Import FullU8.Packed32Layout.
Require Import FullU8.U8Logic FullU8.U8KernelLogic.
Require Import FullU8.Packed32Model.
Local Open Scope sac.

Lemma proof_of_test_rvv_entail_wit_1_split_goal_1 : test_rvv_entail_wit_1_split_goal_1.
Proof. Abort.

Lemma proof_of_test_rvv_entail_wit_1_split_goal_2 : test_rvv_entail_wit_1_split_goal_2.
Proof. Abort.

Lemma proof_of_test_rvv_entail_wit_1_split_goal_3 : test_rvv_entail_wit_1_split_goal_3.
Proof. Abort.

Lemma proof_of_test_rvv_entail_wit_1_split_goal_4 : test_rvv_entail_wit_1_split_goal_4.
Proof. Abort.

Lemma proof_of_test_rvv_entail_wit_1_split_goal_5 : test_rvv_entail_wit_1_split_goal_5.
Proof. Abort.

Lemma proof_of_test_rvv_entail_wit_1_split_goal_6 : test_rvv_entail_wit_1_split_goal_6.
Proof. Abort.

Lemma proof_of_test_rvv_entail_wit_1_split_goal_7 : test_rvv_entail_wit_1_split_goal_7.
Proof. Abort.

Lemma proof_of_test_rvv_entail_wit_1_split_goal_8 : test_rvv_entail_wit_1_split_goal_8.
Proof. Abort.

Lemma proof_of_test_rvv_entail_wit_1_split_goal_9 : test_rvv_entail_wit_1_split_goal_9.
Proof. Abort.

Lemma proof_of_test_rvv_entail_wit_1 : test_rvv_entail_wit_1.
Proof. Admitted. 

Lemma proof_of_test_rvv_entail_wit_2_split_goal_1 : test_rvv_entail_wit_2_split_goal_1.
Proof. Abort.

Lemma proof_of_test_rvv_entail_wit_2_split_goal_2 : test_rvv_entail_wit_2_split_goal_2.
Proof. Abort.

Lemma proof_of_test_rvv_entail_wit_2_split_goal_3 : test_rvv_entail_wit_2_split_goal_3.
Proof. Abort.

Lemma proof_of_test_rvv_entail_wit_2_split_goal_4 : test_rvv_entail_wit_2_split_goal_4.
Proof. Abort.

Lemma proof_of_test_rvv_entail_wit_2_split_goal_5 : test_rvv_entail_wit_2_split_goal_5.
Proof. Abort.

Lemma proof_of_test_rvv_entail_wit_2_split_goal_6 : test_rvv_entail_wit_2_split_goal_6.
Proof. Abort.

Lemma proof_of_test_rvv_entail_wit_2_split_goal_7 : test_rvv_entail_wit_2_split_goal_7.
Proof. Abort.

Lemma proof_of_test_rvv_entail_wit_2_split_goal_8 : test_rvv_entail_wit_2_split_goal_8.
Proof. Abort.

Lemma proof_of_test_rvv_entail_wit_2_split_goal_9 : test_rvv_entail_wit_2_split_goal_9.
Proof. Abort.

Lemma proof_of_test_rvv_entail_wit_2_split_goal_10 : test_rvv_entail_wit_2_split_goal_10.
Proof. Abort.

Lemma proof_of_test_rvv_entail_wit_2_split_goal_spatial : test_rvv_entail_wit_2_split_goal_spatial.
Proof. Abort.

Lemma proof_of_test_rvv_entail_wit_2 : test_rvv_entail_wit_2.
Proof. Admitted. 

Lemma proof_of_test_rvv_entail_wit_3_split_goal_1 : test_rvv_entail_wit_3_split_goal_1.
Proof. Abort.

Lemma proof_of_test_rvv_entail_wit_3_split_goal_2 : test_rvv_entail_wit_3_split_goal_2.
Proof. Abort.

Lemma proof_of_test_rvv_entail_wit_3 : test_rvv_entail_wit_3.
Proof. Admitted. 

Lemma proof_of_test_rvv_entail_wit_4_split_goal_1 : test_rvv_entail_wit_4_split_goal_1.
Proof. Abort.

Lemma proof_of_test_rvv_entail_wit_4_split_goal_2 : test_rvv_entail_wit_4_split_goal_2.
Proof. Abort.

Lemma proof_of_test_rvv_entail_wit_4_split_goal_3 : test_rvv_entail_wit_4_split_goal_3.
Proof. Abort.

Lemma proof_of_test_rvv_entail_wit_4_split_goal_spatial : test_rvv_entail_wit_4_split_goal_spatial.
Proof. Abort.

Lemma proof_of_test_rvv_entail_wit_4 : test_rvv_entail_wit_4.
Proof. Admitted. 

Lemma proof_of_test_rvv_return_wit_1_split_goal_spatial : test_rvv_return_wit_1_split_goal_spatial.
Proof. Abort.

Lemma proof_of_test_rvv_return_wit_1 : test_rvv_return_wit_1.
Proof. Admitted. 

Lemma proof_of_test_rvv_partial_solve_wit_7_pure_split_goal_1 : test_rvv_partial_solve_wit_7_pure_split_goal_1.
Proof. Abort.

Lemma proof_of_test_rvv_partial_solve_wit_7_pure : test_rvv_partial_solve_wit_7_pure.
Proof. Admitted. 

Lemma proof_of_test_rvv_partial_solve_wit_9_pure_split_goal_1 : test_rvv_partial_solve_wit_9_pure_split_goal_1.
Proof. Abort.

Lemma proof_of_test_rvv_partial_solve_wit_9_pure_split_goal_2 : test_rvv_partial_solve_wit_9_pure_split_goal_2.
Proof. Abort.

Lemma proof_of_test_rvv_partial_solve_wit_9_pure : test_rvv_partial_solve_wit_9_pure.
Proof. Admitted. 

Lemma proof_of_test_rvv_partial_solve_wit_11_pure_split_goal_1 : test_rvv_partial_solve_wit_11_pure_split_goal_1.
Proof. Abort.

Lemma proof_of_test_rvv_partial_solve_wit_11_pure_split_goal_2 : test_rvv_partial_solve_wit_11_pure_split_goal_2.
Proof. Abort.

Lemma proof_of_test_rvv_partial_solve_wit_11_pure : test_rvv_partial_solve_wit_11_pure.
Proof. Admitted. 

Lemma proof_of_test_rvv_partial_solve_wit_14_pure_split_goal_1 : test_rvv_partial_solve_wit_14_pure_split_goal_1.
Proof. Abort.

Lemma proof_of_test_rvv_partial_solve_wit_14_pure : test_rvv_partial_solve_wit_14_pure.
Proof. Admitted. 

Lemma proof_of_test_rvv_partial_solve_wit_18_pure_split_goal_1 : test_rvv_partial_solve_wit_18_pure_split_goal_1.
Proof. Abort.

Lemma proof_of_test_rvv_partial_solve_wit_18_pure_split_goal_2 : test_rvv_partial_solve_wit_18_pure_split_goal_2.
Proof. Abort.

Lemma proof_of_test_rvv_partial_solve_wit_18_pure : test_rvv_partial_solve_wit_18_pure.
Proof. Admitted. 

Lemma proof_of_test_rvv_partial_solve_wit_20_pure_split_goal_1 : test_rvv_partial_solve_wit_20_pure_split_goal_1.
Proof. Abort.

Lemma proof_of_test_rvv_partial_solve_wit_20_pure_split_goal_2 : test_rvv_partial_solve_wit_20_pure_split_goal_2.
Proof. Abort.

Lemma proof_of_test_rvv_partial_solve_wit_20_pure : test_rvv_partial_solve_wit_20_pure.
Proof. Admitted. 

