Require Import Coq.ZArith.ZArith.
Require Import Coq.Bool.Bool.
Require Import Coq.Lists.List.
Require Import Coq.Strings.String.
Require Import Coq.micromega.Psatz.
From SimpleC.SL Require Import SeparationLogic.
From FullU8 Require Import u8_copy_strategy_goal.
Import Snaive_C_Rules64.
Require Import FullU8.Layout.
Local Open Scope Z_scope.
Local Open Scope sac.
Local Open Scope string.

Lemma u8_copy_strategy1_correctness : u8_copy_strategy1.
  pre_process_default.
Admitted.

Lemma u8_copy_strategy2_correctness : u8_copy_strategy2.
  pre_process_default.
Admitted.
