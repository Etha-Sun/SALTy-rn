typedef unsigned char uint8_t;
typedef unsigned int uint32_t;
/*@ Import Coq Require Import FullU8.Packed32Model */
/*@ Extern Coq (pack4:Z->Z->Z->Z->Z) (word_byte:Z->Z->Z) */
uint32_t qcp_pack4(unsigned char a,unsigned char b,unsigned char c,unsigned char d)
/*@ Require 0<=a && a<=255 && 0<=b && b<=255 && 0<=c && c<=255 && 0<=d && d<=255 Ensure __return==pack4(a,b,c,d) && 0<=__return && __return<=4294967295 */
{return (unsigned int)a+256U*b+65536U*c+16777216U*d;}

unsigned char qcp_word_byte(uint32_t w,uint32_t lane)
/*@ Require 0<=lane && lane<4 Ensure __return==word_byte(w,lane) && 0<=__return && __return<=255 */
{return(unsigned char)(w>>(8U*lane));}

