Require Import Coq.ZArith.ZArith.
Require Import Coq.Bool.Bool.
Require Import Coq.Strings.String.
Require Import Coq.Strings.Ascii.
Require Import Coq.Lists.List.
Require Import Coq.Classes.RelationClasses.
Require Import Coq.Classes.Morphisms.
Require Import Coq.micromega.Psatz.
Require Import Coq.Sorting.Permutation.
From AUXLib Require Import int_auto Axioms Feq Idents ListLib VMap.
Require Import SetsClass.SetsClass. Import SetsNotation.
From SimpleC.SL Require Import Mem SeparationLogic.
From ActiveCodecVC Require Import unit_goal.
Require Import Logic.LogicGenerator.demo932.Interface.
Local Open Scope Z_scope.
Local Open Scope sets.
Local Open Scope string_scope.
Local Open Scope list.
Import Snaive_C_Rules64.
Require Import FullU8.U8Logic FullU8.Packed32Model.
Local Open Scope sac.

Lemma proof_of_qcp_active_min_partial_solve_wit_1 : qcp_active_min_partial_solve_wit_1.
Proof. Admitted. 

Lemma proof_of_qcp_active_max_partial_solve_wit_1 : qcp_active_max_partial_solve_wit_1.
Proof. Admitted. 

Lemma proof_of_qcp_word_min_safety_wit_1 : qcp_word_min_safety_wit_1.
Proof. Admitted. 

Lemma proof_of_qcp_word_min_safety_wit_2 : qcp_word_min_safety_wit_2.
Proof. Admitted. 

Lemma proof_of_qcp_word_min_safety_wit_3 : qcp_word_min_safety_wit_3.
Proof. Admitted. 

Lemma proof_of_qcp_word_min_safety_wit_4 : qcp_word_min_safety_wit_4.
Proof. Admitted. 

Lemma proof_of_qcp_word_min_safety_wit_5 : qcp_word_min_safety_wit_5.
Proof. Admitted. 

Lemma proof_of_qcp_word_min_safety_wit_6 : qcp_word_min_safety_wit_6.
Proof. Admitted. 

Lemma proof_of_qcp_word_min_safety_wit_7 : qcp_word_min_safety_wit_7.
Proof. Admitted. 

Lemma proof_of_qcp_word_min_safety_wit_8 : qcp_word_min_safety_wit_8.
Proof. Admitted. 

Lemma proof_of_qcp_word_min_safety_wit_9 : qcp_word_min_safety_wit_9.
Proof. Admitted. 

Lemma proof_of_qcp_word_min_safety_wit_10 : qcp_word_min_safety_wit_10.
Proof. Admitted. 

Lemma proof_of_qcp_word_min_safety_wit_11 : qcp_word_min_safety_wit_11.
Proof. Admitted. 

Lemma proof_of_qcp_word_min_safety_wit_12 : qcp_word_min_safety_wit_12.
Proof. Admitted. 

Lemma proof_of_qcp_word_min_partial_solve_wit_1_pure : qcp_word_min_partial_solve_wit_1_pure.
Proof. Admitted. 

Lemma proof_of_qcp_word_min_partial_solve_wit_1 : qcp_word_min_partial_solve_wit_1.
Proof. Admitted. 

Lemma proof_of_qcp_word_min_partial_solve_wit_2_pure : qcp_word_min_partial_solve_wit_2_pure.
Proof. Admitted. 

Lemma proof_of_qcp_word_min_partial_solve_wit_2 : qcp_word_min_partial_solve_wit_2.
Proof. Admitted. 

Lemma proof_of_qcp_word_min_partial_solve_wit_3_pure : qcp_word_min_partial_solve_wit_3_pure.
Proof. Admitted. 

Lemma proof_of_qcp_word_min_partial_solve_wit_3 : qcp_word_min_partial_solve_wit_3.
Proof. Admitted. 

Lemma proof_of_qcp_word_min_partial_solve_wit_4_pure : qcp_word_min_partial_solve_wit_4_pure.
Proof. Admitted. 

Lemma proof_of_qcp_word_min_partial_solve_wit_4 : qcp_word_min_partial_solve_wit_4.
Proof. Admitted. 

Lemma proof_of_qcp_word_min_partial_solve_wit_5_pure : qcp_word_min_partial_solve_wit_5_pure.
Proof. Admitted. 

Lemma proof_of_qcp_word_min_partial_solve_wit_5 : qcp_word_min_partial_solve_wit_5.
Proof. Admitted. 

Lemma proof_of_qcp_word_min_partial_solve_wit_6_pure : qcp_word_min_partial_solve_wit_6_pure.
Proof. Admitted. 

Lemma proof_of_qcp_word_min_partial_solve_wit_6 : qcp_word_min_partial_solve_wit_6.
Proof. Admitted. 

Lemma proof_of_qcp_word_min_partial_solve_wit_7_pure : qcp_word_min_partial_solve_wit_7_pure.
Proof. Admitted. 

Lemma proof_of_qcp_word_min_partial_solve_wit_7 : qcp_word_min_partial_solve_wit_7.
Proof. Admitted. 

Lemma proof_of_qcp_word_min_partial_solve_wit_8_pure : qcp_word_min_partial_solve_wit_8_pure.
Proof. Admitted. 

Lemma proof_of_qcp_word_min_partial_solve_wit_8 : qcp_word_min_partial_solve_wit_8.
Proof. Admitted. 

Lemma proof_of_qcp_word_min_partial_solve_wit_9_pure : qcp_word_min_partial_solve_wit_9_pure.
Proof. Admitted. 

Lemma proof_of_qcp_word_min_partial_solve_wit_9 : qcp_word_min_partial_solve_wit_9.
Proof. Admitted. 

Lemma proof_of_qcp_word_max_safety_wit_1 : qcp_word_max_safety_wit_1.
Proof. Admitted. 

Lemma proof_of_qcp_word_max_safety_wit_2 : qcp_word_max_safety_wit_2.
Proof. Admitted. 

Lemma proof_of_qcp_word_max_safety_wit_3 : qcp_word_max_safety_wit_3.
Proof. Admitted. 

Lemma proof_of_qcp_word_max_safety_wit_4 : qcp_word_max_safety_wit_4.
Proof. Admitted. 

Lemma proof_of_qcp_word_max_safety_wit_5 : qcp_word_max_safety_wit_5.
Proof. Admitted. 

Lemma proof_of_qcp_word_max_safety_wit_6 : qcp_word_max_safety_wit_6.
Proof. Admitted. 

Lemma proof_of_qcp_word_max_safety_wit_7 : qcp_word_max_safety_wit_7.
Proof. Admitted. 

Lemma proof_of_qcp_word_max_safety_wit_8 : qcp_word_max_safety_wit_8.
Proof. Admitted. 

Lemma proof_of_qcp_word_max_safety_wit_9 : qcp_word_max_safety_wit_9.
Proof. Admitted. 

Lemma proof_of_qcp_word_max_safety_wit_10 : qcp_word_max_safety_wit_10.
Proof. Admitted. 

Lemma proof_of_qcp_word_max_safety_wit_11 : qcp_word_max_safety_wit_11.
Proof. Admitted. 

Lemma proof_of_qcp_word_max_safety_wit_12 : qcp_word_max_safety_wit_12.
Proof. Admitted. 

Lemma proof_of_qcp_word_max_partial_solve_wit_1_pure : qcp_word_max_partial_solve_wit_1_pure.
Proof. Admitted. 

Lemma proof_of_qcp_word_max_partial_solve_wit_1 : qcp_word_max_partial_solve_wit_1.
Proof. Admitted. 

Lemma proof_of_qcp_word_max_partial_solve_wit_2_pure : qcp_word_max_partial_solve_wit_2_pure.
Proof. Admitted. 

Lemma proof_of_qcp_word_max_partial_solve_wit_2 : qcp_word_max_partial_solve_wit_2.
Proof. Admitted. 

Lemma proof_of_qcp_word_max_partial_solve_wit_3_pure : qcp_word_max_partial_solve_wit_3_pure.
Proof. Admitted. 

Lemma proof_of_qcp_word_max_partial_solve_wit_3 : qcp_word_max_partial_solve_wit_3.
Proof. Admitted. 

Lemma proof_of_qcp_word_max_partial_solve_wit_4_pure : qcp_word_max_partial_solve_wit_4_pure.
Proof. Admitted. 

Lemma proof_of_qcp_word_max_partial_solve_wit_4 : qcp_word_max_partial_solve_wit_4.
Proof. Admitted. 

Lemma proof_of_qcp_word_max_partial_solve_wit_5_pure : qcp_word_max_partial_solve_wit_5_pure.
Proof. Admitted. 

Lemma proof_of_qcp_word_max_partial_solve_wit_5 : qcp_word_max_partial_solve_wit_5.
Proof. Admitted. 

Lemma proof_of_qcp_word_max_partial_solve_wit_6_pure : qcp_word_max_partial_solve_wit_6_pure.
Proof. Admitted. 

Lemma proof_of_qcp_word_max_partial_solve_wit_6 : qcp_word_max_partial_solve_wit_6.
Proof. Admitted. 

Lemma proof_of_qcp_word_max_partial_solve_wit_7_pure : qcp_word_max_partial_solve_wit_7_pure.
Proof. Admitted. 

Lemma proof_of_qcp_word_max_partial_solve_wit_7 : qcp_word_max_partial_solve_wit_7.
Proof. Admitted. 

Lemma proof_of_qcp_word_max_partial_solve_wit_8_pure : qcp_word_max_partial_solve_wit_8_pure.
Proof. Admitted. 

Lemma proof_of_qcp_word_max_partial_solve_wit_8 : qcp_word_max_partial_solve_wit_8.
Proof. Admitted. 

Lemma proof_of_qcp_word_max_partial_solve_wit_9_pure : qcp_word_max_partial_solve_wit_9_pure.
Proof. Admitted. 

Lemma proof_of_qcp_word_max_partial_solve_wit_9 : qcp_word_max_partial_solve_wit_9.
Proof. Admitted. 

