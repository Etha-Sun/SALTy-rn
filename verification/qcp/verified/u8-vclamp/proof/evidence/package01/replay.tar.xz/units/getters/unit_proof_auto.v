Require Import Coq.ZArith.ZArith.
Require Import Coq.Bool.Bool.
Require Import Coq.Strings.String.
Require Import Coq.Strings.Ascii.
Require Import Coq.Lists.List.
Require Import Coq.Classes.RelationClasses.
Require Import Coq.Classes.Morphisms.
Require Import Coq.micromega.Psatz.
Require Import Coq.Sorting.Permutation.
From AUXLib Require Import int_auto Axioms Feq Idents ListLib VMap.
Require Import SetsClass.SetsClass. Import SetsNotation.
From SimpleC.SL Require Import Mem SeparationLogic.
From GettersCodecVC Require Import unit_goal.
Require Import Logic.LogicGenerator.demo932.Interface.
Local Open Scope Z_scope.
Local Open Scope sets.
Local Open Scope string_scope.
Local Open Scope list.
Import Snaive_C_Rules64.
Require Import FullU8.Packed32Model.
Local Open Scope sac.

Lemma proof_of_qcp_get_word_safety_wit_1 : qcp_get_word_safety_wit_1.
Proof. Admitted. 

Lemma proof_of_qcp_get_word_safety_wit_2 : qcp_get_word_safety_wit_2.
Proof. Admitted. 

Lemma proof_of_qcp_get_word_safety_wit_3 : qcp_get_word_safety_wit_3.
Proof. Admitted. 

Lemma proof_of_qcp_get_word_safety_wit_4 : qcp_get_word_safety_wit_4.
Proof. Admitted. 

Lemma proof_of_qcp_get_word_safety_wit_5 : qcp_get_word_safety_wit_5.
Proof. Admitted. 

Lemma proof_of_qcp_get_word_safety_wit_6 : qcp_get_word_safety_wit_6.
Proof. Admitted. 

Lemma proof_of_qcp_get_word_safety_wit_7 : qcp_get_word_safety_wit_7.
Proof. Admitted. 

Lemma proof_of_qcp_get_word_safety_wit_8 : qcp_get_word_safety_wit_8.
Proof. Admitted. 

Lemma proof_of_qcp_get_word_safety_wit_9 : qcp_get_word_safety_wit_9.
Proof. Admitted. 

Lemma proof_of_qcp_get_word_safety_wit_10 : qcp_get_word_safety_wit_10.
Proof. Admitted. 

Lemma proof_of_qcp_get_word_safety_wit_11 : qcp_get_word_safety_wit_11.
Proof. Admitted. 

Lemma proof_of_qcp_get_word_safety_wit_12 : qcp_get_word_safety_wit_12.
Proof. Admitted. 

Lemma proof_of_qcp_get_word_safety_wit_13 : qcp_get_word_safety_wit_13.
Proof. Admitted. 

Lemma proof_of_qcp_get_word_safety_wit_14 : qcp_get_word_safety_wit_14.
Proof. Admitted. 

Lemma proof_of_qcp_get_word_safety_wit_15 : qcp_get_word_safety_wit_15.
Proof. Admitted. 

Lemma proof_of_qcp_get_word_safety_wit_16 : qcp_get_word_safety_wit_16.
Proof. Admitted. 

Lemma proof_of_qcp_get_word_safety_wit_17 : qcp_get_word_safety_wit_17.
Proof. Admitted. 

Lemma proof_of_qcp_get_word_safety_wit_18 : qcp_get_word_safety_wit_18.
Proof. Admitted. 

Lemma proof_of_qcp_get_word_safety_wit_19 : qcp_get_word_safety_wit_19.
Proof. Admitted. 

Lemma proof_of_qcp_get_word_safety_wit_20 : qcp_get_word_safety_wit_20.
Proof. Admitted. 

Lemma proof_of_qcp_get_word_safety_wit_21 : qcp_get_word_safety_wit_21.
Proof. Admitted. 

Lemma proof_of_qcp_get_word_safety_wit_22 : qcp_get_word_safety_wit_22.
Proof. Admitted. 

Lemma proof_of_qcp_get_word_safety_wit_23 : qcp_get_word_safety_wit_23.
Proof. Admitted. 

Lemma proof_of_qcp_get_word_safety_wit_24 : qcp_get_word_safety_wit_24.
Proof. Admitted. 

Lemma proof_of_qcp_get_word_safety_wit_25 : qcp_get_word_safety_wit_25.
Proof. Admitted. 

Lemma proof_of_qcp_get_word_safety_wit_26 : qcp_get_word_safety_wit_26.
Proof. Admitted. 

Lemma proof_of_qcp_get_word_safety_wit_27 : qcp_get_word_safety_wit_27.
Proof. Admitted. 

Lemma proof_of_qcp_get_word_safety_wit_28 : qcp_get_word_safety_wit_28.
Proof. Admitted. 

Lemma proof_of_qcp_get_word_safety_wit_29 : qcp_get_word_safety_wit_29.
Proof. Admitted. 

Lemma proof_of_qcp_get_word_safety_wit_30 : qcp_get_word_safety_wit_30.
Proof. Admitted. 

Lemma proof_of_qcp_get_word_safety_wit_31 : qcp_get_word_safety_wit_31.
Proof. Admitted. 

Lemma proof_of_qcp_get_word_return_wit_2 : qcp_get_word_return_wit_2.
Proof. Admitted. 

Lemma proof_of_qcp_get_word_return_wit_3 : qcp_get_word_return_wit_3.
Proof. Admitted. 

Lemma proof_of_qcp_get_word_return_wit_4 : qcp_get_word_return_wit_4.
Proof. Admitted. 

Lemma proof_of_qcp_get_word_return_wit_5 : qcp_get_word_return_wit_5.
Proof. Admitted. 

Lemma proof_of_qcp_get_word_return_wit_6 : qcp_get_word_return_wit_6.
Proof. Admitted. 

Lemma proof_of_qcp_get_word_return_wit_7 : qcp_get_word_return_wit_7.
Proof. Admitted. 

Lemma proof_of_qcp_get_word_return_wit_8 : qcp_get_word_return_wit_8.
Proof. Admitted. 

Lemma proof_of_qcp_get_word_return_wit_9 : qcp_get_word_return_wit_9.
Proof. Admitted. 

Lemma proof_of_qcp_get_word_return_wit_10 : qcp_get_word_return_wit_10.
Proof. Admitted. 

Lemma proof_of_qcp_get_word_return_wit_11 : qcp_get_word_return_wit_11.
Proof. Admitted. 

Lemma proof_of_qcp_get_word_return_wit_12 : qcp_get_word_return_wit_12.
Proof. Admitted. 

Lemma proof_of_qcp_get_word_return_wit_13 : qcp_get_word_return_wit_13.
Proof. Admitted. 

Lemma proof_of_qcp_get_word_return_wit_14 : qcp_get_word_return_wit_14.
Proof. Admitted. 

Lemma proof_of_qcp_get_word_return_wit_15 : qcp_get_word_return_wit_15.
Proof. Admitted. 

Lemma proof_of_qcp_get_word_return_wit_16 : qcp_get_word_return_wit_16.
Proof. Admitted. 

Lemma proof_of_qcp_get_word_return_wit_17 : qcp_get_word_return_wit_17.
Proof. Admitted. 

Lemma proof_of_qcp_get_word_return_wit_18 : qcp_get_word_return_wit_18.
Proof. Admitted. 

Lemma proof_of_qcp_get_word_return_wit_19 : qcp_get_word_return_wit_19.
Proof. Admitted. 

Lemma proof_of_qcp_get_word_return_wit_20 : qcp_get_word_return_wit_20.
Proof. Admitted. 

Lemma proof_of_qcp_get_word_return_wit_21 : qcp_get_word_return_wit_21.
Proof. Admitted. 

Lemma proof_of_qcp_get_word_return_wit_22 : qcp_get_word_return_wit_22.
Proof. Admitted. 

Lemma proof_of_qcp_get_word_return_wit_23 : qcp_get_word_return_wit_23.
Proof. Admitted. 

Lemma proof_of_qcp_get_word_return_wit_24 : qcp_get_word_return_wit_24.
Proof. Admitted. 

Lemma proof_of_qcp_get_word_return_wit_25 : qcp_get_word_return_wit_25.
Proof. Admitted. 

Lemma proof_of_qcp_get_word_return_wit_26 : qcp_get_word_return_wit_26.
Proof. Admitted. 

Lemma proof_of_qcp_get_word_return_wit_27 : qcp_get_word_return_wit_27.
Proof. Admitted. 

Lemma proof_of_qcp_get_word_return_wit_28 : qcp_get_word_return_wit_28.
Proof. Admitted. 

Lemma proof_of_qcp_get_word_return_wit_29 : qcp_get_word_return_wit_29.
Proof. Admitted. 

Lemma proof_of_qcp_get_word_return_wit_30 : qcp_get_word_return_wit_30.
Proof. Admitted. 

Lemma proof_of_qcp_get_word_return_wit_31 : qcp_get_word_return_wit_31.
Proof. Admitted. 

Lemma proof_of_qcp_get_word_return_wit_32 : qcp_get_word_return_wit_32.
Proof. Admitted. 

Lemma proof_of_qcp_get_byte_safety_wit_1 : qcp_get_byte_safety_wit_1.
Proof. Admitted. 

Lemma proof_of_qcp_get_byte_safety_wit_2 : qcp_get_byte_safety_wit_2.
Proof. Admitted. 

Lemma proof_of_qcp_get_byte_safety_wit_3 : qcp_get_byte_safety_wit_3.
Proof. Admitted. 

Lemma proof_of_qcp_get_byte_safety_wit_4 : qcp_get_byte_safety_wit_4.
Proof. Admitted. 

Lemma proof_of_qcp_get_byte_partial_solve_wit_1 : qcp_get_byte_partial_solve_wit_1.
Proof. Admitted. 

Lemma proof_of_qcp_get_byte_partial_solve_wit_2 : qcp_get_byte_partial_solve_wit_2.
Proof. Admitted. 

