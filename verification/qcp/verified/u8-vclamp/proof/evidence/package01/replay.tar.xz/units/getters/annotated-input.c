typedef unsigned long long size_t;
typedef unsigned char uint8_t;
typedef unsigned int uint32_t;
typedef struct vuint8m8_t {uint32_t w0;uint32_t w1;uint32_t w2;uint32_t w3;uint32_t w4;uint32_t w5;uint32_t w6;uint32_t w7;uint32_t w8;uint32_t w9;uint32_t w10;uint32_t w11;uint32_t w12;uint32_t w13;uint32_t w14;uint32_t w15;uint32_t w16;uint32_t w17;uint32_t w18;uint32_t w19;uint32_t w20;uint32_t w21;uint32_t w22;uint32_t w23;uint32_t w24;uint32_t w25;uint32_t w26;uint32_t w27;uint32_t w28;uint32_t w29;uint32_t w30;uint32_t w31;} vuint8m8_t;
/*@ Import Coq Require Import FullU8.Packed32Model */
/*@ Extern Coq (word_byte:Z->Z->Z) (vec_byte:list Z->Z->Z) */
unsigned char qcp_word_byte(uint32_t w,uint32_t lane)
/*@ Require 0<=lane && lane<4 Ensure __return==word_byte(w,lane) && 0<=__return && __return<=255 */
;
uint32_t qcp_get_word(const vuint8m8_t*a,size_t i)
/*@ With (x0:Z) (x1:Z) (x2:Z) (x3:Z) (x4:Z) (x5:Z) (x6:Z) (x7:Z) (x8:Z) (x9:Z) (x10:Z) (x11:Z) (x12:Z) (x13:Z) (x14:Z) (x15:Z) (x16:Z) (x17:Z) (x18:Z) (x19:Z) (x20:Z) (x21:Z) (x22:Z) (x23:Z) (x24:Z) (x25:Z) (x26:Z) (x27:Z) (x28:Z) (x29:Z) (x30:Z) (x31:Z) Require 0<=i && i<32 && store(&(a->w0),unsigned int,x0) * store(&(a->w1),unsigned int,x1) * store(&(a->w2),unsigned int,x2) * store(&(a->w3),unsigned int,x3) * store(&(a->w4),unsigned int,x4) * store(&(a->w5),unsigned int,x5) * store(&(a->w6),unsigned int,x6) * store(&(a->w7),unsigned int,x7) * store(&(a->w8),unsigned int,x8) * store(&(a->w9),unsigned int,x9) * store(&(a->w10),unsigned int,x10) * store(&(a->w11),unsigned int,x11) * store(&(a->w12),unsigned int,x12) * store(&(a->w13),unsigned int,x13) * store(&(a->w14),unsigned int,x14) * store(&(a->w15),unsigned int,x15) * store(&(a->w16),unsigned int,x16) * store(&(a->w17),unsigned int,x17) * store(&(a->w18),unsigned int,x18) * store(&(a->w19),unsigned int,x19) * store(&(a->w20),unsigned int,x20) * store(&(a->w21),unsigned int,x21) * store(&(a->w22),unsigned int,x22) * store(&(a->w23),unsigned int,x23) * store(&(a->w24),unsigned int,x24) * store(&(a->w25),unsigned int,x25) * store(&(a->w26),unsigned int,x26) * store(&(a->w27),unsigned int,x27) * store(&(a->w28),unsigned int,x28) * store(&(a->w29),unsigned int,x29) * store(&(a->w30),unsigned int,x30) * store(&(a->w31),unsigned int,x31) Ensure store(&(a->w0),unsigned int,x0) * store(&(a->w1),unsigned int,x1) * store(&(a->w2),unsigned int,x2) * store(&(a->w3),unsigned int,x3) * store(&(a->w4),unsigned int,x4) * store(&(a->w5),unsigned int,x5) * store(&(a->w6),unsigned int,x6) * store(&(a->w7),unsigned int,x7) * store(&(a->w8),unsigned int,x8) * store(&(a->w9),unsigned int,x9) * store(&(a->w10),unsigned int,x10) * store(&(a->w11),unsigned int,x11) * store(&(a->w12),unsigned int,x12) * store(&(a->w13),unsigned int,x13) * store(&(a->w14),unsigned int,x14) * store(&(a->w15),unsigned int,x15) * store(&(a->w16),unsigned int,x16) * store(&(a->w17),unsigned int,x17) * store(&(a->w18),unsigned int,x18) * store(&(a->w19),unsigned int,x19) * store(&(a->w20),unsigned int,x20) * store(&(a->w21),unsigned int,x21) * store(&(a->w22),unsigned int,x22) * store(&(a->w23),unsigned int,x23) * store(&(a->w24),unsigned int,x24) * store(&(a->w25),unsigned int,x25) * store(&(a->w26),unsigned int,x26) * store(&(a->w27),unsigned int,x27) * store(&(a->w28),unsigned int,x28) * store(&(a->w29),unsigned int,x29) * store(&(a->w30),unsigned int,x30) * store(&(a->w31),unsigned int,x31) * (__return==(cons(x0,cons(x1,cons(x2,cons(x3,cons(x4,cons(x5,cons(x6,cons(x7,cons(x8,cons(x9,cons(x10,cons(x11,cons(x12,cons(x13,cons(x14,cons(x15,cons(x16,cons(x17,cons(x18,cons(x19,cons(x20,cons(x21,cons(x22,cons(x23,cons(x24,cons(x25,cons(x26,cons(x27,cons(x28,cons(x29,cons(x30,cons(x31,nil)))))))))))))))))))))))))))))))))[i]) */
{if(i==0)return a->w0;
if(i==1)return a->w1;
if(i==2)return a->w2;
if(i==3)return a->w3;
if(i==4)return a->w4;
if(i==5)return a->w5;
if(i==6)return a->w6;
if(i==7)return a->w7;
if(i==8)return a->w8;
if(i==9)return a->w9;
if(i==10)return a->w10;
if(i==11)return a->w11;
if(i==12)return a->w12;
if(i==13)return a->w13;
if(i==14)return a->w14;
if(i==15)return a->w15;
if(i==16)return a->w16;
if(i==17)return a->w17;
if(i==18)return a->w18;
if(i==19)return a->w19;
if(i==20)return a->w20;
if(i==21)return a->w21;
if(i==22)return a->w22;
if(i==23)return a->w23;
if(i==24)return a->w24;
if(i==25)return a->w25;
if(i==26)return a->w26;
if(i==27)return a->w27;
if(i==28)return a->w28;
if(i==29)return a->w29;
if(i==30)return a->w30;
return a->w31;}

unsigned char qcp_get_byte(const vuint8m8_t*a,size_t i)
/*@ With (x0:Z) (x1:Z) (x2:Z) (x3:Z) (x4:Z) (x5:Z) (x6:Z) (x7:Z) (x8:Z) (x9:Z) (x10:Z) (x11:Z) (x12:Z) (x13:Z) (x14:Z) (x15:Z) (x16:Z) (x17:Z) (x18:Z) (x19:Z) (x20:Z) (x21:Z) (x22:Z) (x23:Z) (x24:Z) (x25:Z) (x26:Z) (x27:Z) (x28:Z) (x29:Z) (x30:Z) (x31:Z) Require 0<=i && i<128 && store(&(a->w0),unsigned int,x0) * store(&(a->w1),unsigned int,x1) * store(&(a->w2),unsigned int,x2) * store(&(a->w3),unsigned int,x3) * store(&(a->w4),unsigned int,x4) * store(&(a->w5),unsigned int,x5) * store(&(a->w6),unsigned int,x6) * store(&(a->w7),unsigned int,x7) * store(&(a->w8),unsigned int,x8) * store(&(a->w9),unsigned int,x9) * store(&(a->w10),unsigned int,x10) * store(&(a->w11),unsigned int,x11) * store(&(a->w12),unsigned int,x12) * store(&(a->w13),unsigned int,x13) * store(&(a->w14),unsigned int,x14) * store(&(a->w15),unsigned int,x15) * store(&(a->w16),unsigned int,x16) * store(&(a->w17),unsigned int,x17) * store(&(a->w18),unsigned int,x18) * store(&(a->w19),unsigned int,x19) * store(&(a->w20),unsigned int,x20) * store(&(a->w21),unsigned int,x21) * store(&(a->w22),unsigned int,x22) * store(&(a->w23),unsigned int,x23) * store(&(a->w24),unsigned int,x24) * store(&(a->w25),unsigned int,x25) * store(&(a->w26),unsigned int,x26) * store(&(a->w27),unsigned int,x27) * store(&(a->w28),unsigned int,x28) * store(&(a->w29),unsigned int,x29) * store(&(a->w30),unsigned int,x30) * store(&(a->w31),unsigned int,x31) Ensure store(&(a->w0),unsigned int,x0) * store(&(a->w1),unsigned int,x1) * store(&(a->w2),unsigned int,x2) * store(&(a->w3),unsigned int,x3) * store(&(a->w4),unsigned int,x4) * store(&(a->w5),unsigned int,x5) * store(&(a->w6),unsigned int,x6) * store(&(a->w7),unsigned int,x7) * store(&(a->w8),unsigned int,x8) * store(&(a->w9),unsigned int,x9) * store(&(a->w10),unsigned int,x10) * store(&(a->w11),unsigned int,x11) * store(&(a->w12),unsigned int,x12) * store(&(a->w13),unsigned int,x13) * store(&(a->w14),unsigned int,x14) * store(&(a->w15),unsigned int,x15) * store(&(a->w16),unsigned int,x16) * store(&(a->w17),unsigned int,x17) * store(&(a->w18),unsigned int,x18) * store(&(a->w19),unsigned int,x19) * store(&(a->w20),unsigned int,x20) * store(&(a->w21),unsigned int,x21) * store(&(a->w22),unsigned int,x22) * store(&(a->w23),unsigned int,x23) * store(&(a->w24),unsigned int,x24) * store(&(a->w25),unsigned int,x25) * store(&(a->w26),unsigned int,x26) * store(&(a->w27),unsigned int,x27) * store(&(a->w28),unsigned int,x28) * store(&(a->w29),unsigned int,x29) * store(&(a->w30),unsigned int,x30) * store(&(a->w31),unsigned int,x31) * (__return==vec_byte(cons(x0,cons(x1,cons(x2,cons(x3,cons(x4,cons(x5,cons(x6,cons(x7,cons(x8,cons(x9,cons(x10,cons(x11,cons(x12,cons(x13,cons(x14,cons(x15,cons(x16,cons(x17,cons(x18,cons(x19,cons(x20,cons(x21,cons(x22,cons(x23,cons(x24,cons(x25,cons(x26,cons(x27,cons(x28,cons(x29,cons(x30,cons(x31,nil)))))))))))))))))))))))))))))))),i)) */
{return qcp_word_byte(qcp_get_word(a,i/4),(uint32_t)(i%4));}

