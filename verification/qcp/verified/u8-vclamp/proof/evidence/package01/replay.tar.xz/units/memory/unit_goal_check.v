From MemoryCodecVC Require Import unit_goal unit_proof_auto unit_proof_manual.

Module VC_Correctness : VC_Correct.
  Include arrays_strategy_proof.
  Include unit_proof_auto.
  Include unit_proof_manual.
End VC_Correctness.
