#ifndef QCP_U8_ORIGINAL_SPEC_H
#define QCP_U8_ORIGINAL_SPEC_H
#include "case_types.h"
#include "../src/arrays.h"
/* Modular declarations correspond to the preserved original definitions.
   Their implementation VC closures remain mandatory; declarations alone are not proof. */
void test_neon(size_t batch,const uint8_t*input,uint8_t*output,const struct xnn_u8_minmax_params*restrict params)
/*@ With (A:list Z) (lo:Z) (hi:Z)
 Require 0<batch && batch<=18446744073709551608 && input!=0 && output!=0 && params!=0 &&
 UCharArray::full(input,batch+7,A) * UCharArray::undef_full(output,batch) *
 store(&(params->scalar.min),unsigned int,lo) * store(&(params->scalar.max),unsigned int,hi)
 Ensure UCharArray::full(input@pre,batch@pre+7,A) *
 UCharArray::full(output@pre,batch@pre,u8_phase_all(batch@pre,u8_bound(lo),u8_bound(hi),A)) *
 store(&(params->scalar.min),unsigned int,lo) * store(&(params->scalar.max),unsigned int,hi) */;
void test_rvv(size_t batch,const uint8_t*input,uint8_t*output,const struct xnn_u8_minmax_params*params)
/*@ With (A:list Z) (lo:Z) (hi:Z)
 Require 0<batch && batch<=18446744073709551608 && input!=0 && output!=0 && params!=0 &&
 UCharArray::full(input,batch+7,A) * UCharArray::undef_full(output,batch) *
 store(&(params->scalar.min),unsigned int,lo) * store(&(params->scalar.max),unsigned int,hi)
 Ensure UCharArray::full(input@pre,batch@pre+7,A) *
 UCharArray::full(output@pre,batch@pre,u8_phase_all(batch@pre,u8_bound(lo),u8_bound(hi),A)) *
 store(&(params->scalar.min),unsigned int,lo) * store(&(params->scalar.max),unsigned int,hi) */;
int equivalent(size_t n,const uint8_t*input,uint8_t*left,uint8_t*right,const struct xnn_u8_minmax_params*params)
/*@ With (A:list Z) (lo:Z) (hi:Z)
 Require 0<n && n<=18446744073709551608 && input!=0 && left!=0 && right!=0 && params!=0 &&
 UCharArray::full(input,n+7,A) * UCharArray::undef_full(left,n) * UCharArray::undef_full(right,n) *
 store(&(params->scalar.min),unsigned int,lo) * store(&(params->scalar.max),unsigned int,hi)
 Ensure __return==1 && UCharArray::full(input,n+7,A) *
 UCharArray::full(left,n,u8_phase_all(n,u8_bound(lo),u8_bound(hi),A)) *
 UCharArray::full(right,n,u8_phase_all(n,u8_bound(lo),u8_bound(hi),A)) *
 store(&(params->scalar.min),unsigned int,lo) * store(&(params->scalar.max),unsigned int,hi) */;
#endif
