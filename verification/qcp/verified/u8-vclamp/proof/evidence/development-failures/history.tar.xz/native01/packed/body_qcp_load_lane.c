#define QCP_IMPLEMENT_qcp_load_lane
#include "packed.h"
unsigned char qcp_load_lane(const unsigned char*p,size_t vl,size_t i)
/*@ With (A:list Z) (n:Z) Require 0<vl && vl<=128 && vl<=n && n<=18446744073709551615 && 0<=i && i<128 && UCharArray::full(p,n,A)
 Ensure UCharArray::full(p,n,A) * (__return==lane_load(A,vl,i) && 0<=__return && __return<=255) */
{if(i<vl)return p[i];return 0;}
