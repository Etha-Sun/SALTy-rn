#define QCP_IMPLEMENT_qcp_u8_min
#include "packed.h"
unsigned char qcp_u8_min(unsigned char x,unsigned char y)
/*@ Require emp Ensure __return==u8_min(x,y) */
{if(x<y)return x;return y;}
