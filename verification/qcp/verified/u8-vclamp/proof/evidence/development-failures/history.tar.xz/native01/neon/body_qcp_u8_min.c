#define QCP_IMPLEMENT_qcp_u8_min
#include "rvv_shim.h"
unsigned char qcp_u8_min(unsigned char x,unsigned char y)
/*@ Require 0<=x && x<=255 && 0<=y && y<=255 Ensure __return==u8_min(x,y) */
{if(x<y)return x;return y;}
