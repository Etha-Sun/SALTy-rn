#define QCP_IMPLEMENT_qcp_word_byte
#include "packed.h"
unsigned char qcp_word_byte(uint32_t w,uint32_t lane)
/*@ Require 0<=lane && lane<4 Ensure __return==word_byte(w,lane) && 0<=__return && __return<=255 */
{return(unsigned char)(w>>(8U*lane));}
