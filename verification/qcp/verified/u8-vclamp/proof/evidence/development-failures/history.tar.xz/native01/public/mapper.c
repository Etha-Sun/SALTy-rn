#include "spec.h"
int equivalent(size_t n,const uint8_t*input,uint8_t*left,uint8_t*right,const struct xnn_u8_minmax_params*params)
/*@ With (A:list Z) (lo:Z) (hi:Z)
 Require 0<n && n<=18446744073709551608 && input!=0 && left!=0 && right!=0 && params!=0 &&
 UCharArray::full(input,n+7,A) * UCharArray::undef_full(left,n) * UCharArray::undef_full(right,n) *
 store(&(params->scalar.min),unsigned int,lo) * store(&(params->scalar.max),unsigned int,hi)
 Ensure __return==1 && UCharArray::full(input,n+7,A) *
 UCharArray::full(left,n,u8_phase_all(n,u8_bound(lo),u8_bound(hi),A)) *
 UCharArray::full(right,n,u8_phase_all(n,u8_bound(lo),u8_bound(hi),A)) *
 store(&(params->scalar.min),unsigned int,lo) * store(&(params->scalar.max),unsigned int,hi) */
{
 test_neon(n,input,left,params);
 test_rvv(n,input,right,params);
 size_t i;
 /*@ Inv 0<=i && i<=n && n==n@pre && input==input@pre && left==left@pre && right==right@pre && params==params@pre &&
 UCharArray::full(input,n+7,A) *
 UCharArray::full(left,n,u8_phase_all(n,u8_bound(lo),u8_bound(hi),A)) *
 UCharArray::full(right,n,u8_phase_all(n,u8_bound(lo),u8_bound(hi),A)) *
 store(&(params->scalar.min),unsigned int,lo) * store(&(params->scalar.max),unsigned int,hi) */
 for(i=0;i<n;++i){if(left[i]!=right[i])return 0;}
 return 1;
}
