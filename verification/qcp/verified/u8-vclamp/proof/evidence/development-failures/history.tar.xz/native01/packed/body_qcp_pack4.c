#define QCP_IMPLEMENT_qcp_pack4
#include "packed.h"
uint32_t qcp_pack4(unsigned char a,unsigned char b,unsigned char c,unsigned char d)
/*@ Require 0<=a && a<=255 && 0<=b && b<=255 && 0<=c && c<=255 && 0<=d && d<=255 Ensure __return==pack4(a,b,c,d) && 0<=__return && __return<=4294967295 */
{return (unsigned int)a+256U*b+65536U*c+16777216U*d;}
