#define QCP_IMPLEMENT_qcp_load_word
#include "packed.h"
uint32_t qcp_load_word(const unsigned char*p,size_t vl,size_t wi)
/*@ With (A:list Z) (n:Z) Require 0<vl && vl<=128 && vl<=n && n<=18446744073709551615 && 0<=wi && wi<32 && UCharArray::full(p,n,A)
 Ensure UCharArray::full(p,n,A) * (__return==word_load(A,vl,wi) && 0<=__return && __return<=4294967295) */
{return qcp_pack4(qcp_load_lane(p,vl,4*wi),qcp_load_lane(p,vl,4*wi+1),qcp_load_lane(p,vl,4*wi+2),qcp_load_lane(p,vl,4*wi+3));}
