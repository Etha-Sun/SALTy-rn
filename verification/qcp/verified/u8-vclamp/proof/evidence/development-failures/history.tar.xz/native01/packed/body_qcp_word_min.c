#define QCP_IMPLEMENT_qcp_word_min
#include "packed.h"
uint32_t qcp_word_min(uint32_t w,unsigned char y,size_t vl,size_t wi)
/*@ Require 0<=y && y<=255 && 0<vl && vl<=128 && 0<=wi && wi<32 Ensure __return==word_min(w,y,vl,wi) && 0<=__return && __return<=4294967295 */
{return qcp_pack4(qcp_active_min(qcp_word_byte(w,0),y,vl,4*wi+0),qcp_active_min(qcp_word_byte(w,1),y,vl,4*wi+1),qcp_active_min(qcp_word_byte(w,2),y,vl,4*wi+2),qcp_active_min(qcp_word_byte(w,3),y,vl,4*wi+3));}
