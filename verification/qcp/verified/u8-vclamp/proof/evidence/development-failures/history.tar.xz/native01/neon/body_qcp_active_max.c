#define QCP_IMPLEMENT_qcp_active_max
#include "rvv_shim.h"
unsigned char qcp_active_max(unsigned char x,unsigned char y,size_t vl,size_t i)
/*@ Require 0<=x && x<=255 && 0<=y && y<=255 && 0<vl && vl<=128 && 0<=i && i<128 Ensure __return==rvv_active_max(x,y,vl,i) */
{if(i<vl)return qcp_u8_max(x,y);return x;}
