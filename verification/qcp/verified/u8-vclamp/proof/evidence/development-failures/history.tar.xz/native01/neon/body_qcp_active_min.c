#define QCP_IMPLEMENT_qcp_active_min
#include "rvv_shim.h"
unsigned char qcp_active_min(unsigned char x,unsigned char y,size_t vl,size_t i)
/*@ Require 0<=x && x<=255 && 0<=y && y<=255 && 0<vl && vl<=128 && 0<=i && i<128 Ensure __return==rvv_active_min(x,y,vl,i) */
{if(i<vl)return qcp_u8_min(x,y);return x;}
