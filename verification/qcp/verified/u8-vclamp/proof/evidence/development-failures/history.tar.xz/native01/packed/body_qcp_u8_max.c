#define QCP_IMPLEMENT_qcp_u8_max
#include "packed.h"
unsigned char qcp_u8_max(unsigned char x,unsigned char y)
/*@ Require emp Ensure __return==u8_max(x,y) */
{if(x<y)return y;return x;}
