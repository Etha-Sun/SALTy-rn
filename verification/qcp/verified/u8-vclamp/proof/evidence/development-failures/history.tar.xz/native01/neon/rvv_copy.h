/*@ Import Coq Require Import FullU8.RvvLayout */
/*@ Extern Coq (UndefStructPredvuint8m8_t:Z->Assertion) */
/*@ include strategies "rvv_copy.strategies" */
