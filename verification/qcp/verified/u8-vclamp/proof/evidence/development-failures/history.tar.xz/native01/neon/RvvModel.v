From Coq Require Import ZArith List.
From AUXLib Require Import ListLib.
From FullU8 Require Import U8Logic.
Local Open Scope Z_scope.
Definition rvv_lane(A:list Z)(vl i:Z):Z:=if Z.ltb i vl then Znth i A 0 else 0.
Definition rvv_active_min(x y vl i:Z):Z:=if Z.ltb i vl then u8_min x y else x.
Definition rvv_active_max(x y vl i:Z):Z:=if Z.ltb i vl then u8_max x y else x.
