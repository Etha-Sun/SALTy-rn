/*@ Import Coq Require Import SpmmSpec.TupleMemory */
struct float32x4_t {float s0;float s1;float s2;float s3;};
typedef struct float32x4_t float32x4_t;
struct float32x4x2_t {float32x4_t val[2];};
typedef struct float32x4x2_t float32x4x2_t;
/*@ Extern Coq Record Recordfloat32x4_t { f0:fp32; f1:fp32; f2:fp32; f3:fp32; } */
/*@ Extern Coq Record Recordfloat32x4x2_t { tuple_values:list Recordfloat32x4_t; } */
/*@ Extern Coq
 (tuple_record:list Recordfloat32x4_t -> Recordfloat32x4x2_t)
 (tuple_values:Recordfloat32x4x2_t -> list Recordfloat32x4_t)
 (vec4: fp32 -> fp32 -> fp32 -> fp32 -> Recordfloat32x4_t)
 (f0: Recordfloat32x4_t -> fp32) (f1: Recordfloat32x4_t -> fp32)
 (f2: Recordfloat32x4_t -> fp32) (f3: Recordfloat32x4_t -> fp32)
 (veczero:Recordfloat32x4_t)
 (StructPredfloat32x4x2_t:Z -> Recordfloat32x4x2_t -> Assertion)
 (UndefStructPredfloat32x4_t: Z -> Assertion)
 (UndefStructPredfloat32x4x2_t: Z -> Assertion)
 (Structfloat32x4_tArray::full: Z -> Z -> list Recordfloat32x4_t -> Assertion)
 (Structfloat32x4_tArray::undef_full: Z -> Z -> Assertion)
 (cons:{A} -> A -> list A -> list A) (nil:{A} -> list A)
 (tuple_at: Z -> list Recordfloat32x4_t -> Recordfloat32x4_t)
*/
/*@ include strategies "tuple.strategies" */
/*@ Import Coq Require Import GemmSpec.FmaModel */
/*@ Extern Coq (bit_same:fp32 -> fp32 -> Prop) */
float qcp_identity(float x)
/*@ Require emp Ensure bit_same(__return,x) && emp */;
void qcp_assert(int condition)
/*@ Require condition!=0 && emp Ensure emp */;
/* Source-reviewed GNU builtin. Cache/performance effects are not data-memory
   observations; the caller still proves evaluation of its address expression. */
void __builtin_prefetch(const void *address)
/*@ Require emp Ensure emp */;
void xnn_prefetch_to_l1(const void *address)
/*@ Require emp Ensure emp */;
typedef unsigned long long size_t;
typedef unsigned long long uintptr_t;
typedef long long intptr_t;
typedef int int32_t;
typedef unsigned int uint32_t;
struct scalar_bounds {float min;float max;};
struct xnn_f32_minmax_params {struct scalar_bounds scalar;};
struct float32x2_t {float s0;float s1;};
typedef struct float32x2_t float32x2_t;
struct vfloat32m8_t {float s0;float s1;float s2;float s3;float s4;float s5;float s6;float s7;float s8;float s9;float s10;float s11;float s12;float s13;float s14;float s15;float s16;float s17;float s18;float s19;float s20;float s21;float s22;float s23;float s24;float s25;float s26;float s27;float s28;float s29;float s30;float s31;};
typedef struct vfloat32m8_t vfloat32m8_t;
struct vbool4_t {int s0;int s1;int s2;int s3;int s4;int s5;int s6;int s7;int s8;int s9;int s10;int s11;int s12;int s13;int s14;int s15;int s16;int s17;int s18;int s19;int s20;int s21;int s22;int s23;int s24;int s25;int s26;int s27;int s28;int s29;int s30;int s31;};
typedef struct vbool4_t vbool4_t;
/*@ Import Coq Require Import SpmmSpec.Model SpmmSpec.Vectors */
/*@ Extern Coq
 (FloatArray::full:Z -> Z -> list fp32 -> Assertion)
 (FloatArray::seg:Z -> Z -> Z -> list fp32 -> Assertion)
 (FloatArray::undef_full:Z -> Z -> Assertion)
 (spmm_get:Z -> list fp32 -> fp32)
 (bit_same:fp32 -> fp32 -> Prop)
 (fma_rne:fp32 -> fp32 -> fp32 -> fp32)
 (fp32_neon_min:fp32 -> fp32 -> fp32) (fp32_neon_max:fp32 -> fp32 -> fp32)
 (fp32_min_number:fp32 -> fp32 -> fp32) (fp32_max_number:fp32 -> fp32 -> fp32)
 (canonical_qnan:fp32) (spmm_nanth:fp32 -> Z) (spmm_merge:fp32 -> fp32 -> Z -> fp32)
 (spmm_vl_allowed:Z -> Z -> Prop)
 (UndefStructPredfloat32x2_t:Z -> Assertion)
 (UndefStructPredvfloat32m8_t:Z -> Assertion) (UndefStructPredvbool4_t:Z -> Assertion)
 (spmm_active32:Z -> fp32 -> fp32 -> fp32 -> fp32 -> fp32 -> fp32 -> fp32 -> fp32 -> fp32 -> fp32 -> fp32 -> fp32 -> fp32 -> fp32 -> fp32 -> fp32 -> fp32 -> fp32 -> fp32 -> fp32 -> fp32 -> fp32 -> fp32 -> fp32 -> fp32 -> fp32 -> fp32 -> fp32 -> fp32 -> fp32 -> fp32 -> fp32 -> fp32 -> fp32 -> fp32 -> fp32 -> fp32 -> fp32 -> fp32 -> fp32 -> fp32 -> fp32 -> fp32 -> fp32 -> fp32 -> fp32 -> fp32 -> fp32 -> fp32 -> fp32 -> fp32 -> fp32 -> fp32 -> fp32 -> fp32 -> fp32 -> fp32 -> fp32 -> fp32 -> fp32 -> fp32 -> fp32 -> fp32 -> fp32 -> Prop)
 (spmm_mask32:Z -> Z -> Z -> Z -> Z -> Z -> Z -> Z -> Z -> Z -> Z -> Z -> Z -> Z -> Z -> Z -> Z -> Z -> Z -> Z -> Z -> Z -> Z -> Z -> Z -> Z -> Z -> Z -> Z -> Z -> Z -> Z -> Z -> Z -> Z -> Z -> Z -> Z -> Z -> Z -> Z -> Z -> Z -> Z -> Z -> Z -> Z -> Z -> Z -> Z -> Z -> Z -> Z -> Z -> Z -> Z -> Z -> Z -> Z -> Z -> Z -> Z -> Z -> Z -> Z -> Prop)
*/
/*@ include strategies "vectors.strategies" */
/*@ Import Coq Require Import SpmmSpec.Memory */
/*@ Extern Coq
 (spmm_shape:Z -> Z -> Z -> list Z -> list Z -> list fp32 -> list fp32 -> Prop)
 (spmm_capacity:Z -> Z -> Z -> Z -> Z -> Z -> Z -> Z -> list Z -> list Z -> list fp32 -> list fp32 -> Prop)
 (spmm_output:Z -> Z -> Z -> Z -> Z -> Z -> Z -> Z -> list Z -> list Z -> list fp32 -> list fp32 -> fp32 -> fp32 -> Assertion)
 (spmm_output_hole:Z -> Z -> Z -> Z -> Z -> Z -> Z -> Z -> list Z -> list Z -> list fp32 -> list fp32 -> fp32 -> fp32 -> Assertion)
 (spmm_acc:Z -> Z -> Z -> Z -> list Z -> list Z -> list fp32 -> list fp32 -> fp32)
 (spmm_cell:Z -> Z -> Z -> list Z -> list Z -> list fp32 -> list fp32 -> fp32 -> fp32 -> fp32)
 (spmm_column_prefix:Z -> Z -> Z -> list Z -> list Z -> list fp32 -> list fp32 -> fp32 -> fp32 -> list fp32)
 (IntArray::full:Z -> Z -> list Z -> Assertion)
 (UIntArray::full:Z -> Z -> list Z -> Assertion)
 (FloatArray::missing_i:Z -> Z -> Z -> Z -> list fp32 -> Assertion)
 (prefix_sum:list Z -> Z -> Z) (nnz_before:list Z -> Z -> Z)
 (bias_index:list Z -> Z -> Z) (input_index:list Z -> Z -> Z -> Z -> Z)
 (fp_at:list fp32 -> Z -> fp32) (z_at:list Z -> Z -> Z)
 (word64:Z -> Z) (modulus64:Z)
 (spmm_output_cursor:Z -> Z -> Z -> Z -> Z)
*/
size_t __riscv_vsetvl_e32m8(size_t n)
/*@ Require 1<=n && emp
 Ensure spmm_vl_allowed(n,__return) && emp */;
float qcp_nanf(void)
/*@ Require emp
 Ensure bit_same(__return,canonical_qnan) && emp */;
vfloat32m8_t __riscv_vle32_v_f32m8(const float*p,size_t vl)
/*@ With (base:Z) (len:Z) (j:Z) (L:list fp32)
 Require 1<=vl && vl<=32 && p==pointer_offset(base,j,float) && 0<=j && j+vl<=len && FloatArray::full(base,len,L)
 Ensure exists z0 z1 z2 z3 z4 z5 z6 z7 z8 z9 z10 z11 z12 z13 z14 z15 z16 z17 z18 z19 z20 z21 z22 z23 z24 z25 z26 z27 z28 z29 z30 z31, spmm_active32(vl,z0,z1,z2,z3,z4,z5,z6,z7,z8,z9,z10,z11,z12,z13,z14,z15,z16,z17,z18,z19,z20,z21,z22,z23,z24,z25,z26,z27,z28,z29,z30,z31,spmm_get(j+0,L),spmm_get(j+1,L),spmm_get(j+2,L),spmm_get(j+3,L),spmm_get(j+4,L),spmm_get(j+5,L),spmm_get(j+6,L),spmm_get(j+7,L),spmm_get(j+8,L),spmm_get(j+9,L),spmm_get(j+10,L),spmm_get(j+11,L),spmm_get(j+12,L),spmm_get(j+13,L),spmm_get(j+14,L),spmm_get(j+15,L),spmm_get(j+16,L),spmm_get(j+17,L),spmm_get(j+18,L),spmm_get(j+19,L),spmm_get(j+20,L),spmm_get(j+21,L),spmm_get(j+22,L),spmm_get(j+23,L),spmm_get(j+24,L),spmm_get(j+25,L),spmm_get(j+26,L),spmm_get(j+27,L),spmm_get(j+28,L),spmm_get(j+29,L),spmm_get(j+30,L),spmm_get(j+31,L)) && store(&(__return.s0),float,z0) * store(&(__return.s1),float,z1) * store(&(__return.s2),float,z2) * store(&(__return.s3),float,z3) * store(&(__return.s4),float,z4) * store(&(__return.s5),float,z5) * store(&(__return.s6),float,z6) * store(&(__return.s7),float,z7) * store(&(__return.s8),float,z8) * store(&(__return.s9),float,z9) * store(&(__return.s10),float,z10) * store(&(__return.s11),float,z11) * store(&(__return.s12),float,z12) * store(&(__return.s13),float,z13) * store(&(__return.s14),float,z14) * store(&(__return.s15),float,z15) * store(&(__return.s16),float,z16) * store(&(__return.s17),float,z17) * store(&(__return.s18),float,z18) * store(&(__return.s19),float,z19) * store(&(__return.s20),float,z20) * store(&(__return.s21),float,z21) * store(&(__return.s22),float,z22) * store(&(__return.s23),float,z23) * store(&(__return.s24),float,z24) * store(&(__return.s25),float,z25) * store(&(__return.s26),float,z26) * store(&(__return.s27),float,z27) * store(&(__return.s28),float,z28) * store(&(__return.s29),float,z29) * store(&(__return.s30),float,z30) * store(&(__return.s31),float,z31) * FloatArray::full(base,len,L) */;
vfloat32m8_t __riscv_vfmv_v_f_f32m8(float scalar,size_t vl)
/*@ Require 1<=vl && vl<=32 && emp
 Ensure exists z0 z1 z2 z3 z4 z5 z6 z7 z8 z9 z10 z11 z12 z13 z14 z15 z16 z17 z18 z19 z20 z21 z22 z23 z24 z25 z26 z27 z28 z29 z30 z31, spmm_active32(vl,z0,z1,z2,z3,z4,z5,z6,z7,z8,z9,z10,z11,z12,z13,z14,z15,z16,z17,z18,z19,z20,z21,z22,z23,z24,z25,z26,z27,z28,z29,z30,z31,scalar,scalar,scalar,scalar,scalar,scalar,scalar,scalar,scalar,scalar,scalar,scalar,scalar,scalar,scalar,scalar,scalar,scalar,scalar,scalar,scalar,scalar,scalar,scalar,scalar,scalar,scalar,scalar,scalar,scalar,scalar,scalar) && store(&(__return.s0),float,z0) * store(&(__return.s1),float,z1) * store(&(__return.s2),float,z2) * store(&(__return.s3),float,z3) * store(&(__return.s4),float,z4) * store(&(__return.s5),float,z5) * store(&(__return.s6),float,z6) * store(&(__return.s7),float,z7) * store(&(__return.s8),float,z8) * store(&(__return.s9),float,z9) * store(&(__return.s10),float,z10) * store(&(__return.s11),float,z11) * store(&(__return.s12),float,z12) * store(&(__return.s13),float,z13) * store(&(__return.s14),float,z14) * store(&(__return.s15),float,z15) * store(&(__return.s16),float,z16) * store(&(__return.s17),float,z17) * store(&(__return.s18),float,z18) * store(&(__return.s19),float,z19) * store(&(__return.s20),float,z20) * store(&(__return.s21),float,z21) * store(&(__return.s22),float,z22) * store(&(__return.s23),float,z23) * store(&(__return.s24),float,z24) * store(&(__return.s25),float,z25) * store(&(__return.s26),float,z26) * store(&(__return.s27),float,z27) * store(&(__return.s28),float,z28) * store(&(__return.s29),float,z29) * store(&(__return.s30),float,z30) * store(&(__return.s31),float,z31) */;
vfloat32m8_t __riscv_vfmacc_vf_f32m8(vfloat32m8_t a,float scalar,vfloat32m8_t b,size_t vl)
/*@ With (x0:fp32) (x1:fp32) (x2:fp32) (x3:fp32) (x4:fp32) (x5:fp32) (x6:fp32) (x7:fp32) (x8:fp32) (x9:fp32) (x10:fp32) (x11:fp32) (x12:fp32) (x13:fp32) (x14:fp32) (x15:fp32) (x16:fp32) (x17:fp32) (x18:fp32) (x19:fp32) (x20:fp32) (x21:fp32) (x22:fp32) (x23:fp32) (x24:fp32) (x25:fp32) (x26:fp32) (x27:fp32) (x28:fp32) (x29:fp32) (x30:fp32) (x31:fp32) (y0:fp32) (y1:fp32) (y2:fp32) (y3:fp32) (y4:fp32) (y5:fp32) (y6:fp32) (y7:fp32) (y8:fp32) (y9:fp32) (y10:fp32) (y11:fp32) (y12:fp32) (y13:fp32) (y14:fp32) (y15:fp32) (y16:fp32) (y17:fp32) (y18:fp32) (y19:fp32) (y20:fp32) (y21:fp32) (y22:fp32) (y23:fp32) (y24:fp32) (y25:fp32) (y26:fp32) (y27:fp32) (y28:fp32) (y29:fp32) (y30:fp32) (y31:fp32)
 Require 1<=vl && vl<=32 && store(&(a.s0),float,x0) * store(&(a.s1),float,x1) * store(&(a.s2),float,x2) * store(&(a.s3),float,x3) * store(&(a.s4),float,x4) * store(&(a.s5),float,x5) * store(&(a.s6),float,x6) * store(&(a.s7),float,x7) * store(&(a.s8),float,x8) * store(&(a.s9),float,x9) * store(&(a.s10),float,x10) * store(&(a.s11),float,x11) * store(&(a.s12),float,x12) * store(&(a.s13),float,x13) * store(&(a.s14),float,x14) * store(&(a.s15),float,x15) * store(&(a.s16),float,x16) * store(&(a.s17),float,x17) * store(&(a.s18),float,x18) * store(&(a.s19),float,x19) * store(&(a.s20),float,x20) * store(&(a.s21),float,x21) * store(&(a.s22),float,x22) * store(&(a.s23),float,x23) * store(&(a.s24),float,x24) * store(&(a.s25),float,x25) * store(&(a.s26),float,x26) * store(&(a.s27),float,x27) * store(&(a.s28),float,x28) * store(&(a.s29),float,x29) * store(&(a.s30),float,x30) * store(&(a.s31),float,x31) * store(&(b.s0),float,y0) * store(&(b.s1),float,y1) * store(&(b.s2),float,y2) * store(&(b.s3),float,y3) * store(&(b.s4),float,y4) * store(&(b.s5),float,y5) * store(&(b.s6),float,y6) * store(&(b.s7),float,y7) * store(&(b.s8),float,y8) * store(&(b.s9),float,y9) * store(&(b.s10),float,y10) * store(&(b.s11),float,y11) * store(&(b.s12),float,y12) * store(&(b.s13),float,y13) * store(&(b.s14),float,y14) * store(&(b.s15),float,y15) * store(&(b.s16),float,y16) * store(&(b.s17),float,y17) * store(&(b.s18),float,y18) * store(&(b.s19),float,y19) * store(&(b.s20),float,y20) * store(&(b.s21),float,y21) * store(&(b.s22),float,y22) * store(&(b.s23),float,y23) * store(&(b.s24),float,y24) * store(&(b.s25),float,y25) * store(&(b.s26),float,y26) * store(&(b.s27),float,y27) * store(&(b.s28),float,y28) * store(&(b.s29),float,y29) * store(&(b.s30),float,y30) * store(&(b.s31),float,y31)
 Ensure exists z0 z1 z2 z3 z4 z5 z6 z7 z8 z9 z10 z11 z12 z13 z14 z15 z16 z17 z18 z19 z20 z21 z22 z23 z24 z25 z26 z27 z28 z29 z30 z31, spmm_active32(vl,z0,z1,z2,z3,z4,z5,z6,z7,z8,z9,z10,z11,z12,z13,z14,z15,z16,z17,z18,z19,z20,z21,z22,z23,z24,z25,z26,z27,z28,z29,z30,z31,fma_rne(scalar,y0,x0),fma_rne(scalar,y1,x1),fma_rne(scalar,y2,x2),fma_rne(scalar,y3,x3),fma_rne(scalar,y4,x4),fma_rne(scalar,y5,x5),fma_rne(scalar,y6,x6),fma_rne(scalar,y7,x7),fma_rne(scalar,y8,x8),fma_rne(scalar,y9,x9),fma_rne(scalar,y10,x10),fma_rne(scalar,y11,x11),fma_rne(scalar,y12,x12),fma_rne(scalar,y13,x13),fma_rne(scalar,y14,x14),fma_rne(scalar,y15,x15),fma_rne(scalar,y16,x16),fma_rne(scalar,y17,x17),fma_rne(scalar,y18,x18),fma_rne(scalar,y19,x19),fma_rne(scalar,y20,x20),fma_rne(scalar,y21,x21),fma_rne(scalar,y22,x22),fma_rne(scalar,y23,x23),fma_rne(scalar,y24,x24),fma_rne(scalar,y25,x25),fma_rne(scalar,y26,x26),fma_rne(scalar,y27,x27),fma_rne(scalar,y28,x28),fma_rne(scalar,y29,x29),fma_rne(scalar,y30,x30),fma_rne(scalar,y31,x31)) && store(&(__return.s0),float,z0) * store(&(__return.s1),float,z1) * store(&(__return.s2),float,z2) * store(&(__return.s3),float,z3) * store(&(__return.s4),float,z4) * store(&(__return.s5),float,z5) * store(&(__return.s6),float,z6) * store(&(__return.s7),float,z7) * store(&(__return.s8),float,z8) * store(&(__return.s9),float,z9) * store(&(__return.s10),float,z10) * store(&(__return.s11),float,z11) * store(&(__return.s12),float,z12) * store(&(__return.s13),float,z13) * store(&(__return.s14),float,z14) * store(&(__return.s15),float,z15) * store(&(__return.s16),float,z16) * store(&(__return.s17),float,z17) * store(&(__return.s18),float,z18) * store(&(__return.s19),float,z19) * store(&(__return.s20),float,z20) * store(&(__return.s21),float,z21) * store(&(__return.s22),float,z22) * store(&(__return.s23),float,z23) * store(&(__return.s24),float,z24) * store(&(__return.s25),float,z25) * store(&(__return.s26),float,z26) * store(&(__return.s27),float,z27) * store(&(__return.s28),float,z28) * store(&(__return.s29),float,z29) * store(&(__return.s30),float,z30) * store(&(__return.s31),float,z31) */;
vfloat32m8_t __riscv_vfmin_vf_f32m8(vfloat32m8_t a,float scalar,size_t vl)
/*@ With (x0:fp32) (x1:fp32) (x2:fp32) (x3:fp32) (x4:fp32) (x5:fp32) (x6:fp32) (x7:fp32) (x8:fp32) (x9:fp32) (x10:fp32) (x11:fp32) (x12:fp32) (x13:fp32) (x14:fp32) (x15:fp32) (x16:fp32) (x17:fp32) (x18:fp32) (x19:fp32) (x20:fp32) (x21:fp32) (x22:fp32) (x23:fp32) (x24:fp32) (x25:fp32) (x26:fp32) (x27:fp32) (x28:fp32) (x29:fp32) (x30:fp32) (x31:fp32)
 Require 1<=vl && vl<=32 && store(&(a.s0),float,x0) * store(&(a.s1),float,x1) * store(&(a.s2),float,x2) * store(&(a.s3),float,x3) * store(&(a.s4),float,x4) * store(&(a.s5),float,x5) * store(&(a.s6),float,x6) * store(&(a.s7),float,x7) * store(&(a.s8),float,x8) * store(&(a.s9),float,x9) * store(&(a.s10),float,x10) * store(&(a.s11),float,x11) * store(&(a.s12),float,x12) * store(&(a.s13),float,x13) * store(&(a.s14),float,x14) * store(&(a.s15),float,x15) * store(&(a.s16),float,x16) * store(&(a.s17),float,x17) * store(&(a.s18),float,x18) * store(&(a.s19),float,x19) * store(&(a.s20),float,x20) * store(&(a.s21),float,x21) * store(&(a.s22),float,x22) * store(&(a.s23),float,x23) * store(&(a.s24),float,x24) * store(&(a.s25),float,x25) * store(&(a.s26),float,x26) * store(&(a.s27),float,x27) * store(&(a.s28),float,x28) * store(&(a.s29),float,x29) * store(&(a.s30),float,x30) * store(&(a.s31),float,x31)
 Ensure exists z0 z1 z2 z3 z4 z5 z6 z7 z8 z9 z10 z11 z12 z13 z14 z15 z16 z17 z18 z19 z20 z21 z22 z23 z24 z25 z26 z27 z28 z29 z30 z31, spmm_active32(vl,z0,z1,z2,z3,z4,z5,z6,z7,z8,z9,z10,z11,z12,z13,z14,z15,z16,z17,z18,z19,z20,z21,z22,z23,z24,z25,z26,z27,z28,z29,z30,z31,fp32_min_number(x0,scalar),fp32_min_number(x1,scalar),fp32_min_number(x2,scalar),fp32_min_number(x3,scalar),fp32_min_number(x4,scalar),fp32_min_number(x5,scalar),fp32_min_number(x6,scalar),fp32_min_number(x7,scalar),fp32_min_number(x8,scalar),fp32_min_number(x9,scalar),fp32_min_number(x10,scalar),fp32_min_number(x11,scalar),fp32_min_number(x12,scalar),fp32_min_number(x13,scalar),fp32_min_number(x14,scalar),fp32_min_number(x15,scalar),fp32_min_number(x16,scalar),fp32_min_number(x17,scalar),fp32_min_number(x18,scalar),fp32_min_number(x19,scalar),fp32_min_number(x20,scalar),fp32_min_number(x21,scalar),fp32_min_number(x22,scalar),fp32_min_number(x23,scalar),fp32_min_number(x24,scalar),fp32_min_number(x25,scalar),fp32_min_number(x26,scalar),fp32_min_number(x27,scalar),fp32_min_number(x28,scalar),fp32_min_number(x29,scalar),fp32_min_number(x30,scalar),fp32_min_number(x31,scalar)) && store(&(__return.s0),float,z0) * store(&(__return.s1),float,z1) * store(&(__return.s2),float,z2) * store(&(__return.s3),float,z3) * store(&(__return.s4),float,z4) * store(&(__return.s5),float,z5) * store(&(__return.s6),float,z6) * store(&(__return.s7),float,z7) * store(&(__return.s8),float,z8) * store(&(__return.s9),float,z9) * store(&(__return.s10),float,z10) * store(&(__return.s11),float,z11) * store(&(__return.s12),float,z12) * store(&(__return.s13),float,z13) * store(&(__return.s14),float,z14) * store(&(__return.s15),float,z15) * store(&(__return.s16),float,z16) * store(&(__return.s17),float,z17) * store(&(__return.s18),float,z18) * store(&(__return.s19),float,z19) * store(&(__return.s20),float,z20) * store(&(__return.s21),float,z21) * store(&(__return.s22),float,z22) * store(&(__return.s23),float,z23) * store(&(__return.s24),float,z24) * store(&(__return.s25),float,z25) * store(&(__return.s26),float,z26) * store(&(__return.s27),float,z27) * store(&(__return.s28),float,z28) * store(&(__return.s29),float,z29) * store(&(__return.s30),float,z30) * store(&(__return.s31),float,z31) */;
vfloat32m8_t __riscv_vfmax_vf_f32m8(vfloat32m8_t a,float scalar,size_t vl)
/*@ With (x0:fp32) (x1:fp32) (x2:fp32) (x3:fp32) (x4:fp32) (x5:fp32) (x6:fp32) (x7:fp32) (x8:fp32) (x9:fp32) (x10:fp32) (x11:fp32) (x12:fp32) (x13:fp32) (x14:fp32) (x15:fp32) (x16:fp32) (x17:fp32) (x18:fp32) (x19:fp32) (x20:fp32) (x21:fp32) (x22:fp32) (x23:fp32) (x24:fp32) (x25:fp32) (x26:fp32) (x27:fp32) (x28:fp32) (x29:fp32) (x30:fp32) (x31:fp32)
 Require 1<=vl && vl<=32 && store(&(a.s0),float,x0) * store(&(a.s1),float,x1) * store(&(a.s2),float,x2) * store(&(a.s3),float,x3) * store(&(a.s4),float,x4) * store(&(a.s5),float,x5) * store(&(a.s6),float,x6) * store(&(a.s7),float,x7) * store(&(a.s8),float,x8) * store(&(a.s9),float,x9) * store(&(a.s10),float,x10) * store(&(a.s11),float,x11) * store(&(a.s12),float,x12) * store(&(a.s13),float,x13) * store(&(a.s14),float,x14) * store(&(a.s15),float,x15) * store(&(a.s16),float,x16) * store(&(a.s17),float,x17) * store(&(a.s18),float,x18) * store(&(a.s19),float,x19) * store(&(a.s20),float,x20) * store(&(a.s21),float,x21) * store(&(a.s22),float,x22) * store(&(a.s23),float,x23) * store(&(a.s24),float,x24) * store(&(a.s25),float,x25) * store(&(a.s26),float,x26) * store(&(a.s27),float,x27) * store(&(a.s28),float,x28) * store(&(a.s29),float,x29) * store(&(a.s30),float,x30) * store(&(a.s31),float,x31)
 Ensure exists z0 z1 z2 z3 z4 z5 z6 z7 z8 z9 z10 z11 z12 z13 z14 z15 z16 z17 z18 z19 z20 z21 z22 z23 z24 z25 z26 z27 z28 z29 z30 z31, spmm_active32(vl,z0,z1,z2,z3,z4,z5,z6,z7,z8,z9,z10,z11,z12,z13,z14,z15,z16,z17,z18,z19,z20,z21,z22,z23,z24,z25,z26,z27,z28,z29,z30,z31,fp32_max_number(x0,scalar),fp32_max_number(x1,scalar),fp32_max_number(x2,scalar),fp32_max_number(x3,scalar),fp32_max_number(x4,scalar),fp32_max_number(x5,scalar),fp32_max_number(x6,scalar),fp32_max_number(x7,scalar),fp32_max_number(x8,scalar),fp32_max_number(x9,scalar),fp32_max_number(x10,scalar),fp32_max_number(x11,scalar),fp32_max_number(x12,scalar),fp32_max_number(x13,scalar),fp32_max_number(x14,scalar),fp32_max_number(x15,scalar),fp32_max_number(x16,scalar),fp32_max_number(x17,scalar),fp32_max_number(x18,scalar),fp32_max_number(x19,scalar),fp32_max_number(x20,scalar),fp32_max_number(x21,scalar),fp32_max_number(x22,scalar),fp32_max_number(x23,scalar),fp32_max_number(x24,scalar),fp32_max_number(x25,scalar),fp32_max_number(x26,scalar),fp32_max_number(x27,scalar),fp32_max_number(x28,scalar),fp32_max_number(x29,scalar),fp32_max_number(x30,scalar),fp32_max_number(x31,scalar)) && store(&(__return.s0),float,z0) * store(&(__return.s1),float,z1) * store(&(__return.s2),float,z2) * store(&(__return.s3),float,z3) * store(&(__return.s4),float,z4) * store(&(__return.s5),float,z5) * store(&(__return.s6),float,z6) * store(&(__return.s7),float,z7) * store(&(__return.s8),float,z8) * store(&(__return.s9),float,z9) * store(&(__return.s10),float,z10) * store(&(__return.s11),float,z11) * store(&(__return.s12),float,z12) * store(&(__return.s13),float,z13) * store(&(__return.s14),float,z14) * store(&(__return.s15),float,z15) * store(&(__return.s16),float,z16) * store(&(__return.s17),float,z17) * store(&(__return.s18),float,z18) * store(&(__return.s19),float,z19) * store(&(__return.s20),float,z20) * store(&(__return.s21),float,z21) * store(&(__return.s22),float,z22) * store(&(__return.s23),float,z23) * store(&(__return.s24),float,z24) * store(&(__return.s25),float,z25) * store(&(__return.s26),float,z26) * store(&(__return.s27),float,z27) * store(&(__return.s28),float,z28) * store(&(__return.s29),float,z29) * store(&(__return.s30),float,z30) * store(&(__return.s31),float,z31) */;
vbool4_t qcp_nanmask(const vfloat32m8_t*a,const vfloat32m8_t*b,size_t vl)
/*@ With (x0:fp32) (x1:fp32) (x2:fp32) (x3:fp32) (x4:fp32) (x5:fp32) (x6:fp32) (x7:fp32) (x8:fp32) (x9:fp32) (x10:fp32) (x11:fp32) (x12:fp32) (x13:fp32) (x14:fp32) (x15:fp32) (x16:fp32) (x17:fp32) (x18:fp32) (x19:fp32) (x20:fp32) (x21:fp32) (x22:fp32) (x23:fp32) (x24:fp32) (x25:fp32) (x26:fp32) (x27:fp32) (x28:fp32) (x29:fp32) (x30:fp32) (x31:fp32)
 Require 1<=vl && vl<=32 && a==b && store(&(a->s0),float,x0) * store(&(a->s1),float,x1) * store(&(a->s2),float,x2) * store(&(a->s3),float,x3) * store(&(a->s4),float,x4) * store(&(a->s5),float,x5) * store(&(a->s6),float,x6) * store(&(a->s7),float,x7) * store(&(a->s8),float,x8) * store(&(a->s9),float,x9) * store(&(a->s10),float,x10) * store(&(a->s11),float,x11) * store(&(a->s12),float,x12) * store(&(a->s13),float,x13) * store(&(a->s14),float,x14) * store(&(a->s15),float,x15) * store(&(a->s16),float,x16) * store(&(a->s17),float,x17) * store(&(a->s18),float,x18) * store(&(a->s19),float,x19) * store(&(a->s20),float,x20) * store(&(a->s21),float,x21) * store(&(a->s22),float,x22) * store(&(a->s23),float,x23) * store(&(a->s24),float,x24) * store(&(a->s25),float,x25) * store(&(a->s26),float,x26) * store(&(a->s27),float,x27) * store(&(a->s28),float,x28) * store(&(a->s29),float,x29) * store(&(a->s30),float,x30) * store(&(a->s31),float,x31)
 Ensure exists m0 m1 m2 m3 m4 m5 m6 m7 m8 m9 m10 m11 m12 m13 m14 m15 m16 m17 m18 m19 m20 m21 m22 m23 m24 m25 m26 m27 m28 m29 m30 m31, spmm_mask32(vl,m0,m1,m2,m3,m4,m5,m6,m7,m8,m9,m10,m11,m12,m13,m14,m15,m16,m17,m18,m19,m20,m21,m22,m23,m24,m25,m26,m27,m28,m29,m30,m31,spmm_nanth(x0),spmm_nanth(x1),spmm_nanth(x2),spmm_nanth(x3),spmm_nanth(x4),spmm_nanth(x5),spmm_nanth(x6),spmm_nanth(x7),spmm_nanth(x8),spmm_nanth(x9),spmm_nanth(x10),spmm_nanth(x11),spmm_nanth(x12),spmm_nanth(x13),spmm_nanth(x14),spmm_nanth(x15),spmm_nanth(x16),spmm_nanth(x17),spmm_nanth(x18),spmm_nanth(x19),spmm_nanth(x20),spmm_nanth(x21),spmm_nanth(x22),spmm_nanth(x23),spmm_nanth(x24),spmm_nanth(x25),spmm_nanth(x26),spmm_nanth(x27),spmm_nanth(x28),spmm_nanth(x29),spmm_nanth(x30),spmm_nanth(x31)) && store(&(a->s0),float,x0) * store(&(a->s1),float,x1) * store(&(a->s2),float,x2) * store(&(a->s3),float,x3) * store(&(a->s4),float,x4) * store(&(a->s5),float,x5) * store(&(a->s6),float,x6) * store(&(a->s7),float,x7) * store(&(a->s8),float,x8) * store(&(a->s9),float,x9) * store(&(a->s10),float,x10) * store(&(a->s11),float,x11) * store(&(a->s12),float,x12) * store(&(a->s13),float,x13) * store(&(a->s14),float,x14) * store(&(a->s15),float,x15) * store(&(a->s16),float,x16) * store(&(a->s17),float,x17) * store(&(a->s18),float,x18) * store(&(a->s19),float,x19) * store(&(a->s20),float,x20) * store(&(a->s21),float,x21) * store(&(a->s22),float,x22) * store(&(a->s23),float,x23) * store(&(a->s24),float,x24) * store(&(a->s25),float,x25) * store(&(a->s26),float,x26) * store(&(a->s27),float,x27) * store(&(a->s28),float,x28) * store(&(a->s29),float,x29) * store(&(a->s30),float,x30) * store(&(a->s31),float,x31) * store(&(__return.s0),int,m0) * store(&(__return.s1),int,m1) * store(&(__return.s2),int,m2) * store(&(__return.s3),int,m3) * store(&(__return.s4),int,m4) * store(&(__return.s5),int,m5) * store(&(__return.s6),int,m6) * store(&(__return.s7),int,m7) * store(&(__return.s8),int,m8) * store(&(__return.s9),int,m9) * store(&(__return.s10),int,m10) * store(&(__return.s11),int,m11) * store(&(__return.s12),int,m12) * store(&(__return.s13),int,m13) * store(&(__return.s14),int,m14) * store(&(__return.s15),int,m15) * store(&(__return.s16),int,m16) * store(&(__return.s17),int,m17) * store(&(__return.s18),int,m18) * store(&(__return.s19),int,m19) * store(&(__return.s20),int,m20) * store(&(__return.s21),int,m21) * store(&(__return.s22),int,m22) * store(&(__return.s23),int,m23) * store(&(__return.s24),int,m24) * store(&(__return.s25),int,m25) * store(&(__return.s26),int,m26) * store(&(__return.s27),int,m27) * store(&(__return.s28),int,m28) * store(&(__return.s29),int,m29) * store(&(__return.s30),int,m30) * store(&(__return.s31),int,m31) */;
vfloat32m8_t __riscv_vfmerge_vfm_f32m8(vfloat32m8_t a,float scalar,vbool4_t mask,size_t vl)
/*@ With (x0:fp32) (x1:fp32) (x2:fp32) (x3:fp32) (x4:fp32) (x5:fp32) (x6:fp32) (x7:fp32) (x8:fp32) (x9:fp32) (x10:fp32) (x11:fp32) (x12:fp32) (x13:fp32) (x14:fp32) (x15:fp32) (x16:fp32) (x17:fp32) (x18:fp32) (x19:fp32) (x20:fp32) (x21:fp32) (x22:fp32) (x23:fp32) (x24:fp32) (x25:fp32) (x26:fp32) (x27:fp32) (x28:fp32) (x29:fp32) (x30:fp32) (x31:fp32) (m0:Z) (m1:Z) (m2:Z) (m3:Z) (m4:Z) (m5:Z) (m6:Z) (m7:Z) (m8:Z) (m9:Z) (m10:Z) (m11:Z) (m12:Z) (m13:Z) (m14:Z) (m15:Z) (m16:Z) (m17:Z) (m18:Z) (m19:Z) (m20:Z) (m21:Z) (m22:Z) (m23:Z) (m24:Z) (m25:Z) (m26:Z) (m27:Z) (m28:Z) (m29:Z) (m30:Z) (m31:Z)
 Require 1<=vl && vl<=32 && store(&(a.s0),float,x0) * store(&(a.s1),float,x1) * store(&(a.s2),float,x2) * store(&(a.s3),float,x3) * store(&(a.s4),float,x4) * store(&(a.s5),float,x5) * store(&(a.s6),float,x6) * store(&(a.s7),float,x7) * store(&(a.s8),float,x8) * store(&(a.s9),float,x9) * store(&(a.s10),float,x10) * store(&(a.s11),float,x11) * store(&(a.s12),float,x12) * store(&(a.s13),float,x13) * store(&(a.s14),float,x14) * store(&(a.s15),float,x15) * store(&(a.s16),float,x16) * store(&(a.s17),float,x17) * store(&(a.s18),float,x18) * store(&(a.s19),float,x19) * store(&(a.s20),float,x20) * store(&(a.s21),float,x21) * store(&(a.s22),float,x22) * store(&(a.s23),float,x23) * store(&(a.s24),float,x24) * store(&(a.s25),float,x25) * store(&(a.s26),float,x26) * store(&(a.s27),float,x27) * store(&(a.s28),float,x28) * store(&(a.s29),float,x29) * store(&(a.s30),float,x30) * store(&(a.s31),float,x31) * store(&(mask.s0),int,m0) * store(&(mask.s1),int,m1) * store(&(mask.s2),int,m2) * store(&(mask.s3),int,m3) * store(&(mask.s4),int,m4) * store(&(mask.s5),int,m5) * store(&(mask.s6),int,m6) * store(&(mask.s7),int,m7) * store(&(mask.s8),int,m8) * store(&(mask.s9),int,m9) * store(&(mask.s10),int,m10) * store(&(mask.s11),int,m11) * store(&(mask.s12),int,m12) * store(&(mask.s13),int,m13) * store(&(mask.s14),int,m14) * store(&(mask.s15),int,m15) * store(&(mask.s16),int,m16) * store(&(mask.s17),int,m17) * store(&(mask.s18),int,m18) * store(&(mask.s19),int,m19) * store(&(mask.s20),int,m20) * store(&(mask.s21),int,m21) * store(&(mask.s22),int,m22) * store(&(mask.s23),int,m23) * store(&(mask.s24),int,m24) * store(&(mask.s25),int,m25) * store(&(mask.s26),int,m26) * store(&(mask.s27),int,m27) * store(&(mask.s28),int,m28) * store(&(mask.s29),int,m29) * store(&(mask.s30),int,m30) * store(&(mask.s31),int,m31)
 Ensure exists z0 z1 z2 z3 z4 z5 z6 z7 z8 z9 z10 z11 z12 z13 z14 z15 z16 z17 z18 z19 z20 z21 z22 z23 z24 z25 z26 z27 z28 z29 z30 z31, spmm_active32(vl,z0,z1,z2,z3,z4,z5,z6,z7,z8,z9,z10,z11,z12,z13,z14,z15,z16,z17,z18,z19,z20,z21,z22,z23,z24,z25,z26,z27,z28,z29,z30,z31,spmm_merge(x0,scalar,m0),spmm_merge(x1,scalar,m1),spmm_merge(x2,scalar,m2),spmm_merge(x3,scalar,m3),spmm_merge(x4,scalar,m4),spmm_merge(x5,scalar,m5),spmm_merge(x6,scalar,m6),spmm_merge(x7,scalar,m7),spmm_merge(x8,scalar,m8),spmm_merge(x9,scalar,m9),spmm_merge(x10,scalar,m10),spmm_merge(x11,scalar,m11),spmm_merge(x12,scalar,m12),spmm_merge(x13,scalar,m13),spmm_merge(x14,scalar,m14),spmm_merge(x15,scalar,m15),spmm_merge(x16,scalar,m16),spmm_merge(x17,scalar,m17),spmm_merge(x18,scalar,m18),spmm_merge(x19,scalar,m19),spmm_merge(x20,scalar,m20),spmm_merge(x21,scalar,m21),spmm_merge(x22,scalar,m22),spmm_merge(x23,scalar,m23),spmm_merge(x24,scalar,m24),spmm_merge(x25,scalar,m25),spmm_merge(x26,scalar,m26),spmm_merge(x27,scalar,m27),spmm_merge(x28,scalar,m28),spmm_merge(x29,scalar,m29),spmm_merge(x30,scalar,m30),spmm_merge(x31,scalar,m31)) && store(&(__return.s0),float,z0) * store(&(__return.s1),float,z1) * store(&(__return.s2),float,z2) * store(&(__return.s3),float,z3) * store(&(__return.s4),float,z4) * store(&(__return.s5),float,z5) * store(&(__return.s6),float,z6) * store(&(__return.s7),float,z7) * store(&(__return.s8),float,z8) * store(&(__return.s9),float,z9) * store(&(__return.s10),float,z10) * store(&(__return.s11),float,z11) * store(&(__return.s12),float,z12) * store(&(__return.s13),float,z13) * store(&(__return.s14),float,z14) * store(&(__return.s15),float,z15) * store(&(__return.s16),float,z16) * store(&(__return.s17),float,z17) * store(&(__return.s18),float,z18) * store(&(__return.s19),float,z19) * store(&(__return.s20),float,z20) * store(&(__return.s21),float,z21) * store(&(__return.s22),float,z22) * store(&(__return.s23),float,z23) * store(&(__return.s24),float,z24) * store(&(__return.s25),float,z25) * store(&(__return.s26),float,z26) * store(&(__return.s27),float,z27) * store(&(__return.s28),float,z28) * store(&(__return.s29),float,z29) * store(&(__return.s30),float,z30) * store(&(__return.s31),float,z31) */;
void qcp_store(float*p,const vfloat32m8_t*a,size_t vl)
/*@ With (x0:fp32) (x1:fp32) (x2:fp32) (x3:fp32) (x4:fp32) (x5:fp32) (x6:fp32) (x7:fp32) (x8:fp32) (x9:fp32) (x10:fp32) (x11:fp32) (x12:fp32) (x13:fp32) (x14:fp32) (x15:fp32) (x16:fp32) (x17:fp32) (x18:fp32) (x19:fp32) (x20:fp32) (x21:fp32) (x22:fp32) (x23:fp32) (x24:fp32) (x25:fp32) (x26:fp32) (x27:fp32) (x28:fp32) (x29:fp32) (x30:fp32) (x31:fp32)
 Require 1<=vl && vl<=32 && store(&(a->s0),float,x0) * store(&(a->s1),float,x1) * store(&(a->s2),float,x2) * store(&(a->s3),float,x3) * store(&(a->s4),float,x4) * store(&(a->s5),float,x5) * store(&(a->s6),float,x6) * store(&(a->s7),float,x7) * store(&(a->s8),float,x8) * store(&(a->s9),float,x9) * store(&(a->s10),float,x10) * store(&(a->s11),float,x11) * store(&(a->s12),float,x12) * store(&(a->s13),float,x13) * store(&(a->s14),float,x14) * store(&(a->s15),float,x15) * store(&(a->s16),float,x16) * store(&(a->s17),float,x17) * store(&(a->s18),float,x18) * store(&(a->s19),float,x19) * store(&(a->s20),float,x20) * store(&(a->s21),float,x21) * store(&(a->s22),float,x22) * store(&(a->s23),float,x23) * store(&(a->s24),float,x24) * store(&(a->s25),float,x25) * store(&(a->s26),float,x26) * store(&(a->s27),float,x27) * store(&(a->s28),float,x28) * store(&(a->s29),float,x29) * store(&(a->s30),float,x30) * store(&(a->s31),float,x31) * FloatArray::undef_full(p,vl)
 Ensure store(&(a->s0),float,x0) * store(&(a->s1),float,x1) * store(&(a->s2),float,x2) * store(&(a->s3),float,x3) * store(&(a->s4),float,x4) * store(&(a->s5),float,x5) * store(&(a->s6),float,x6) * store(&(a->s7),float,x7) * store(&(a->s8),float,x8) * store(&(a->s9),float,x9) * store(&(a->s10),float,x10) * store(&(a->s11),float,x11) * store(&(a->s12),float,x12) * store(&(a->s13),float,x13) * store(&(a->s14),float,x14) * store(&(a->s15),float,x15) * store(&(a->s16),float,x16) * store(&(a->s17),float,x17) * store(&(a->s18),float,x18) * store(&(a->s19),float,x19) * store(&(a->s20),float,x20) * store(&(a->s21),float,x21) * store(&(a->s22),float,x22) * store(&(a->s23),float,x23) * store(&(a->s24),float,x24) * store(&(a->s25),float,x25) * store(&(a->s26),float,x26) * store(&(a->s27),float,x27) * store(&(a->s28),float,x28) * store(&(a->s29),float,x29) * store(&(a->s30),float,x30) * store(&(a->s31),float,x31) * FloatArray::full(p,vl,sublist(0,vl,cons(x0,cons(x1,cons(x2,cons(x3,cons(x4,cons(x5,cons(x6,cons(x7,cons(x8,cons(x9,cons(x10,cons(x11,cons(x12,cons(x13,cons(x14,cons(x15,cons(x16,cons(x17,cons(x18,cons(x19,cons(x20,cons(x21,cons(x22,cons(x23,cons(x24,cons(x25,cons(x26,cons(x27,cons(x28,cons(x29,cons(x30,cons(x31,nil)))))))))))))))))))))))))))))))))) */;
void test_rvv(
    size_t mc,
    size_t nc,
    const float* input,
    const float* weights,
    const int32_t* widx_dmap,
    const uint32_t* nidx_nnzmap,
    float* output,
    size_t output_stride,
    const struct xnn_f32_minmax_params* restrict params)
{
  qcp_assert(mc != 0);
  qcp_assert(mc % sizeof(float) == 0);
  qcp_assert(nc != 0);
  const float vmin = params->scalar.min;
  const float vmax = params->scalar.max;
  // Process the M dimension input_cursor vl-row strips; each strip is one vsetvl group.
  size_t m = mc / sizeof(float);
  while (m > 0) {
    size_t vl = __riscv_vsetvl_e32m8(m);
    const float* w = weights;
    const int32_t* dmap = widx_dmap;
    const uint32_t* nnzmap = nidx_nnzmap;
    const float* input_cursor = input;
    float* out = output;
    size_t n = nc;
    do {
      uint32_t nnz = *nnzmap; nnzmap += 1;
      vfloat32m8_t vacc = __riscv_vfmv_v_f_f32m8(*w, vl); w += 1; // bias broadcast
      if (nnz != 0) {
        do {
          const intptr_t diff = *dmap; dmap += 1;
          vfloat32m8_t vi = __riscv_vle32_v_f32m8(input_cursor, vl);
          input_cursor = (const float*) ((uintptr_t) input_cursor + (uintptr_t) diff);
          const float vw = *w; w += 1;
          // Match NEON fused accumulation: one binary32 rounding.
          vacc = __riscv_vfmacc_vf_f32m8(vacc, vw, vi, vl);
          nnz -= 1;
        } while (nnz != 0);
      }
      /* Preserve NEON NaN propagation; vfmin/vfmax keep RVV semantics. */
      vfloat32m8_t vout;
      if (vmax != qcp_identity(vmax)) {
        vout = __riscv_vfmv_v_f_f32m8(qcp_nanf(), vl);
      } else {
        vbool4_t nan = qcp_nanmask(&(vacc),&(vacc),(vl));
        vout = __riscv_vfmin_vf_f32m8(vacc, vmax, vl);
        vout = __riscv_vfmerge_vfm_f32m8(vout, qcp_nanf(), nan, vl);
      }
      if (vmin != qcp_identity(vmin)) {
        vout = __riscv_vfmv_v_f_f32m8(qcp_nanf(), vl);
      } else {
        vbool4_t nan = qcp_nanmask(&(vout),&(vout),(vl));
        vout = __riscv_vfmax_vf_f32m8(vout, vmin, vl);
        vout = __riscv_vfmerge_vfm_f32m8(vout, qcp_nanf(), nan, vl);
      }
      qcp_store((out),&(vout),(vl));
      out = (float*) ((uintptr_t) out + output_stride);
      n -= 1;
    } while (n != 0);
    input += vl;
    output += vl;
    m -= vl;
  }
}
