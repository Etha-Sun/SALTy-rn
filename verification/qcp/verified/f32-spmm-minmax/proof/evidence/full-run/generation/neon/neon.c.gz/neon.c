/*@ Import Coq Require Import SpmmSpec.TupleMemory */
struct float32x4_t {float s0;float s1;float s2;float s3;};
typedef struct float32x4_t float32x4_t;
struct float32x4x2_t {float32x4_t val[2];};
typedef struct float32x4x2_t float32x4x2_t;
/*@ Extern Coq Record Recordfloat32x4_t { f0:fp32; f1:fp32; f2:fp32; f3:fp32; } */
/*@ Extern Coq Record Recordfloat32x4x2_t { tuple_values:list Recordfloat32x4_t; } */
/*@ Extern Coq
 (tuple_record:list Recordfloat32x4_t -> Recordfloat32x4x2_t)
 (tuple_values:Recordfloat32x4x2_t -> list Recordfloat32x4_t)
 (vec4: fp32 -> fp32 -> fp32 -> fp32 -> Recordfloat32x4_t)
 (f0: Recordfloat32x4_t -> fp32) (f1: Recordfloat32x4_t -> fp32)
 (f2: Recordfloat32x4_t -> fp32) (f3: Recordfloat32x4_t -> fp32)
 (veczero:Recordfloat32x4_t)
 (StructPredfloat32x4x2_t:Z -> Recordfloat32x4x2_t -> Assertion)
 (UndefStructPredfloat32x4_t: Z -> Assertion)
 (UndefStructPredfloat32x4x2_t: Z -> Assertion)
 (Structfloat32x4_tArray::full: Z -> Z -> list Recordfloat32x4_t -> Assertion)
 (Structfloat32x4_tArray::undef_full: Z -> Z -> Assertion)
 (cons:{A} -> A -> list A -> list A) (nil:{A} -> list A)
 (tuple_at: Z -> list Recordfloat32x4_t -> Recordfloat32x4_t)
*/
/*@ include strategies "tuple.strategies" */
/*@ Import Coq Require Import GemmSpec.FmaModel */
/*@ Extern Coq (bit_same:fp32 -> fp32 -> Prop) */
float qcp_identity(float x)
/*@ Require emp Ensure bit_same(__return,x) && emp */;
void qcp_assert(int condition)
/*@ Require condition!=0 && emp Ensure emp */;
/* Source-reviewed GNU builtin. Cache/performance effects are not data-memory
   observations; the caller still proves evaluation of its address expression. */
void __builtin_prefetch(const void *address)
/*@ Require emp Ensure emp */;
void xnn_prefetch_to_l1(const void *address)
/*@ Require emp Ensure emp */;
typedef unsigned long long size_t;
typedef unsigned long long uintptr_t;
typedef long long intptr_t;
typedef int int32_t;
typedef unsigned int uint32_t;
struct scalar_bounds {float min;float max;};
struct xnn_f32_minmax_params {struct scalar_bounds scalar;};
struct float32x2_t {float s0;float s1;};
typedef struct float32x2_t float32x2_t;
struct vfloat32m8_t {float s0;float s1;float s2;float s3;float s4;float s5;float s6;float s7;float s8;float s9;float s10;float s11;float s12;float s13;float s14;float s15;float s16;float s17;float s18;float s19;float s20;float s21;float s22;float s23;float s24;float s25;float s26;float s27;float s28;float s29;float s30;float s31;};
typedef struct vfloat32m8_t vfloat32m8_t;
struct vbool4_t {int s0;int s1;int s2;int s3;int s4;int s5;int s6;int s7;int s8;int s9;int s10;int s11;int s12;int s13;int s14;int s15;int s16;int s17;int s18;int s19;int s20;int s21;int s22;int s23;int s24;int s25;int s26;int s27;int s28;int s29;int s30;int s31;};
typedef struct vbool4_t vbool4_t;
/*@ Import Coq Require Import SpmmSpec.Model SpmmSpec.Vectors */
/*@ Extern Coq
 (FloatArray::full:Z -> Z -> list fp32 -> Assertion)
 (FloatArray::seg:Z -> Z -> Z -> list fp32 -> Assertion)
 (FloatArray::undef_full:Z -> Z -> Assertion)
 (spmm_get:Z -> list fp32 -> fp32)
 (bit_same:fp32 -> fp32 -> Prop)
 (fma_rne:fp32 -> fp32 -> fp32 -> fp32)
 (fp32_neon_min:fp32 -> fp32 -> fp32) (fp32_neon_max:fp32 -> fp32 -> fp32)
 (fp32_min_number:fp32 -> fp32 -> fp32) (fp32_max_number:fp32 -> fp32 -> fp32)
 (canonical_qnan:fp32) (spmm_nanth:fp32 -> Z) (spmm_merge:fp32 -> fp32 -> Z -> fp32)
 (spmm_vl_allowed:Z -> Z -> Prop)
 (UndefStructPredfloat32x2_t:Z -> Assertion)
 (UndefStructPredvfloat32m8_t:Z -> Assertion) (UndefStructPredvbool4_t:Z -> Assertion)
 (spmm_active32:Z -> fp32 -> fp32 -> fp32 -> fp32 -> fp32 -> fp32 -> fp32 -> fp32 -> fp32 -> fp32 -> fp32 -> fp32 -> fp32 -> fp32 -> fp32 -> fp32 -> fp32 -> fp32 -> fp32 -> fp32 -> fp32 -> fp32 -> fp32 -> fp32 -> fp32 -> fp32 -> fp32 -> fp32 -> fp32 -> fp32 -> fp32 -> fp32 -> fp32 -> fp32 -> fp32 -> fp32 -> fp32 -> fp32 -> fp32 -> fp32 -> fp32 -> fp32 -> fp32 -> fp32 -> fp32 -> fp32 -> fp32 -> fp32 -> fp32 -> fp32 -> fp32 -> fp32 -> fp32 -> fp32 -> fp32 -> fp32 -> fp32 -> fp32 -> fp32 -> fp32 -> fp32 -> fp32 -> fp32 -> fp32 -> Prop)
 (spmm_mask32:Z -> Z -> Z -> Z -> Z -> Z -> Z -> Z -> Z -> Z -> Z -> Z -> Z -> Z -> Z -> Z -> Z -> Z -> Z -> Z -> Z -> Z -> Z -> Z -> Z -> Z -> Z -> Z -> Z -> Z -> Z -> Z -> Z -> Z -> Z -> Z -> Z -> Z -> Z -> Z -> Z -> Z -> Z -> Z -> Z -> Z -> Z -> Z -> Z -> Z -> Z -> Z -> Z -> Z -> Z -> Z -> Z -> Z -> Z -> Z -> Z -> Z -> Z -> Z -> Z -> Prop)
*/
/*@ include strategies "vectors.strategies" */
/*@ Import Coq Require Import SpmmSpec.Memory */
/*@ Extern Coq
 (spmm_shape:Z -> Z -> Z -> list Z -> list Z -> list fp32 -> list fp32 -> Prop)
 (spmm_capacity:Z -> Z -> Z -> Z -> Z -> Z -> Z -> Z -> list Z -> list Z -> list fp32 -> list fp32 -> Prop)
 (spmm_output:Z -> Z -> Z -> Z -> Z -> Z -> Z -> Z -> list Z -> list Z -> list fp32 -> list fp32 -> fp32 -> fp32 -> Assertion)
 (spmm_output_hole:Z -> Z -> Z -> Z -> Z -> Z -> Z -> Z -> list Z -> list Z -> list fp32 -> list fp32 -> fp32 -> fp32 -> Assertion)
 (spmm_acc:Z -> Z -> Z -> Z -> list Z -> list Z -> list fp32 -> list fp32 -> fp32)
 (spmm_cell:Z -> Z -> Z -> list Z -> list Z -> list fp32 -> list fp32 -> fp32 -> fp32 -> fp32)
 (spmm_column_prefix:Z -> Z -> Z -> list Z -> list Z -> list fp32 -> list fp32 -> fp32 -> fp32 -> list fp32)
 (IntArray::full:Z -> Z -> list Z -> Assertion)
 (UIntArray::full:Z -> Z -> list Z -> Assertion)
 (FloatArray::missing_i:Z -> Z -> Z -> Z -> list fp32 -> Assertion)
 (prefix_sum:list Z -> Z -> Z) (nnz_before:list Z -> Z -> Z)
 (bias_index:list Z -> Z -> Z) (input_index:list Z -> Z -> Z -> Z -> Z)
 (fp_at:list fp32 -> Z -> fp32) (z_at:list Z -> Z -> Z)
 (word64:Z -> Z) (modulus64:Z)
 (spmm_output_cursor:Z -> Z -> Z -> Z -> Z)
*/
/* This call-specific view reads the adjacent min/max fields of scalar_bounds.
 * AAPCS64 2025Q1: binary32 size/alignment4 and sequential homogeneous aggregate.
 * ACLE aef52c2: LD2R broadcasts these two elements to val[0]/val[1].
 * Source-reviewed intrinsic memory view; not a formal ABI refinement theorem. */
float32x4x2_t vld2q_dup_f32(const float*p)
/*@ With (owner:Z) (lo:fp32) (hi:fp32)
 Require p==field_addr(field_addr(owner,xnn_f32_minmax_params,scalar),scalar_bounds,min) && store(field_addr(field_addr(owner,xnn_f32_minmax_params,scalar),scalar_bounds,min),float,lo) * store(field_addr(field_addr(owner,xnn_f32_minmax_params,scalar),scalar_bounds,max),float,hi)
 Ensure store(field_addr(field_addr(owner,xnn_f32_minmax_params,scalar),scalar_bounds,min),float,lo) * store(field_addr(field_addr(owner,xnn_f32_minmax_params,scalar),scalar_bounds,max),float,hi) * StructPredfloat32x4x2_t(&(__return),tuple_record(cons(vec4(lo,lo,lo,lo),cons(vec4(hi,hi,hi,hi),nil)))) */;
float32x4_t vld1q_f32(const float*p)
/*@ With (base:Z) (len:Z) (j:Z) (L:list fp32)
 Require p==pointer_offset(base,j,float) && 0<=j && j+4<=len && FloatArray::full(base,len,L)
 Ensure FloatArray::full(base,len,L) * store(&(__return.s0),float,spmm_get(j+0,L)) * store(&(__return.s1),float,spmm_get(j+1,L)) * store(&(__return.s2),float,spmm_get(j+2,L)) * store(&(__return.s3),float,spmm_get(j+3,L)) */;
float32x4_t vld1q_dup_f32(const float*p)
/*@ With (base:Z) (len:Z) (j:Z) (L:list fp32)
 Require p==pointer_offset(base,j,float) && 0<=j && j+1<=len && FloatArray::full(base,len,L)
 Ensure FloatArray::full(base,len,L) * store(&(__return.s0),float,spmm_get(j+0,L)) * store(&(__return.s1),float,spmm_get(j+0,L)) * store(&(__return.s2),float,spmm_get(j+0,L)) * store(&(__return.s3),float,spmm_get(j+0,L)) */;
float32x4_t vfmaq_f32(float32x4_t acc,float32x4_t a,float32x4_t b)
/*@ With (z0:fp32) (z1:fp32) (z2:fp32) (z3:fp32) (x0:fp32) (x1:fp32) (x2:fp32) (x3:fp32) (y0:fp32) (y1:fp32) (y2:fp32) (y3:fp32)
 Require store(&(acc.s0),float,z0) * store(&(acc.s1),float,z1) * store(&(acc.s2),float,z2) * store(&(acc.s3),float,z3) * store(&(a.s0),float,x0) * store(&(a.s1),float,x1) * store(&(a.s2),float,x2) * store(&(a.s3),float,x3) * store(&(b.s0),float,y0) * store(&(b.s1),float,y1) * store(&(b.s2),float,y2) * store(&(b.s3),float,y3)
 Ensure store(&(__return.s0),float,fma_rne(x0,y0,z0)) * store(&(__return.s1),float,fma_rne(x1,y1,z1)) * store(&(__return.s2),float,fma_rne(x2,y2,z2)) * store(&(__return.s3),float,fma_rne(x3,y3,z3)) */;
float32x4_t vminq_f32(float32x4_t a,float32x4_t b)
/*@ With (x0:fp32) (x1:fp32) (x2:fp32) (x3:fp32) (y0:fp32) (y1:fp32) (y2:fp32) (y3:fp32)
 Require store(&(a.s0),float,x0) * store(&(a.s1),float,x1) * store(&(a.s2),float,x2) * store(&(a.s3),float,x3) * store(&(b.s0),float,y0) * store(&(b.s1),float,y1) * store(&(b.s2),float,y2) * store(&(b.s3),float,y3)
 Ensure store(&(__return.s0),float,fp32_neon_min(x0,y0)) * store(&(__return.s1),float,fp32_neon_min(x1,y1)) * store(&(__return.s2),float,fp32_neon_min(x2,y2)) * store(&(__return.s3),float,fp32_neon_min(x3,y3)) */;
float32x4_t vmaxq_f32(float32x4_t a,float32x4_t b)
/*@ With (x0:fp32) (x1:fp32) (x2:fp32) (x3:fp32) (y0:fp32) (y1:fp32) (y2:fp32) (y3:fp32)
 Require store(&(a.s0),float,x0) * store(&(a.s1),float,x1) * store(&(a.s2),float,x2) * store(&(a.s3),float,x3) * store(&(b.s0),float,y0) * store(&(b.s1),float,y1) * store(&(b.s2),float,y2) * store(&(b.s3),float,y3)
 Ensure store(&(__return.s0),float,fp32_neon_max(x0,y0)) * store(&(__return.s1),float,fp32_neon_max(x1,y1)) * store(&(__return.s2),float,fp32_neon_max(x2,y2)) * store(&(__return.s3),float,fp32_neon_max(x3,y3)) */;
void qcp_vst1q_f32(float*p,const float32x4_t*a)
/*@ With (x0:fp32) (x1:fp32) (x2:fp32) (x3:fp32)
 Require store(&(a->s0),float,x0) * store(&(a->s1),float,x1) * store(&(a->s2),float,x2) * store(&(a->s3),float,x3) * FloatArray::undef_full(p,4)
 Ensure store(&(a->s0),float,x0) * store(&(a->s1),float,x1) * store(&(a->s2),float,x2) * store(&(a->s3),float,x3) * FloatArray::full(p,4,cons(x0,cons(x1,cons(x2,cons(x3,nil))))) */;
float32x2_t vld1_f32(const float*p)
/*@ With (base:Z) (len:Z) (j:Z) (L:list fp32)
 Require p==pointer_offset(base,j,float) && 0<=j && j+2<=len && FloatArray::full(base,len,L)
 Ensure FloatArray::full(base,len,L) * store(&(__return.s0),float,spmm_get(j+0,L)) * store(&(__return.s1),float,spmm_get(j+1,L)) */;
float32x2_t vld1_dup_f32(const float*p)
/*@ With (base:Z) (len:Z) (j:Z) (L:list fp32)
 Require p==pointer_offset(base,j,float) && 0<=j && j+1<=len && FloatArray::full(base,len,L)
 Ensure FloatArray::full(base,len,L) * store(&(__return.s0),float,spmm_get(j+0,L)) * store(&(__return.s1),float,spmm_get(j+0,L)) */;
float32x2_t vfma_f32(float32x2_t acc,float32x2_t a,float32x2_t b)
/*@ With (z0:fp32) (z1:fp32) (x0:fp32) (x1:fp32) (y0:fp32) (y1:fp32)
 Require store(&(acc.s0),float,z0) * store(&(acc.s1),float,z1) * store(&(a.s0),float,x0) * store(&(a.s1),float,x1) * store(&(b.s0),float,y0) * store(&(b.s1),float,y1)
 Ensure store(&(__return.s0),float,fma_rne(x0,y0,z0)) * store(&(__return.s1),float,fma_rne(x1,y1,z1)) */;
float32x2_t vmin_f32(float32x2_t a,float32x2_t b)
/*@ With (x0:fp32) (x1:fp32) (y0:fp32) (y1:fp32)
 Require store(&(a.s0),float,x0) * store(&(a.s1),float,x1) * store(&(b.s0),float,y0) * store(&(b.s1),float,y1)
 Ensure store(&(__return.s0),float,fp32_neon_min(x0,y0)) * store(&(__return.s1),float,fp32_neon_min(x1,y1)) */;
float32x2_t vmax_f32(float32x2_t a,float32x2_t b)
/*@ With (x0:fp32) (x1:fp32) (y0:fp32) (y1:fp32)
 Require store(&(a.s0),float,x0) * store(&(a.s1),float,x1) * store(&(b.s0),float,y0) * store(&(b.s1),float,y1)
 Ensure store(&(__return.s0),float,fp32_neon_max(x0,y0)) * store(&(__return.s1),float,fp32_neon_max(x1,y1)) */;
void qcp_vst1_f32(float*p,const float32x2_t*a)
/*@ With (x0:fp32) (x1:fp32)
 Require store(&(a->s0),float,x0) * store(&(a->s1),float,x1) * FloatArray::undef_full(p,2)
 Ensure store(&(a->s0),float,x0) * store(&(a->s1),float,x1) * FloatArray::full(p,2,cons(x0,cons(x1,nil))) */;
float32x2_t vget_low_f32(float32x4_t a)
/*@ With (x0:fp32) (x1:fp32) (x2:fp32) (x3:fp32)
 Require store(&(a.s0),float,x0) * store(&(a.s1),float,x1) * store(&(a.s2),float,x2) * store(&(a.s3),float,x3)
 Ensure store(&(__return.s0),float,x0) * store(&(__return.s1),float,x1) */;
void qcp_vst1_lane_f32(float*p,const float32x2_t*a,int lane)
/*@ With (x0:fp32) (x1:fp32)
 Require lane==0 && store(&(a->s0),float,x0) * store(&(a->s1),float,x1) * FloatArray::undef_full(p,1)
 Ensure store(&(a->s0),float,x0) * store(&(a->s1),float,x1) * FloatArray::full(p,1,cons(x0,nil)) */;
/*
struct xnn_f32_minmax_params {
  struct {
    float min;
    float max;
  } scalar;
};
*/
void test_neon(
    size_t mc,
    size_t nc,
    const float* input,
    const float* weights,
    const int32_t* widx_dmap,
    const uint32_t* nidx_nnzmap,
    float* output,
    size_t output_stride,
    const struct xnn_f32_minmax_params* restrict params)
/*@ With (rows:Z) (start:Z) (a:Z) (NN:list Z) (D:list Z) (A:list fp32) (W:list fp32) (lo:fp32) (hi:fp32)
 Require mc == 4*rows && input == pointer_offset(a,start,float) && spmm_shape(rows,nc,start,NN,D,A,W) && spmm_capacity(rows,nc,output_stride,a,weights,widx_dmap,nidx_nnzmap,output,NN,D,A,W) &&
 FloatArray::full(a,Zlength(A),A) * FloatArray::full(weights,Zlength(W),W) *
 IntArray::full(widx_dmap,Zlength(D),D) * UIntArray::full(nidx_nnzmap,nc,NN) *
 store(&(params->scalar.min),float,lo) * store(&(params->scalar.max),float,hi) * spmm_output(output,rows,nc,output_stride,0,0,0,start,NN,D,A,W,lo,hi)
 Ensure FloatArray::full(a,Zlength(A),A) * FloatArray::full(weights,Zlength(W),W) *
 IntArray::full(widx_dmap,Zlength(D),D) * UIntArray::full(nidx_nnzmap,nc,NN) *
 store(&(params->scalar.min),float,lo) * store(&(params->scalar.max),float,hi) * spmm_output(output,rows,nc,output_stride,rows,0,0,start,NN,D,A,W,lo,hi) */
{
/*@ Assert mc==mc@pre && nc==nc@pre && input==input@pre && weights==weights@pre && widx_dmap==widx_dmap@pre && nidx_nnzmap==nidx_nnzmap@pre && output==output@pre && output_stride==output_stride@pre && params==params@pre && sizeof(float)==4 && sizeof(int)==4 && sizeof(unsigned int)==4 && 0<rows && 0<mc && mc%4==0 && 0<nc && mc==4*rows && input==pointer_offset(a,start,float) && spmm_shape(rows,nc,start,NN,D,A,W) && spmm_capacity(rows,nc,output_stride,a,weights,widx_dmap,nidx_nnzmap,output,NN,D,A,W) && FloatArray::full(a,Zlength(A),A) * FloatArray::full(weights,Zlength(W),W) * IntArray::full(widx_dmap,Zlength(D),D) * UIntArray::full(nidx_nnzmap,nc,NN) * store(&(params->scalar.min),float,lo) * store(&(params->scalar.max),float,hi) * spmm_output(output,rows,nc,output_stride,0,0,0,start,NN,D,A,W,lo,hi) */
qcp_assert(mc != 0);
  qcp_assert(mc % sizeof(float) == 0);
  qcp_assert(nc != 0);
    const float32x4x2_t vminmax = vld2q_dup_f32(&params->scalar.min)
/*@ where owner=params */
;
    const float32x4_t vmin = vminmax.val[0];
    const float32x4_t vmax = vminmax.val[1];
  size_t output_decrement = output_stride * nc - 4 * sizeof(float);
/*@ Inv Assert 0<nc && 0<rows && sizeof(float)==4 && sizeof(int)==4 && sizeof(unsigned int)==4 && mc@pre==4*rows && nc==nc@pre && weights==weights@pre && widx_dmap==widx_dmap@pre && nidx_nnzmap==nidx_nnzmap@pre && output_stride==output_stride@pre && params==params@pre && spmm_shape(rows,nc,start,NN,D,A,W) && spmm_capacity(rows,nc,output_stride,a,weights,widx_dmap,nidx_nnzmap,output@pre,NN,D,A,W) && 0<=mc && mc<=mc@pre && mc%4==0 && output_decrement==word64(word64(output_stride*nc)-16) && input==pointer_offset(a,start+(rows-mc/4),float) && output==spmm_output_cursor(output@pre,(rows-mc/4),output_stride,0) && FloatArray::full(a,Zlength(A),A) * FloatArray::full(weights,Zlength(W),W) * IntArray::full(widx_dmap,Zlength(D),D) * UIntArray::full(nidx_nnzmap,nc,NN) * store(&(params->scalar.min),float,lo) * store(&(params->scalar.max),float,hi) * store(&(vmin.s0),float,lo) * store(&(vmin.s1),float,lo) * store(&(vmin.s2),float,lo) * store(&(vmin.s3),float,lo) * store(&(vmax.s0),float,hi) * store(&(vmax.s1),float,hi) * store(&(vmax.s2),float,hi) * store(&(vmax.s3),float,hi) * StructPredfloat32x4x2_t(&vminmax,tuple_record(cons(vec4(lo,lo,lo,lo),cons(vec4(hi,hi,hi,hi),nil)))) * spmm_output(output@pre,rows,nc,output_stride,(rows-mc/4),0,0,start,NN,D,A,W,lo,hi) */
while (mc >= 4 * sizeof(float)) {
    const float* w = weights;
    const int32_t* dmap = widx_dmap;
    const uint32_t* nnzmap = nidx_nnzmap;
    size_t n = nc;
/*@ Assert 0<nc && 0<rows && sizeof(float)==4 && sizeof(int)==4 && sizeof(unsigned int)==4 && mc@pre==4*rows && nc==nc@pre && weights==weights@pre && widx_dmap==widx_dmap@pre && nidx_nnzmap==nidx_nnzmap@pre && output_stride==output_stride@pre && params==params@pre && spmm_shape(rows,nc,start,NN,D,A,W) && spmm_capacity(rows,nc,output_stride,a,weights,widx_dmap,nidx_nnzmap,output@pre,NN,D,A,W) && 0<=mc && mc<=mc@pre && mc%4==0 && 0<mc && 0<=(rows-mc/4) && (rows-mc/4)+4<=rows && output_decrement==word64(word64(output_stride*nc)-16) && 16<=mc && 0<n && n<=nc && w==pointer_offset(weights,bias_index(NN,(nc-n)),float) && dmap==pointer_offset(widx_dmap,nnz_before(NN,(nc-n)),int) && nnzmap==pointer_offset(nidx_nnzmap,(nc-n),unsigned int) && input==pointer_offset(a,input_index(D,start,(rows-mc/4),nnz_before(NN,(nc-n))),float) && output==spmm_output_cursor(output@pre,(rows-mc/4),output_stride,(nc-n)) && FloatArray::full(a,Zlength(A),A) * FloatArray::full(weights,Zlength(W),W) * IntArray::full(widx_dmap,Zlength(D),D) * UIntArray::full(nidx_nnzmap,nc,NN) * store(&(params->scalar.min),float,lo) * store(&(params->scalar.max),float,hi) * store(&(vmin.s0),float,lo) * store(&(vmin.s1),float,lo) * store(&(vmin.s2),float,lo) * store(&(vmin.s3),float,lo) * store(&(vmax.s0),float,hi) * store(&(vmax.s1),float,hi) * store(&(vmax.s2),float,hi) * store(&(vmax.s3),float,hi) * StructPredfloat32x4x2_t(&vminmax,tuple_record(cons(vec4(lo,lo,lo,lo),cons(vec4(hi,hi,hi,hi),nil)))) * spmm_output(output@pre,rows,nc,output_stride,(rows-mc/4),(nc-n),4,start,NN,D,A,W,lo,hi) */
do {
/*@ spmm_shape(rows,nc,start,NN,D,A,W) && 0<n && n<=nc && nnzmap==pointer_offset(nidx_nnzmap,(nc-n),unsigned int) && UIntArray::full(nidx_nnzmap,nc,NN) which implies spmm_shape(rows,nc,start,NN,D,A,W) && 0<n && n<=nc && nnzmap==pointer_offset(nidx_nnzmap,(nc-n),unsigned int) && 0<=(nc-n) && (nc-n)<nc && UIntArray::missing_i(nidx_nnzmap,(nc-n),0,nc,NN) * store(nnzmap,unsigned int,NN[(nc-n)]) */
uint32_t nnz = *nnzmap; nnzmap += 1;
/*@ spmm_shape(rows,nc,start,NN,D,A,W) && 0<n && n<=nc && w==pointer_offset(weights,bias_index(NN,(nc-n)),float) && FloatArray::full(weights,Zlength(W),W) which implies spmm_shape(rows,nc,start,NN,D,A,W) && 0<n && n<=nc && w==pointer_offset(weights,bias_index(NN,(nc-n)),float) && 0<=bias_index(NN,(nc-n)) && bias_index(NN,(nc-n))+1<=Zlength(W) && FloatArray::full(weights,Zlength(W),W) */
float32x4_t vacc0123 = vld1q_dup_f32(w)
/*@ where base=weights,len=Zlength(W),j=bias_index(NN,(nc-n)),L=W */
; w += 1;
      if (nnz != 0) {
        do {
/*@ spmm_shape(rows,nc,start,NN,D,A,W) && 0<n && n<=nc && 0<nnz && nnz<=NN[(nc-n)] && dmap==pointer_offset(widx_dmap,(nnz_before(NN,(nc-n))+(NN[(nc-n)]-nnz)),int) && IntArray::full(widx_dmap,Zlength(D),D) which implies spmm_shape(rows,nc,start,NN,D,A,W) && 0<n && n<=nc && 0<nnz && nnz<=NN[(nc-n)] && dmap==pointer_offset(widx_dmap,(nnz_before(NN,(nc-n))+(NN[(nc-n)]-nnz)),int) && 0<=(nnz_before(NN,(nc-n))+(NN[(nc-n)]-nnz)) && (nnz_before(NN,(nc-n))+(NN[(nc-n)]-nnz))<Zlength(D) && IntArray::missing_i(widx_dmap,(nnz_before(NN,(nc-n))+(NN[(nc-n)]-nnz)),0,Zlength(D),D) * store(dmap,int,D[(nnz_before(NN,(nc-n))+(NN[(nc-n)]-nnz))]) */
const intptr_t diff = *dmap; dmap += 1;
/*@ spmm_shape(rows,nc,start,NN,D,A,W) && 0<n && n<=nc && 0<nnz && nnz<=z_at(NN,(nc-n)) && 0<=(rows-mc/4) && (rows-mc/4)+4<=rows && input==pointer_offset(a,input_index(D,start,(rows-mc/4),(nnz_before(NN,(nc-n))+(z_at(NN,(nc-n))-nnz))),float) && FloatArray::full(a,Zlength(A),A) which implies spmm_shape(rows,nc,start,NN,D,A,W) && 0<n && n<=nc && 0<nnz && nnz<=z_at(NN,(nc-n)) && 0<=(rows-mc/4) && (rows-mc/4)+4<=rows && input==pointer_offset(a,input_index(D,start,(rows-mc/4),(nnz_before(NN,(nc-n))+(z_at(NN,(nc-n))-nnz))),float) && 0<=input_index(D,start,(rows-mc/4),(nnz_before(NN,(nc-n))+(z_at(NN,(nc-n))-nnz))) && input_index(D,start,(rows-mc/4),(nnz_before(NN,(nc-n))+(z_at(NN,(nc-n))-nnz)))+4<=Zlength(A) && FloatArray::full(a,Zlength(A),A) */
const float32x4_t vi0123 = vld1q_f32(input)
/*@ where base=a,len=Zlength(A),j=input_index(D,start,(rows-mc/4),(nnz_before(NN,(nc-n))+(z_at(NN,(nc-n))-nnz))),L=A */
;
          input = (const float*) ((uintptr_t) input + (uintptr_t) diff);
          xnn_prefetch_to_l1(input + 16);
/*@ spmm_shape(rows,nc,start,NN,D,A,W) && 0<n && n<=nc && w==pointer_offset(weights,(bias_index(NN,(nc-n))+1+(z_at(NN,(nc-n))-nnz)),float) && 0<nnz && nnz<=z_at(NN,(nc-n)) && FloatArray::full(weights,Zlength(W),W) which implies spmm_shape(rows,nc,start,NN,D,A,W) && 0<n && n<=nc && w==pointer_offset(weights,(bias_index(NN,(nc-n))+1+(z_at(NN,(nc-n))-nnz)),float) && 0<nnz && nnz<=z_at(NN,(nc-n)) && 0<=(bias_index(NN,(nc-n))+1+(z_at(NN,(nc-n))-nnz)) && (bias_index(NN,(nc-n))+1+(z_at(NN,(nc-n))-nnz))+1<=Zlength(W) && FloatArray::full(weights,Zlength(W),W) */
const float32x4_t vw = vld1q_dup_f32(w)
/*@ where base=weights,len=Zlength(W),j=(bias_index(NN,(nc-n))+1+(z_at(NN,(nc-n))-nnz)),L=W */
; w += 1;
          xnn_prefetch_to_l1(w + 32);
          vacc0123 = vfmaq_f32(vacc0123, vi0123, vw)
/*@ where acc=&vacc0123,a=&vi0123,b=&vw */
;
          nnz -= 1;
        }
/*@ Inv Assert 0<nc && 0<rows && sizeof(float)==4 && sizeof(int)==4 && sizeof(unsigned int)==4 && mc@pre==4*rows && nc==nc@pre && weights==weights@pre && widx_dmap==widx_dmap@pre && nidx_nnzmap==nidx_nnzmap@pre && output_stride==output_stride@pre && params==params@pre && spmm_shape(rows,nc,start,NN,D,A,W) && spmm_capacity(rows,nc,output_stride,a,weights,widx_dmap,nidx_nnzmap,output@pre,NN,D,A,W) && 0<=mc && mc<=mc@pre && mc%4==0 && 0<mc && 0<=(rows-mc/4) && (rows-mc/4)+4<=rows && output_decrement==word64(word64(output_stride*nc)-16) && 16<=mc && 0<n && n<=nc && 0<=nnz && nnz<=z_at(NN,(nc-n)) && w==pointer_offset(weights,bias_index(NN,(nc-n))+1+(z_at(NN,(nc-n))-nnz),float) && dmap==pointer_offset(widx_dmap,(nnz_before(NN,(nc-n))+(z_at(NN,(nc-n))-nnz)),int) && nnzmap==pointer_offset(nidx_nnzmap,(nc-n)+1,unsigned int) && input==pointer_offset(a,input_index(D,start,(rows-mc/4),(nnz_before(NN,(nc-n))+(z_at(NN,(nc-n))-nnz))),float) && output==spmm_output_cursor(output@pre,(rows-mc/4),output_stride,(nc-n)) && FloatArray::full(a,Zlength(A),A) * FloatArray::full(weights,Zlength(W),W) * IntArray::full(widx_dmap,Zlength(D),D) * UIntArray::full(nidx_nnzmap,nc,NN) * store(&(params->scalar.min),float,lo) * store(&(params->scalar.max),float,hi) * store(&(vmin.s0),float,lo) * store(&(vmin.s1),float,lo) * store(&(vmin.s2),float,lo) * store(&(vmin.s3),float,lo) * store(&(vmax.s0),float,hi) * store(&(vmax.s1),float,hi) * store(&(vmax.s2),float,hi) * store(&(vmax.s3),float,hi) * StructPredfloat32x4x2_t(&vminmax,tuple_record(cons(vec4(lo,lo,lo,lo),cons(vec4(hi,hi,hi,hi),nil)))) * spmm_output(output@pre,rows,nc,output_stride,(rows-mc/4),(nc-n),4,start,NN,D,A,W,lo,hi) * store(&(vacc0123.s0),float,spmm_acc((z_at(NN,(nc-n))-nnz),(nc-n),(rows-mc/4)+0,start,NN,D,A,W)) * store(&(vacc0123.s1),float,spmm_acc((z_at(NN,(nc-n))-nnz),(nc-n),(rows-mc/4)+1,start,NN,D,A,W)) * store(&(vacc0123.s2),float,spmm_acc((z_at(NN,(nc-n))-nnz),(nc-n),(rows-mc/4)+2,start,NN,D,A,W)) * store(&(vacc0123.s3),float,spmm_acc((z_at(NN,(nc-n))-nnz),(nc-n),(rows-mc/4)+3,start,NN,D,A,W)) */
while (nnz != 0);
      }
      float32x4_t vout0123 = vminq_f32(vacc0123, vmax)
/*@ where a=&vacc0123,b=&vmax */
;
      vout0123 = vmaxq_f32(vout0123, vmin)
/*@ where a=&vout0123,b=&vmin */
;
/*@ 0<nc && 0<rows && sizeof(float)==4 && sizeof(int)==4 && sizeof(unsigned int)==4 && mc@pre==4*rows && nc==nc@pre && weights==weights@pre && widx_dmap==widx_dmap@pre && nidx_nnzmap==nidx_nnzmap@pre && output_stride==output_stride@pre && params==params@pre && spmm_shape(rows,nc,start,NN,D,A,W) && spmm_capacity(rows,nc,output_stride,a,weights,widx_dmap,nidx_nnzmap,output@pre,NN,D,A,W) && 0<=mc && mc<=mc@pre && mc%4==0 && 0<mc && 0<=(rows-mc/4) && (rows-mc/4)+4<=rows && output_decrement==word64(word64(output_stride*nc)-16) && 16<=mc && 0<n && n<=nc && output==spmm_output_cursor(output@pre,(rows-mc/4),output_stride,(nc-n)) && spmm_output(output@pre,rows,nc,output_stride,(rows-mc/4),(nc-n),4,start,NN,D,A,W,lo,hi) which implies 0<nc && 0<rows && sizeof(float)==4 && sizeof(int)==4 && sizeof(unsigned int)==4 && mc@pre==4*rows && nc==nc@pre && weights==weights@pre && widx_dmap==widx_dmap@pre && nidx_nnzmap==nidx_nnzmap@pre && output_stride==output_stride@pre && params==params@pre && spmm_shape(rows,nc,start,NN,D,A,W) && spmm_capacity(rows,nc,output_stride,a,weights,widx_dmap,nidx_nnzmap,output@pre,NN,D,A,W) && 0<=mc && mc<=mc@pre && mc%4==0 && 0<mc && 0<=(rows-mc/4) && (rows-mc/4)+4<=rows && output_decrement==word64(word64(output_stride*nc)-16) && 16<=mc && 0<n && n<=nc && output==spmm_output_cursor(output@pre,(rows-mc/4),output_stride,(nc-n)) && spmm_output_hole(output@pre,rows,nc,output_stride,(rows-mc/4),(nc-n),4,start,NN,D,A,W,lo,hi) * FloatArray::undef_full(output,4) */
qcp_vst1q_f32((output),&(vout0123));
      output = (float*) ((uintptr_t) output + output_stride);
      n -= 1;
    }
/*@ Inv Assert 0<nc && 0<rows && sizeof(float)==4 && sizeof(int)==4 && sizeof(unsigned int)==4 && mc@pre==4*rows && nc==nc@pre && weights==weights@pre && widx_dmap==widx_dmap@pre && nidx_nnzmap==nidx_nnzmap@pre && output_stride==output_stride@pre && params==params@pre && spmm_shape(rows,nc,start,NN,D,A,W) && spmm_capacity(rows,nc,output_stride,a,weights,widx_dmap,nidx_nnzmap,output@pre,NN,D,A,W) && 0<=mc && mc<=mc@pre && mc%4==0 && 0<mc && 0<=(rows-mc/4) && (rows-mc/4)+4<=rows && output_decrement==word64(word64(output_stride*nc)-16) && 16<=mc && 0<=n && n<=nc && w==pointer_offset(weights,bias_index(NN,(nc-n)),float) && dmap==pointer_offset(widx_dmap,nnz_before(NN,(nc-n)),int) && nnzmap==pointer_offset(nidx_nnzmap,(nc-n),unsigned int) && input==pointer_offset(a,input_index(D,start,(rows-mc/4),nnz_before(NN,(nc-n))),float) && output==spmm_output_cursor(output@pre,(rows-mc/4),output_stride,(nc-n)) && FloatArray::full(a,Zlength(A),A) * FloatArray::full(weights,Zlength(W),W) * IntArray::full(widx_dmap,Zlength(D),D) * UIntArray::full(nidx_nnzmap,nc,NN) * store(&(params->scalar.min),float,lo) * store(&(params->scalar.max),float,hi) * store(&(vmin.s0),float,lo) * store(&(vmin.s1),float,lo) * store(&(vmin.s2),float,lo) * store(&(vmin.s3),float,lo) * store(&(vmax.s0),float,hi) * store(&(vmax.s1),float,hi) * store(&(vmax.s2),float,hi) * store(&(vmax.s3),float,hi) * StructPredfloat32x4x2_t(&vminmax,tuple_record(cons(vec4(lo,lo,lo,lo),cons(vec4(hi,hi,hi,hi),nil)))) * spmm_output(output@pre,rows,nc,output_stride,(rows-mc/4),(nc-n),4,start,NN,D,A,W,lo,hi) */
while (n != 0);
    output = (float*) ((uintptr_t) output - output_decrement);
    input += 4;
    mc -= 4 * sizeof(float);
  }
  if (mc != 0) {
    output_decrement += 2 * sizeof(float);
    if (mc & (2 * sizeof(float))) {
      const float* w = weights;
      const int32_t* dmap = widx_dmap;
      const uint32_t* nnzmap = nidx_nnzmap;
      size_t n = nc;
/*@ Assert 0<nc && 0<rows && sizeof(float)==4 && sizeof(int)==4 && sizeof(unsigned int)==4 && mc@pre==4*rows && nc==nc@pre && weights==weights@pre && widx_dmap==widx_dmap@pre && nidx_nnzmap==nidx_nnzmap@pre && output_stride==output_stride@pre && params==params@pre && spmm_shape(rows,nc,start,NN,D,A,W) && spmm_capacity(rows,nc,output_stride,a,weights,widx_dmap,nidx_nnzmap,output@pre,NN,D,A,W) && 0<=mc && mc<=mc@pre && mc%4==0 && 0<mc && 0<=(rows-mc/4) && (rows-mc/4)+2<=rows && output_decrement==word64(word64(output_stride*nc)-8) && mc<16 && 0<n && n<=nc && w==pointer_offset(weights,bias_index(NN,(nc-n)),float) && dmap==pointer_offset(widx_dmap,nnz_before(NN,(nc-n)),int) && nnzmap==pointer_offset(nidx_nnzmap,(nc-n),unsigned int) && input==pointer_offset(a,input_index(D,start,(rows-mc/4),nnz_before(NN,(nc-n))),float) && output==spmm_output_cursor(output@pre,(rows-mc/4),output_stride,(nc-n)) && FloatArray::full(a,Zlength(A),A) * FloatArray::full(weights,Zlength(W),W) * IntArray::full(widx_dmap,Zlength(D),D) * UIntArray::full(nidx_nnzmap,nc,NN) * store(&(params->scalar.min),float,lo) * store(&(params->scalar.max),float,hi) * store(&(vmin.s0),float,lo) * store(&(vmin.s1),float,lo) * store(&(vmin.s2),float,lo) * store(&(vmin.s3),float,lo) * store(&(vmax.s0),float,hi) * store(&(vmax.s1),float,hi) * store(&(vmax.s2),float,hi) * store(&(vmax.s3),float,hi) * StructPredfloat32x4x2_t(&vminmax,tuple_record(cons(vec4(lo,lo,lo,lo),cons(vec4(hi,hi,hi,hi),nil)))) * spmm_output(output@pre,rows,nc,output_stride,(rows-mc/4),(nc-n),2,start,NN,D,A,W,lo,hi) */
do {
/*@ spmm_shape(rows,nc,start,NN,D,A,W) && 0<n && n<=nc && nnzmap==pointer_offset(nidx_nnzmap,(nc-n),unsigned int) && UIntArray::full(nidx_nnzmap,nc,NN) which implies spmm_shape(rows,nc,start,NN,D,A,W) && 0<n && n<=nc && nnzmap==pointer_offset(nidx_nnzmap,(nc-n),unsigned int) && 0<=(nc-n) && (nc-n)<nc && UIntArray::missing_i(nidx_nnzmap,(nc-n),0,nc,NN) * store(nnzmap,unsigned int,NN[(nc-n)]) */
uint32_t nnz = *nnzmap; nnzmap += 1;
/*@ spmm_shape(rows,nc,start,NN,D,A,W) && 0<n && n<=nc && w==pointer_offset(weights,bias_index(NN,(nc-n)),float) && FloatArray::full(weights,Zlength(W),W) which implies spmm_shape(rows,nc,start,NN,D,A,W) && 0<n && n<=nc && w==pointer_offset(weights,bias_index(NN,(nc-n)),float) && 0<=bias_index(NN,(nc-n)) && bias_index(NN,(nc-n))+1<=Zlength(W) && FloatArray::full(weights,Zlength(W),W) */
float32x2_t vacc01 = vld1_dup_f32(w)
/*@ where base=weights,len=Zlength(W),j=bias_index(NN,(nc-n)),L=W */
; w += 1;
        if (nnz != 0) {
          do {
/*@ spmm_shape(rows,nc,start,NN,D,A,W) && 0<n && n<=nc && 0<nnz && nnz<=NN[(nc-n)] && dmap==pointer_offset(widx_dmap,(nnz_before(NN,(nc-n))+(NN[(nc-n)]-nnz)),int) && IntArray::full(widx_dmap,Zlength(D),D) which implies spmm_shape(rows,nc,start,NN,D,A,W) && 0<n && n<=nc && 0<nnz && nnz<=NN[(nc-n)] && dmap==pointer_offset(widx_dmap,(nnz_before(NN,(nc-n))+(NN[(nc-n)]-nnz)),int) && 0<=(nnz_before(NN,(nc-n))+(NN[(nc-n)]-nnz)) && (nnz_before(NN,(nc-n))+(NN[(nc-n)]-nnz))<Zlength(D) && IntArray::missing_i(widx_dmap,(nnz_before(NN,(nc-n))+(NN[(nc-n)]-nnz)),0,Zlength(D),D) * store(dmap,int,D[(nnz_before(NN,(nc-n))+(NN[(nc-n)]-nnz))]) */
const intptr_t diff = *dmap; dmap += 1;
/*@ spmm_shape(rows,nc,start,NN,D,A,W) && 0<n && n<=nc && 0<nnz && nnz<=z_at(NN,(nc-n)) && 0<=(rows-mc/4) && (rows-mc/4)+2<=rows && input==pointer_offset(a,input_index(D,start,(rows-mc/4),(nnz_before(NN,(nc-n))+(z_at(NN,(nc-n))-nnz))),float) && FloatArray::full(a,Zlength(A),A) which implies spmm_shape(rows,nc,start,NN,D,A,W) && 0<n && n<=nc && 0<nnz && nnz<=z_at(NN,(nc-n)) && 0<=(rows-mc/4) && (rows-mc/4)+2<=rows && input==pointer_offset(a,input_index(D,start,(rows-mc/4),(nnz_before(NN,(nc-n))+(z_at(NN,(nc-n))-nnz))),float) && 0<=input_index(D,start,(rows-mc/4),(nnz_before(NN,(nc-n))+(z_at(NN,(nc-n))-nnz))) && input_index(D,start,(rows-mc/4),(nnz_before(NN,(nc-n))+(z_at(NN,(nc-n))-nnz)))+2<=Zlength(A) && FloatArray::full(a,Zlength(A),A) */
const float32x2_t vi01 = vld1_f32(input)
/*@ where base=a,len=Zlength(A),j=input_index(D,start,(rows-mc/4),(nnz_before(NN,(nc-n))+(z_at(NN,(nc-n))-nnz))),L=A */
;
            input = (const float*) ((uintptr_t) input + (uintptr_t) diff);
/*@ spmm_shape(rows,nc,start,NN,D,A,W) && 0<n && n<=nc && w==pointer_offset(weights,(bias_index(NN,(nc-n))+1+(z_at(NN,(nc-n))-nnz)),float) && 0<nnz && nnz<=z_at(NN,(nc-n)) && FloatArray::full(weights,Zlength(W),W) which implies spmm_shape(rows,nc,start,NN,D,A,W) && 0<n && n<=nc && w==pointer_offset(weights,(bias_index(NN,(nc-n))+1+(z_at(NN,(nc-n))-nnz)),float) && 0<nnz && nnz<=z_at(NN,(nc-n)) && 0<=(bias_index(NN,(nc-n))+1+(z_at(NN,(nc-n))-nnz)) && (bias_index(NN,(nc-n))+1+(z_at(NN,(nc-n))-nnz))+1<=Zlength(W) && FloatArray::full(weights,Zlength(W),W) */
const float32x2_t vw = vld1_dup_f32(w)
/*@ where base=weights,len=Zlength(W),j=(bias_index(NN,(nc-n))+1+(z_at(NN,(nc-n))-nnz)),L=W */
; w += 1;
            vacc01 = vfma_f32(vacc01, vi01, vw)
/*@ where acc=&vacc01,a=&vi01,b=&vw */
;
            nnz -= 1;
          }
/*@ Inv Assert 0<nc && 0<rows && sizeof(float)==4 && sizeof(int)==4 && sizeof(unsigned int)==4 && mc@pre==4*rows && nc==nc@pre && weights==weights@pre && widx_dmap==widx_dmap@pre && nidx_nnzmap==nidx_nnzmap@pre && output_stride==output_stride@pre && params==params@pre && spmm_shape(rows,nc,start,NN,D,A,W) && spmm_capacity(rows,nc,output_stride,a,weights,widx_dmap,nidx_nnzmap,output@pre,NN,D,A,W) && 0<=mc && mc<=mc@pre && mc%4==0 && 0<mc && 0<=(rows-mc/4) && (rows-mc/4)+2<=rows && output_decrement==word64(word64(output_stride*nc)-8) && mc<16 && 0<n && n<=nc && 0<=nnz && nnz<=z_at(NN,(nc-n)) && w==pointer_offset(weights,bias_index(NN,(nc-n))+1+(z_at(NN,(nc-n))-nnz),float) && dmap==pointer_offset(widx_dmap,(nnz_before(NN,(nc-n))+(z_at(NN,(nc-n))-nnz)),int) && nnzmap==pointer_offset(nidx_nnzmap,(nc-n)+1,unsigned int) && input==pointer_offset(a,input_index(D,start,(rows-mc/4),(nnz_before(NN,(nc-n))+(z_at(NN,(nc-n))-nnz))),float) && output==spmm_output_cursor(output@pre,(rows-mc/4),output_stride,(nc-n)) && FloatArray::full(a,Zlength(A),A) * FloatArray::full(weights,Zlength(W),W) * IntArray::full(widx_dmap,Zlength(D),D) * UIntArray::full(nidx_nnzmap,nc,NN) * store(&(params->scalar.min),float,lo) * store(&(params->scalar.max),float,hi) * store(&(vmin.s0),float,lo) * store(&(vmin.s1),float,lo) * store(&(vmin.s2),float,lo) * store(&(vmin.s3),float,lo) * store(&(vmax.s0),float,hi) * store(&(vmax.s1),float,hi) * store(&(vmax.s2),float,hi) * store(&(vmax.s3),float,hi) * StructPredfloat32x4x2_t(&vminmax,tuple_record(cons(vec4(lo,lo,lo,lo),cons(vec4(hi,hi,hi,hi),nil)))) * spmm_output(output@pre,rows,nc,output_stride,(rows-mc/4),(nc-n),2,start,NN,D,A,W,lo,hi) * store(&(vacc01.s0),float,spmm_acc((z_at(NN,(nc-n))-nnz),(nc-n),(rows-mc/4)+0,start,NN,D,A,W)) * store(&(vacc01.s1),float,spmm_acc((z_at(NN,(nc-n))-nnz),(nc-n),(rows-mc/4)+1,start,NN,D,A,W)) */
while (nnz != 0);
        }
        float32x2_t vout01 = vmin_f32(vacc01, vget_low_f32(vmax)
/*@ where a=&vmax */
)
/*@ where a=&vacc01,b=0 */
;
        vout01 = vmax_f32(vout01, vget_low_f32(vmin)
/*@ where a=&vmin */
)
/*@ where a=&vout01,b=0 */
;
/*@ 0<nc && 0<rows && sizeof(float)==4 && sizeof(int)==4 && sizeof(unsigned int)==4 && mc@pre==4*rows && nc==nc@pre && weights==weights@pre && widx_dmap==widx_dmap@pre && nidx_nnzmap==nidx_nnzmap@pre && output_stride==output_stride@pre && params==params@pre && spmm_shape(rows,nc,start,NN,D,A,W) && spmm_capacity(rows,nc,output_stride,a,weights,widx_dmap,nidx_nnzmap,output@pre,NN,D,A,W) && 0<=mc && mc<=mc@pre && mc%4==0 && 0<mc && 0<=(rows-mc/4) && (rows-mc/4)+2<=rows && output_decrement==word64(word64(output_stride*nc)-8) && mc<16 && 0<n && n<=nc && output==spmm_output_cursor(output@pre,(rows-mc/4),output_stride,(nc-n)) && spmm_output(output@pre,rows,nc,output_stride,(rows-mc/4),(nc-n),2,start,NN,D,A,W,lo,hi) which implies 0<nc && 0<rows && sizeof(float)==4 && sizeof(int)==4 && sizeof(unsigned int)==4 && mc@pre==4*rows && nc==nc@pre && weights==weights@pre && widx_dmap==widx_dmap@pre && nidx_nnzmap==nidx_nnzmap@pre && output_stride==output_stride@pre && params==params@pre && spmm_shape(rows,nc,start,NN,D,A,W) && spmm_capacity(rows,nc,output_stride,a,weights,widx_dmap,nidx_nnzmap,output@pre,NN,D,A,W) && 0<=mc && mc<=mc@pre && mc%4==0 && 0<mc && 0<=(rows-mc/4) && (rows-mc/4)+2<=rows && output_decrement==word64(word64(output_stride*nc)-8) && mc<16 && 0<n && n<=nc && output==spmm_output_cursor(output@pre,(rows-mc/4),output_stride,(nc-n)) && spmm_output_hole(output@pre,rows,nc,output_stride,(rows-mc/4),(nc-n),2,start,NN,D,A,W,lo,hi) * FloatArray::undef_full(output,2) */
qcp_vst1_f32((output),&(vout01));
        output = (float*) ((uintptr_t) output + output_stride);
        n -= 1;
      }
/*@ Inv Assert 0<nc && 0<rows && sizeof(float)==4 && sizeof(int)==4 && sizeof(unsigned int)==4 && mc@pre==4*rows && nc==nc@pre && weights==weights@pre && widx_dmap==widx_dmap@pre && nidx_nnzmap==nidx_nnzmap@pre && output_stride==output_stride@pre && params==params@pre && spmm_shape(rows,nc,start,NN,D,A,W) && spmm_capacity(rows,nc,output_stride,a,weights,widx_dmap,nidx_nnzmap,output@pre,NN,D,A,W) && 0<=mc && mc<=mc@pre && mc%4==0 && 0<mc && 0<=(rows-mc/4) && (rows-mc/4)+2<=rows && output_decrement==word64(word64(output_stride*nc)-8) && mc<16 && 0<=n && n<=nc && w==pointer_offset(weights,bias_index(NN,(nc-n)),float) && dmap==pointer_offset(widx_dmap,nnz_before(NN,(nc-n)),int) && nnzmap==pointer_offset(nidx_nnzmap,(nc-n),unsigned int) && input==pointer_offset(a,input_index(D,start,(rows-mc/4),nnz_before(NN,(nc-n))),float) && output==spmm_output_cursor(output@pre,(rows-mc/4),output_stride,(nc-n)) && FloatArray::full(a,Zlength(A),A) * FloatArray::full(weights,Zlength(W),W) * IntArray::full(widx_dmap,Zlength(D),D) * UIntArray::full(nidx_nnzmap,nc,NN) * store(&(params->scalar.min),float,lo) * store(&(params->scalar.max),float,hi) * store(&(vmin.s0),float,lo) * store(&(vmin.s1),float,lo) * store(&(vmin.s2),float,lo) * store(&(vmin.s3),float,lo) * store(&(vmax.s0),float,hi) * store(&(vmax.s1),float,hi) * store(&(vmax.s2),float,hi) * store(&(vmax.s3),float,hi) * StructPredfloat32x4x2_t(&vminmax,tuple_record(cons(vec4(lo,lo,lo,lo),cons(vec4(hi,hi,hi,hi),nil)))) * spmm_output(output@pre,rows,nc,output_stride,(rows-mc/4),(nc-n),2,start,NN,D,A,W,lo,hi) */
while (n != 0);
      output = (float*) ((uintptr_t) output - output_decrement);
      input += 2;
    }
    output_decrement += 1 * sizeof(float);
    if (mc & (1 * sizeof(float))) {
      const float* w = weights;
      const int32_t* dmap = widx_dmap;
      const uint32_t* nnzmap = nidx_nnzmap;
      size_t n = nc;
/*@ Assert 0<nc && 0<rows && sizeof(float)==4 && sizeof(int)==4 && sizeof(unsigned int)==4 && mc@pre==4*rows && nc==nc@pre && weights==weights@pre && widx_dmap==widx_dmap@pre && nidx_nnzmap==nidx_nnzmap@pre && output_stride==output_stride@pre && params==params@pre && spmm_shape(rows,nc,start,NN,D,A,W) && spmm_capacity(rows,nc,output_stride,a,weights,widx_dmap,nidx_nnzmap,output@pre,NN,D,A,W) && 0<=mc && mc<=mc@pre && mc%4==0 && 0<mc && 0<=(rows-1) && (rows-1)+1<=rows && output_decrement==word64(word64(output_stride*nc)-4) && mc<16 && 0<n && n<=nc && w==pointer_offset(weights,bias_index(NN,(nc-n)),float) && dmap==pointer_offset(widx_dmap,nnz_before(NN,(nc-n)),int) && nnzmap==pointer_offset(nidx_nnzmap,(nc-n),unsigned int) && input==pointer_offset(a,input_index(D,start,(rows-1),nnz_before(NN,(nc-n))),float) && output==spmm_output_cursor(output@pre,(rows-1),output_stride,(nc-n)) && FloatArray::full(a,Zlength(A),A) * FloatArray::full(weights,Zlength(W),W) * IntArray::full(widx_dmap,Zlength(D),D) * UIntArray::full(nidx_nnzmap,nc,NN) * store(&(params->scalar.min),float,lo) * store(&(params->scalar.max),float,hi) * store(&(vmin.s0),float,lo) * store(&(vmin.s1),float,lo) * store(&(vmin.s2),float,lo) * store(&(vmin.s3),float,lo) * store(&(vmax.s0),float,hi) * store(&(vmax.s1),float,hi) * store(&(vmax.s2),float,hi) * store(&(vmax.s3),float,hi) * StructPredfloat32x4x2_t(&vminmax,tuple_record(cons(vec4(lo,lo,lo,lo),cons(vec4(hi,hi,hi,hi),nil)))) * spmm_output(output@pre,rows,nc,output_stride,(rows-1),(nc-n),1,start,NN,D,A,W,lo,hi) */
do {
/*@ spmm_shape(rows,nc,start,NN,D,A,W) && 0<n && n<=nc && nnzmap==pointer_offset(nidx_nnzmap,(nc-n),unsigned int) && UIntArray::full(nidx_nnzmap,nc,NN) which implies spmm_shape(rows,nc,start,NN,D,A,W) && 0<n && n<=nc && nnzmap==pointer_offset(nidx_nnzmap,(nc-n),unsigned int) && 0<=(nc-n) && (nc-n)<nc && UIntArray::missing_i(nidx_nnzmap,(nc-n),0,nc,NN) * store(nnzmap,unsigned int,NN[(nc-n)]) */
uint32_t nnz = *nnzmap; nnzmap += 1;
/*@ spmm_shape(rows,nc,start,NN,D,A,W) && 0<n && n<=nc && w==pointer_offset(weights,bias_index(NN,(nc-n)),float) && FloatArray::full(weights,Zlength(W),W) which implies spmm_shape(rows,nc,start,NN,D,A,W) && 0<n && n<=nc && w==pointer_offset(weights,bias_index(NN,(nc-n)),float) && 0<=bias_index(NN,(nc-n)) && bias_index(NN,(nc-n))+1<=Zlength(W) && FloatArray::full(weights,Zlength(W),W) */
float32x2_t vacc0 = vld1_dup_f32(w)
/*@ where base=weights,len=Zlength(W),j=bias_index(NN,(nc-n)),L=W */
; w += 1;
        if (nnz != 0) {
          do {
/*@ spmm_shape(rows,nc,start,NN,D,A,W) && 0<n && n<=nc && 0<nnz && nnz<=NN[(nc-n)] && dmap==pointer_offset(widx_dmap,(nnz_before(NN,(nc-n))+(NN[(nc-n)]-nnz)),int) && IntArray::full(widx_dmap,Zlength(D),D) which implies spmm_shape(rows,nc,start,NN,D,A,W) && 0<n && n<=nc && 0<nnz && nnz<=NN[(nc-n)] && dmap==pointer_offset(widx_dmap,(nnz_before(NN,(nc-n))+(NN[(nc-n)]-nnz)),int) && 0<=(nnz_before(NN,(nc-n))+(NN[(nc-n)]-nnz)) && (nnz_before(NN,(nc-n))+(NN[(nc-n)]-nnz))<Zlength(D) && IntArray::missing_i(widx_dmap,(nnz_before(NN,(nc-n))+(NN[(nc-n)]-nnz)),0,Zlength(D),D) * store(dmap,int,D[(nnz_before(NN,(nc-n))+(NN[(nc-n)]-nnz))]) */
const intptr_t diff = *dmap; dmap += 1;
/*@ spmm_shape(rows,nc,start,NN,D,A,W) && 0<n && n<=nc && 0<nnz && nnz<=z_at(NN,(nc-n)) && 0<=(rows-1) && (rows-1)+1<=rows && input==pointer_offset(a,input_index(D,start,(rows-1),(nnz_before(NN,(nc-n))+(z_at(NN,(nc-n))-nnz))),float) && FloatArray::full(a,Zlength(A),A) which implies spmm_shape(rows,nc,start,NN,D,A,W) && 0<n && n<=nc && 0<nnz && nnz<=z_at(NN,(nc-n)) && 0<=(rows-1) && (rows-1)+1<=rows && input==pointer_offset(a,input_index(D,start,(rows-1),(nnz_before(NN,(nc-n))+(z_at(NN,(nc-n))-nnz))),float) && 0<=input_index(D,start,(rows-1),(nnz_before(NN,(nc-n))+(z_at(NN,(nc-n))-nnz))) && input_index(D,start,(rows-1),(nnz_before(NN,(nc-n))+(z_at(NN,(nc-n))-nnz)))+1<=Zlength(A) && FloatArray::full(a,Zlength(A),A) */
const float32x2_t vi0 = vld1_dup_f32(input)
/*@ where base=a,len=Zlength(A),j=input_index(D,start,(rows-1),(nnz_before(NN,(nc-n))+(z_at(NN,(nc-n))-nnz))),L=A */
;
            input = (const float*) ((uintptr_t) input + (uintptr_t) diff);
/*@ spmm_shape(rows,nc,start,NN,D,A,W) && 0<n && n<=nc && w==pointer_offset(weights,(bias_index(NN,(nc-n))+1+(z_at(NN,(nc-n))-nnz)),float) && 0<nnz && nnz<=z_at(NN,(nc-n)) && FloatArray::full(weights,Zlength(W),W) which implies spmm_shape(rows,nc,start,NN,D,A,W) && 0<n && n<=nc && w==pointer_offset(weights,(bias_index(NN,(nc-n))+1+(z_at(NN,(nc-n))-nnz)),float) && 0<nnz && nnz<=z_at(NN,(nc-n)) && 0<=(bias_index(NN,(nc-n))+1+(z_at(NN,(nc-n))-nnz)) && (bias_index(NN,(nc-n))+1+(z_at(NN,(nc-n))-nnz))+1<=Zlength(W) && FloatArray::full(weights,Zlength(W),W) */
const float32x2_t vw = vld1_dup_f32(w)
/*@ where base=weights,len=Zlength(W),j=(bias_index(NN,(nc-n))+1+(z_at(NN,(nc-n))-nnz)),L=W */
; w += 1;
            vacc0 = vfma_f32(vacc0, vi0, vw)
/*@ where acc=&vacc0,a=&vi0,b=&vw */
;
            nnz -= 1;
          }
/*@ Inv Assert 0<nc && 0<rows && sizeof(float)==4 && sizeof(int)==4 && sizeof(unsigned int)==4 && mc@pre==4*rows && nc==nc@pre && weights==weights@pre && widx_dmap==widx_dmap@pre && nidx_nnzmap==nidx_nnzmap@pre && output_stride==output_stride@pre && params==params@pre && spmm_shape(rows,nc,start,NN,D,A,W) && spmm_capacity(rows,nc,output_stride,a,weights,widx_dmap,nidx_nnzmap,output@pre,NN,D,A,W) && 0<=mc && mc<=mc@pre && mc%4==0 && 0<mc && 0<=(rows-1) && (rows-1)+1<=rows && output_decrement==word64(word64(output_stride*nc)-4) && mc<16 && 0<n && n<=nc && 0<=nnz && nnz<=z_at(NN,(nc-n)) && w==pointer_offset(weights,bias_index(NN,(nc-n))+1+(z_at(NN,(nc-n))-nnz),float) && dmap==pointer_offset(widx_dmap,(nnz_before(NN,(nc-n))+(z_at(NN,(nc-n))-nnz)),int) && nnzmap==pointer_offset(nidx_nnzmap,(nc-n)+1,unsigned int) && input==pointer_offset(a,input_index(D,start,(rows-1),(nnz_before(NN,(nc-n))+(z_at(NN,(nc-n))-nnz))),float) && output==spmm_output_cursor(output@pre,(rows-1),output_stride,(nc-n)) && FloatArray::full(a,Zlength(A),A) * FloatArray::full(weights,Zlength(W),W) * IntArray::full(widx_dmap,Zlength(D),D) * UIntArray::full(nidx_nnzmap,nc,NN) * store(&(params->scalar.min),float,lo) * store(&(params->scalar.max),float,hi) * store(&(vmin.s0),float,lo) * store(&(vmin.s1),float,lo) * store(&(vmin.s2),float,lo) * store(&(vmin.s3),float,lo) * store(&(vmax.s0),float,hi) * store(&(vmax.s1),float,hi) * store(&(vmax.s2),float,hi) * store(&(vmax.s3),float,hi) * StructPredfloat32x4x2_t(&vminmax,tuple_record(cons(vec4(lo,lo,lo,lo),cons(vec4(hi,hi,hi,hi),nil)))) * spmm_output(output@pre,rows,nc,output_stride,(rows-1),(nc-n),1,start,NN,D,A,W,lo,hi) * store(&(vacc0.s0),float,spmm_acc((z_at(NN,(nc-n))-nnz),(nc-n),(rows-1)+0,start,NN,D,A,W)) * store(&(vacc0.s1),float,spmm_acc((z_at(NN,(nc-n))-nnz),(nc-n),(rows-1)+0,start,NN,D,A,W)) */
while (nnz != 0);
        }
        float32x2_t vout0 = vmin_f32(vacc0, vget_low_f32(vmax)
/*@ where a=&vmax */
)
/*@ where a=&vacc0,b=0 */
;
        vout0 = vmax_f32(vout0, vget_low_f32(vmin)
/*@ where a=&vmin */
)
/*@ where a=&vout0,b=0 */
;
/*@ 0<nc && 0<rows && sizeof(float)==4 && sizeof(int)==4 && sizeof(unsigned int)==4 && mc@pre==4*rows && nc==nc@pre && weights==weights@pre && widx_dmap==widx_dmap@pre && nidx_nnzmap==nidx_nnzmap@pre && output_stride==output_stride@pre && params==params@pre && spmm_shape(rows,nc,start,NN,D,A,W) && spmm_capacity(rows,nc,output_stride,a,weights,widx_dmap,nidx_nnzmap,output@pre,NN,D,A,W) && 0<=mc && mc<=mc@pre && mc%4==0 && 0<mc && 0<=(rows-1) && (rows-1)+1<=rows && output_decrement==word64(word64(output_stride*nc)-4) && mc<16 && 0<n && n<=nc && output==spmm_output_cursor(output@pre,(rows-1),output_stride,(nc-n)) && spmm_output(output@pre,rows,nc,output_stride,(rows-1),(nc-n),1,start,NN,D,A,W,lo,hi) which implies 0<nc && 0<rows && sizeof(float)==4 && sizeof(int)==4 && sizeof(unsigned int)==4 && mc@pre==4*rows && nc==nc@pre && weights==weights@pre && widx_dmap==widx_dmap@pre && nidx_nnzmap==nidx_nnzmap@pre && output_stride==output_stride@pre && params==params@pre && spmm_shape(rows,nc,start,NN,D,A,W) && spmm_capacity(rows,nc,output_stride,a,weights,widx_dmap,nidx_nnzmap,output@pre,NN,D,A,W) && 0<=mc && mc<=mc@pre && mc%4==0 && 0<mc && 0<=(rows-1) && (rows-1)+1<=rows && output_decrement==word64(word64(output_stride*nc)-4) && mc<16 && 0<n && n<=nc && output==spmm_output_cursor(output@pre,(rows-1),output_stride,(nc-n)) && spmm_output_hole(output@pre,rows,nc,output_stride,(rows-1),(nc-n),1,start,NN,D,A,W,lo,hi) * FloatArray::undef_full(output,1) */
qcp_vst1_lane_f32((output),&(vout0),(0));
        output = (float*) ((uintptr_t) output + output_stride);
        n -= 1;
      }
/*@ Inv Assert 0<nc && 0<rows && sizeof(float)==4 && sizeof(int)==4 && sizeof(unsigned int)==4 && mc@pre==4*rows && nc==nc@pre && weights==weights@pre && widx_dmap==widx_dmap@pre && nidx_nnzmap==nidx_nnzmap@pre && output_stride==output_stride@pre && params==params@pre && spmm_shape(rows,nc,start,NN,D,A,W) && spmm_capacity(rows,nc,output_stride,a,weights,widx_dmap,nidx_nnzmap,output@pre,NN,D,A,W) && 0<=mc && mc<=mc@pre && mc%4==0 && 0<mc && 0<=(rows-1) && (rows-1)+1<=rows && output_decrement==word64(word64(output_stride*nc)-4) && mc<16 && 0<=n && n<=nc && w==pointer_offset(weights,bias_index(NN,(nc-n)),float) && dmap==pointer_offset(widx_dmap,nnz_before(NN,(nc-n)),int) && nnzmap==pointer_offset(nidx_nnzmap,(nc-n),unsigned int) && input==pointer_offset(a,input_index(D,start,(rows-1),nnz_before(NN,(nc-n))),float) && output==spmm_output_cursor(output@pre,(rows-1),output_stride,(nc-n)) && FloatArray::full(a,Zlength(A),A) * FloatArray::full(weights,Zlength(W),W) * IntArray::full(widx_dmap,Zlength(D),D) * UIntArray::full(nidx_nnzmap,nc,NN) * store(&(params->scalar.min),float,lo) * store(&(params->scalar.max),float,hi) * store(&(vmin.s0),float,lo) * store(&(vmin.s1),float,lo) * store(&(vmin.s2),float,lo) * store(&(vmin.s3),float,lo) * store(&(vmax.s0),float,hi) * store(&(vmax.s1),float,hi) * store(&(vmax.s2),float,hi) * store(&(vmax.s3),float,hi) * StructPredfloat32x4x2_t(&vminmax,tuple_record(cons(vec4(lo,lo,lo,lo),cons(vec4(hi,hi,hi,hi),nil)))) * spmm_output(output@pre,rows,nc,output_stride,(rows-1),(nc-n),1,start,NN,D,A,W,lo,hi) */
while (n != 0);
      output = (float*) ((uintptr_t) output - output_decrement);
      input += 1;
    }
  }
}
