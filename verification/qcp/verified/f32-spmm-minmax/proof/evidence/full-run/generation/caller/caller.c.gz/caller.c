/* Public contract under the declared source-reviewed intrinsic model.
 * This candidate is not yet a complete kernel proof. Canonical modeled values
 * imply the published numeric-or-both-NaN observation; not payload identity.
 */
/*@ Import Coq Require Import SpmmSpec.TupleMemory */
struct float32x4_t {float s0;float s1;float s2;float s3;};
typedef struct float32x4_t float32x4_t;
struct float32x4x2_t {float32x4_t val[2];};
typedef struct float32x4x2_t float32x4x2_t;
/*@ Extern Coq Record Recordfloat32x4_t { f0:fp32; f1:fp32; f2:fp32; f3:fp32; } */
/*@ Extern Coq Record Recordfloat32x4x2_t { tuple_values:list Recordfloat32x4_t; } */
/*@ Extern Coq
 (tuple_record:list Recordfloat32x4_t -> Recordfloat32x4x2_t)
 (tuple_values:Recordfloat32x4x2_t -> list Recordfloat32x4_t)
 (vec4: fp32 -> fp32 -> fp32 -> fp32 -> Recordfloat32x4_t)
 (f0: Recordfloat32x4_t -> fp32) (f1: Recordfloat32x4_t -> fp32)
 (f2: Recordfloat32x4_t -> fp32) (f3: Recordfloat32x4_t -> fp32)
 (veczero:Recordfloat32x4_t)
 (StructPredfloat32x4x2_t:Z -> Recordfloat32x4x2_t -> Assertion)
 (UndefStructPredfloat32x4_t: Z -> Assertion)
 (UndefStructPredfloat32x4x2_t: Z -> Assertion)
 (Structfloat32x4_tArray::full: Z -> Z -> list Recordfloat32x4_t -> Assertion)
 (Structfloat32x4_tArray::undef_full: Z -> Z -> Assertion)
 (cons:{A} -> A -> list A -> list A) (nil:{A} -> list A)
 (tuple_at: Z -> list Recordfloat32x4_t -> Recordfloat32x4_t)
*/
/*@ include strategies "tuple.strategies" */
/*@ Import Coq Require Import GemmSpec.FmaModel */
/*@ Extern Coq (bit_same:fp32 -> fp32 -> Prop) */
float qcp_identity(float x)
/*@ Require emp Ensure bit_same(__return,x) && emp */;
void qcp_assert(int condition)
/*@ Require condition!=0 && emp Ensure emp */;
/* Source-reviewed GNU builtin. Cache/performance effects are not data-memory
   observations; the caller still proves evaluation of its address expression. */
void __builtin_prefetch(const void *address)
/*@ Require emp Ensure emp */;
void xnn_prefetch_to_l1(const void *address)
/*@ Require emp Ensure emp */;
typedef unsigned long long size_t;
typedef unsigned long long uintptr_t;
typedef long long intptr_t;
typedef int int32_t;
typedef unsigned int uint32_t;
struct scalar_bounds {float min;float max;};
struct xnn_f32_minmax_params {struct scalar_bounds scalar;};
struct float32x2_t {float s0;float s1;};
typedef struct float32x2_t float32x2_t;
struct vfloat32m8_t {float s0;float s1;float s2;float s3;float s4;float s5;float s6;float s7;float s8;float s9;float s10;float s11;float s12;float s13;float s14;float s15;float s16;float s17;float s18;float s19;float s20;float s21;float s22;float s23;float s24;float s25;float s26;float s27;float s28;float s29;float s30;float s31;};
typedef struct vfloat32m8_t vfloat32m8_t;
struct vbool4_t {int s0;int s1;int s2;int s3;int s4;int s5;int s6;int s7;int s8;int s9;int s10;int s11;int s12;int s13;int s14;int s15;int s16;int s17;int s18;int s19;int s20;int s21;int s22;int s23;int s24;int s25;int s26;int s27;int s28;int s29;int s30;int s31;};
typedef struct vbool4_t vbool4_t;
/*@ Import Coq Require Import SpmmSpec.Model SpmmSpec.Vectors */
/*@ Extern Coq
 (FloatArray::full:Z -> Z -> list fp32 -> Assertion)
 (FloatArray::seg:Z -> Z -> Z -> list fp32 -> Assertion)
 (FloatArray::undef_full:Z -> Z -> Assertion)
 (spmm_get:Z -> list fp32 -> fp32)
 (bit_same:fp32 -> fp32 -> Prop)
 (fma_rne:fp32 -> fp32 -> fp32 -> fp32)
 (fp32_neon_min:fp32 -> fp32 -> fp32) (fp32_neon_max:fp32 -> fp32 -> fp32)
 (fp32_min_number:fp32 -> fp32 -> fp32) (fp32_max_number:fp32 -> fp32 -> fp32)
 (canonical_qnan:fp32) (spmm_nanth:fp32 -> Z) (spmm_merge:fp32 -> fp32 -> Z -> fp32)
 (spmm_vl_allowed:Z -> Z -> Prop)
 (UndefStructPredfloat32x2_t:Z -> Assertion)
 (UndefStructPredvfloat32m8_t:Z -> Assertion) (UndefStructPredvbool4_t:Z -> Assertion)
 (spmm_active32:Z -> fp32 -> fp32 -> fp32 -> fp32 -> fp32 -> fp32 -> fp32 -> fp32 -> fp32 -> fp32 -> fp32 -> fp32 -> fp32 -> fp32 -> fp32 -> fp32 -> fp32 -> fp32 -> fp32 -> fp32 -> fp32 -> fp32 -> fp32 -> fp32 -> fp32 -> fp32 -> fp32 -> fp32 -> fp32 -> fp32 -> fp32 -> fp32 -> fp32 -> fp32 -> fp32 -> fp32 -> fp32 -> fp32 -> fp32 -> fp32 -> fp32 -> fp32 -> fp32 -> fp32 -> fp32 -> fp32 -> fp32 -> fp32 -> fp32 -> fp32 -> fp32 -> fp32 -> fp32 -> fp32 -> fp32 -> fp32 -> fp32 -> fp32 -> fp32 -> fp32 -> fp32 -> fp32 -> fp32 -> fp32 -> Prop)
 (spmm_mask32:Z -> Z -> Z -> Z -> Z -> Z -> Z -> Z -> Z -> Z -> Z -> Z -> Z -> Z -> Z -> Z -> Z -> Z -> Z -> Z -> Z -> Z -> Z -> Z -> Z -> Z -> Z -> Z -> Z -> Z -> Z -> Z -> Z -> Z -> Z -> Z -> Z -> Z -> Z -> Z -> Z -> Z -> Z -> Z -> Z -> Z -> Z -> Z -> Z -> Z -> Z -> Z -> Z -> Z -> Z -> Z -> Z -> Z -> Z -> Z -> Z -> Z -> Z -> Z -> Z -> Prop)
*/
/*@ include strategies "vectors.strategies" */
/*@ Import Coq Require Import SpmmSpec.Memory */
/*@ Extern Coq
 (spmm_shape:Z -> Z -> Z -> list Z -> list Z -> list fp32 -> list fp32 -> Prop)
 (spmm_capacity:Z -> Z -> Z -> Z -> Z -> Z -> Z -> Z -> list Z -> list Z -> list fp32 -> list fp32 -> Prop)
 (spmm_output:Z -> Z -> Z -> Z -> Z -> Z -> Z -> Z -> list Z -> list Z -> list fp32 -> list fp32 -> fp32 -> fp32 -> Assertion)
 (spmm_output_hole:Z -> Z -> Z -> Z -> Z -> Z -> Z -> Z -> list Z -> list Z -> list fp32 -> list fp32 -> fp32 -> fp32 -> Assertion)
 (spmm_acc:Z -> Z -> Z -> Z -> list Z -> list Z -> list fp32 -> list fp32 -> fp32)
 (spmm_cell:Z -> Z -> Z -> list Z -> list Z -> list fp32 -> list fp32 -> fp32 -> fp32 -> fp32)
 (spmm_column_prefix:Z -> Z -> Z -> list Z -> list Z -> list fp32 -> list fp32 -> fp32 -> fp32 -> list fp32)
 (IntArray::full:Z -> Z -> list Z -> Assertion)
 (UIntArray::full:Z -> Z -> list Z -> Assertion)
 (FloatArray::missing_i:Z -> Z -> Z -> Z -> list fp32 -> Assertion)
 (prefix_sum:list Z -> Z -> Z) (nnz_before:list Z -> Z -> Z)
 (bias_index:list Z -> Z -> Z) (input_index:list Z -> Z -> Z -> Z -> Z)
 (fp_at:list fp32 -> Z -> fp32) (z_at:list Z -> Z -> Z)
 (word64:Z -> Z) (modulus64:Z)
 (spmm_output_cursor:Z -> Z -> Z -> Z -> Z)
*/
void test_neon(size_t mc, size_t nc, const float* input, const float* weights,
    const int32_t* widx_dmap, const uint32_t* nidx_nnzmap,
    float* output, size_t output_stride,
    const struct xnn_f32_minmax_params* restrict params)
/*@ With (rows:Z) (start:Z) (a:Z) (NN:list Z) (D:list Z) (A:list fp32) (W:list fp32) (lo:fp32) (hi:fp32)
 Require mc == 4*rows && input == pointer_offset(a,start,float) && spmm_shape(rows,nc,start,NN,D,A,W) && spmm_capacity(rows,nc,output_stride,a,weights,widx_dmap,nidx_nnzmap,output,NN,D,A,W) &&
 FloatArray::full(a,Zlength(A),A) * FloatArray::full(weights,Zlength(W),W) *
 IntArray::full(widx_dmap,Zlength(D),D) * UIntArray::full(nidx_nnzmap,nc,NN) *
 store(&(params->scalar.min),float,lo) * store(&(params->scalar.max),float,hi) * spmm_output(output,rows,nc,output_stride,0,0,0,start,NN,D,A,W,lo,hi)
 Ensure FloatArray::full(a,Zlength(A),A) * FloatArray::full(weights,Zlength(W),W) *
 IntArray::full(widx_dmap,Zlength(D),D) * UIntArray::full(nidx_nnzmap,nc,NN) *
 store(&(params->scalar.min),float,lo) * store(&(params->scalar.max),float,hi) * spmm_output(output,rows,nc,output_stride,rows,0,0,start,NN,D,A,W,lo,hi) */;
void test_rvv(size_t mc, size_t nc, const float* input, const float* weights,
    const int32_t* widx_dmap, const uint32_t* nidx_nnzmap,
    float* output, size_t output_stride,
    const struct xnn_f32_minmax_params* restrict params)
/*@ With (rows:Z) (start:Z) (a:Z) (NN:list Z) (D:list Z) (A:list fp32) (W:list fp32) (lo:fp32) (hi:fp32)
 Require mc == 4*rows && input == pointer_offset(a,start,float) && spmm_shape(rows,nc,start,NN,D,A,W) && spmm_capacity(rows,nc,output_stride,a,weights,widx_dmap,nidx_nnzmap,output,NN,D,A,W) &&
 FloatArray::full(a,Zlength(A),A) * FloatArray::full(weights,Zlength(W),W) *
 IntArray::full(widx_dmap,Zlength(D),D) * UIntArray::full(nidx_nnzmap,nc,NN) *
 store(&(params->scalar.min),float,lo) * store(&(params->scalar.max),float,hi) * spmm_output(output,rows,nc,output_stride,0,0,0,start,NN,D,A,W,lo,hi)
 Ensure FloatArray::full(a,Zlength(A),A) * FloatArray::full(weights,Zlength(W),W) *
 IntArray::full(widx_dmap,Zlength(D),D) * UIntArray::full(nidx_nnzmap,nc,NN) *
 store(&(params->scalar.min),float,lo) * store(&(params->scalar.max),float,hi) * spmm_output(output,rows,nc,output_stride,rows,0,0,start,NN,D,A,W,lo,hi) */;
int equivalent(size_t mc, size_t nc, const float* input, const float* weights,
    const int32_t* widx_dmap, const uint32_t* nidx_nnzmap,
    float* output_neon, float* output_rvv, size_t output_stride,
    const struct xnn_f32_minmax_params* restrict params)
/*@ With (rows:Z) (start:Z) (a:Z) (NN:list Z) (D:list Z) (A:list fp32) (W:list fp32) (lo:fp32) (hi:fp32)
 Require mc == 4*rows && input == pointer_offset(a,start,float) && spmm_shape(rows,nc,start,NN,D,A,W) && spmm_capacity(rows,nc,output_stride,a,weights,widx_dmap,nidx_nnzmap,output_neon,NN,D,A,W) && spmm_capacity(rows,nc,output_stride,a,weights,widx_dmap,nidx_nnzmap,output_rvv,NN,D,A,W) &&
 FloatArray::full(a,Zlength(A),A) * FloatArray::full(weights,Zlength(W),W) *
 IntArray::full(widx_dmap,Zlength(D),D) * UIntArray::full(nidx_nnzmap,nc,NN) *
 store(&(params->scalar.min),float,lo) * store(&(params->scalar.max),float,hi) * spmm_output(output_neon,rows,nc,output_stride,0,0,0,start,NN,D,A,W,lo,hi) * spmm_output(output_rvv,rows,nc,output_stride,0,0,0,start,NN,D,A,W,lo,hi)
 Ensure __return == 1 &&
 FloatArray::full(a,Zlength(A),A) * FloatArray::full(weights,Zlength(W),W) *
 IntArray::full(widx_dmap,Zlength(D),D) * UIntArray::full(nidx_nnzmap,nc,NN) *
 store(&(params->scalar.min),float,lo) * store(&(params->scalar.max),float,hi) * spmm_output(output_neon,rows,nc,output_stride,rows,0,0,start,NN,D,A,W,lo,hi) * spmm_output(output_rvv,rows,nc,output_stride,rows,0,0,start,NN,D,A,W,lo,hi) */
{
 test_neon(mc,nc,input,weights,widx_dmap,nidx_nnzmap,output_neon,output_stride,params);
 test_rvv(mc,nc,input,weights,widx_dmap,nidx_nnzmap,output_rvv,output_stride,params);
 return 1;
}
