#include "contracts/bindings.h"
#include "shim/neon-intrinsics.h"
/*
struct xnn_f32_minmax_params {
  struct {
    float min;
    float max;
  } scalar;
};
*/

void test_neon(
    size_t mc,
    size_t nc,
    const float* input,
    const float* weights,
    const int32_t* widx_dmap,
    const uint32_t* nidx_nnzmap,
    float* output,
    size_t output_stride,
    const struct xnn_f32_minmax_params* restrict params)

/*@ With (rows:Z) (start:Z) (a:Z) (NN:list Z) (D:list Z) (A:list fp32) (W:list fp32) (lo:fp32) (hi:fp32)
 Require mc == 4*rows && input == pointer_offset(a,start,float) && spmm_shape(rows,nc,start,NN,D,A,W) && spmm_capacity(rows,nc,output_stride,a,weights,widx_dmap,nidx_nnzmap,output,NN,D,A,W) &&
 FloatArray::full(a,Zlength(A),A) * FloatArray::full(weights,Zlength(W),W) *
 IntArray::full(widx_dmap,Zlength(D),D) * UIntArray::full(nidx_nnzmap,nc,NN) *
 store(&(params->scalar.min),float,lo) * store(&(params->scalar.max),float,hi) * spmm_output(output,rows,nc,output_stride,0,0,0,start,NN,D,A,W,lo,hi)
 Ensure FloatArray::full(a,Zlength(A),A) * FloatArray::full(weights,Zlength(W),W) *
 IntArray::full(widx_dmap,Zlength(D),D) * UIntArray::full(nidx_nnzmap,nc,NN) *
 store(&(params->scalar.min),float,lo) * store(&(params->scalar.max),float,hi) * spmm_output(output,rows,nc,output_stride,rows,0,0,start,NN,D,A,W,lo,hi) */
{
  
/*@ Assert mc==mc@pre && nc==nc@pre && input==input@pre && weights==weights@pre && widx_dmap==widx_dmap@pre && nidx_nnzmap==nidx_nnzmap@pre && output==output@pre && output_stride==output_stride@pre && params==params@pre && sizeof(float)==4 && sizeof(int)==4 && sizeof(unsigned int)==4 && 0<rows && 0<mc && mc%4==0 && 0<nc && mc==4*rows && input==pointer_offset(a,start,float) && spmm_shape(rows,nc,start,NN,D,A,W) && spmm_capacity(rows,nc,output_stride,a,weights,widx_dmap,nidx_nnzmap,output,NN,D,A,W) && FloatArray::full(a,Zlength(A),A) * FloatArray::full(weights,Zlength(W),W) * IntArray::full(widx_dmap,Zlength(D),D) * UIntArray::full(nidx_nnzmap,nc,NN) * store(&(params->scalar.min),float,lo) * store(&(params->scalar.max),float,hi) * spmm_output(output,rows,nc,output_stride,0,0,0,start,NN,D,A,W,lo,hi) */
assert(mc != 0);
  assert(mc % sizeof(float) == 0);
  assert(nc != 0);

  #if XNN_ARCH_ARM64
    const float32x4x2_t vminmax = vld2q_dup_f32(&params->scalar.min)
/*@ where owner=params */
;
    const float32x4_t vmin = vminmax.val[0];
    const float32x4_t vmax = vminmax.val[1];
  #else
    const float32x2x2_t vminmax = vld2_dup_f32(&params->scalar.min);
    const float32x4_t vmin = vcombine_f32(vminmax.val[0], vminmax.val[0]);
    const float32x4_t vmax = vcombine_f32(vminmax.val[1], vminmax.val[1]);
  #endif

  size_t output_decrement = output_stride * nc - 4 * sizeof(float);
  
/*@ Inv Assert 0<nc && 0<rows && sizeof(float)==4 && sizeof(int)==4 && sizeof(unsigned int)==4 && mc@pre==4*rows && nc==nc@pre && weights==weights@pre && widx_dmap==widx_dmap@pre && nidx_nnzmap==nidx_nnzmap@pre && output_stride==output_stride@pre && params==params@pre && spmm_shape(rows,nc,start,NN,D,A,W) && spmm_capacity(rows,nc,output_stride,a,weights,widx_dmap,nidx_nnzmap,output@pre,NN,D,A,W) && 0<=mc && mc<=mc@pre && mc%4==0 && output_decrement==word64(word64(output_stride*nc)-16) && input==pointer_offset(a,start+(rows-mc/4),float) && output==spmm_output_cursor(output@pre,(rows-mc/4),output_stride,0) && FloatArray::full(a,Zlength(A),A) * FloatArray::full(weights,Zlength(W),W) * IntArray::full(widx_dmap,Zlength(D),D) * UIntArray::full(nidx_nnzmap,nc,NN) * store(&(params->scalar.min),float,lo) * store(&(params->scalar.max),float,hi) * store(&(vmin.s0),float,lo) * store(&(vmin.s1),float,lo) * store(&(vmin.s2),float,lo) * store(&(vmin.s3),float,lo) * store(&(vmax.s0),float,hi) * store(&(vmax.s1),float,hi) * store(&(vmax.s2),float,hi) * store(&(vmax.s3),float,hi) * StructPredfloat32x4x2_t(&vminmax,tuple_record(cons(vec4(lo,lo,lo,lo),cons(vec4(hi,hi,hi,hi),nil)))) * spmm_output(output@pre,rows,nc,output_stride,(rows-mc/4),0,0,start,NN,D,A,W,lo,hi) */
while XNN_LIKELY(mc >= 4 * sizeof(float)) {
    const float* w = weights;
    const int32_t* dmap = widx_dmap;
    const uint32_t* nnzmap = nidx_nnzmap;
    size_t n = nc;
    
/*@ Assert 0<nc && 0<rows && sizeof(float)==4 && sizeof(int)==4 && sizeof(unsigned int)==4 && mc@pre==4*rows && nc==nc@pre && weights==weights@pre && widx_dmap==widx_dmap@pre && nidx_nnzmap==nidx_nnzmap@pre && output_stride==output_stride@pre && params==params@pre && spmm_shape(rows,nc,start,NN,D,A,W) && spmm_capacity(rows,nc,output_stride,a,weights,widx_dmap,nidx_nnzmap,output@pre,NN,D,A,W) && 0<=mc && mc<=mc@pre && mc%4==0 && 0<mc && 0<=(rows-mc/4) && (rows-mc/4)+4<=rows && output_decrement==word64(word64(output_stride*nc)-16) && 16<=mc && 0<n && n<=nc && w==pointer_offset(weights,bias_index(NN,(nc-n)),float) && dmap==pointer_offset(widx_dmap,nnz_before(NN,(nc-n)),int) && nnzmap==pointer_offset(nidx_nnzmap,(nc-n),unsigned int) && input==pointer_offset(a,input_index(D,start,(rows-mc/4),nnz_before(NN,(nc-n))),float) && output==spmm_output_cursor(output@pre,(rows-mc/4),output_stride,(nc-n)) && FloatArray::full(a,Zlength(A),A) * FloatArray::full(weights,Zlength(W),W) * IntArray::full(widx_dmap,Zlength(D),D) * UIntArray::full(nidx_nnzmap,nc,NN) * store(&(params->scalar.min),float,lo) * store(&(params->scalar.max),float,hi) * store(&(vmin.s0),float,lo) * store(&(vmin.s1),float,lo) * store(&(vmin.s2),float,lo) * store(&(vmin.s3),float,lo) * store(&(vmax.s0),float,hi) * store(&(vmax.s1),float,hi) * store(&(vmax.s2),float,hi) * store(&(vmax.s3),float,hi) * StructPredfloat32x4x2_t(&vminmax,tuple_record(cons(vec4(lo,lo,lo,lo),cons(vec4(hi,hi,hi,hi),nil)))) * spmm_output(output@pre,rows,nc,output_stride,(rows-mc/4),(nc-n),4,start,NN,D,A,W,lo,hi) */
do {
      
/*@ spmm_shape(rows,nc,start,NN,D,A,W) && 0<n && n<=nc && nnzmap==pointer_offset(nidx_nnzmap,(nc-n),unsigned int) && UIntArray::full(nidx_nnzmap,nc,NN) which implies spmm_shape(rows,nc,start,NN,D,A,W) && 0<n && n<=nc && nnzmap==pointer_offset(nidx_nnzmap,(nc-n),unsigned int) && 0<=(nc-n) && (nc-n)<nc && UIntArray::missing_i(nidx_nnzmap,(nc-n),0,nc,NN) * store(nnzmap,unsigned int,NN[(nc-n)]) */
uint32_t nnz = *nnzmap; nnzmap += 1;
      
/*@ spmm_shape(rows,nc,start,NN,D,A,W) && 0<n && n<=nc && w==pointer_offset(weights,bias_index(NN,(nc-n)),float) && FloatArray::full(weights,Zlength(W),W) which implies spmm_shape(rows,nc,start,NN,D,A,W) && 0<n && n<=nc && w==pointer_offset(weights,bias_index(NN,(nc-n)),float) && 0<=bias_index(NN,(nc-n)) && bias_index(NN,(nc-n))+1<=Zlength(W) && FloatArray::full(weights,Zlength(W),W) */
float32x4_t vacc0123 = vld1q_dup_f32(w)
/*@ where base=weights,len=Zlength(W),j=bias_index(NN,(nc-n)),L=W */
; w += 1;
      if XNN_LIKELY(nnz != 0) {
        do {
          
/*@ spmm_shape(rows,nc,start,NN,D,A,W) && 0<n && n<=nc && 0<nnz && nnz<=NN[(nc-n)] && dmap==pointer_offset(widx_dmap,(nnz_before(NN,(nc-n))+(NN[(nc-n)]-nnz)),int) && IntArray::full(widx_dmap,Zlength(D),D) which implies spmm_shape(rows,nc,start,NN,D,A,W) && 0<n && n<=nc && 0<nnz && nnz<=NN[(nc-n)] && dmap==pointer_offset(widx_dmap,(nnz_before(NN,(nc-n))+(NN[(nc-n)]-nnz)),int) && 0<=(nnz_before(NN,(nc-n))+(NN[(nc-n)]-nnz)) && (nnz_before(NN,(nc-n))+(NN[(nc-n)]-nnz))<Zlength(D) && IntArray::missing_i(widx_dmap,(nnz_before(NN,(nc-n))+(NN[(nc-n)]-nnz)),0,Zlength(D),D) * store(dmap,int,D[(nnz_before(NN,(nc-n))+(NN[(nc-n)]-nnz))]) */
const intptr_t diff = *dmap; dmap += 1;
          
/*@ spmm_shape(rows,nc,start,NN,D,A,W) && 0<n && n<=nc && 0<nnz && nnz<=z_at(NN,(nc-n)) && 0<=(rows-mc/4) && (rows-mc/4)+4<=rows && input==pointer_offset(a,input_index(D,start,(rows-mc/4),(nnz_before(NN,(nc-n))+(z_at(NN,(nc-n))-nnz))),float) && FloatArray::full(a,Zlength(A),A) which implies spmm_shape(rows,nc,start,NN,D,A,W) && 0<n && n<=nc && 0<nnz && nnz<=z_at(NN,(nc-n)) && 0<=(rows-mc/4) && (rows-mc/4)+4<=rows && input==pointer_offset(a,input_index(D,start,(rows-mc/4),(nnz_before(NN,(nc-n))+(z_at(NN,(nc-n))-nnz))),float) && 0<=input_index(D,start,(rows-mc/4),(nnz_before(NN,(nc-n))+(z_at(NN,(nc-n))-nnz))) && input_index(D,start,(rows-mc/4),(nnz_before(NN,(nc-n))+(z_at(NN,(nc-n))-nnz)))+4<=Zlength(A) && FloatArray::full(a,Zlength(A),A) */
const float32x4_t vi0123 = vld1q_f32(input)
/*@ where base=a,len=Zlength(A),j=input_index(D,start,(rows-mc/4),(nnz_before(NN,(nc-n))+(z_at(NN,(nc-n))-nnz))),L=A */
;
          input = (const float*) ((uintptr_t) input + (uintptr_t) diff);
          xnn_prefetch_to_l1(input + 16);
          
/*@ spmm_shape(rows,nc,start,NN,D,A,W) && 0<n && n<=nc && w==pointer_offset(weights,(bias_index(NN,(nc-n))+1+(z_at(NN,(nc-n))-nnz)),float) && 0<nnz && nnz<=z_at(NN,(nc-n)) && FloatArray::full(weights,Zlength(W),W) which implies spmm_shape(rows,nc,start,NN,D,A,W) && 0<n && n<=nc && w==pointer_offset(weights,(bias_index(NN,(nc-n))+1+(z_at(NN,(nc-n))-nnz)),float) && 0<nnz && nnz<=z_at(NN,(nc-n)) && 0<=(bias_index(NN,(nc-n))+1+(z_at(NN,(nc-n))-nnz)) && (bias_index(NN,(nc-n))+1+(z_at(NN,(nc-n))-nnz))+1<=Zlength(W) && FloatArray::full(weights,Zlength(W),W) */
const float32x4_t vw = vld1q_dup_f32(w)
/*@ where base=weights,len=Zlength(W),j=(bias_index(NN,(nc-n))+1+(z_at(NN,(nc-n))-nnz)),L=W */
; w += 1;
          xnn_prefetch_to_l1(w + 32);
          vacc0123 = vfmaq_f32(vacc0123, vi0123, vw)
/*@ where acc=&vacc0123,a=&vi0123,b=&vw */
;
          nnz -= 1;
        } 
/*@ Inv Assert 0<nc && 0<rows && sizeof(float)==4 && sizeof(int)==4 && sizeof(unsigned int)==4 && mc@pre==4*rows && nc==nc@pre && weights==weights@pre && widx_dmap==widx_dmap@pre && nidx_nnzmap==nidx_nnzmap@pre && output_stride==output_stride@pre && params==params@pre && spmm_shape(rows,nc,start,NN,D,A,W) && spmm_capacity(rows,nc,output_stride,a,weights,widx_dmap,nidx_nnzmap,output@pre,NN,D,A,W) && 0<=mc && mc<=mc@pre && mc%4==0 && 0<mc && 0<=(rows-mc/4) && (rows-mc/4)+4<=rows && output_decrement==word64(word64(output_stride*nc)-16) && 16<=mc && 0<n && n<=nc && 0<=nnz && nnz<=z_at(NN,(nc-n)) && w==pointer_offset(weights,bias_index(NN,(nc-n))+1+(z_at(NN,(nc-n))-nnz),float) && dmap==pointer_offset(widx_dmap,(nnz_before(NN,(nc-n))+(z_at(NN,(nc-n))-nnz)),int) && nnzmap==pointer_offset(nidx_nnzmap,(nc-n)+1,unsigned int) && input==pointer_offset(a,input_index(D,start,(rows-mc/4),(nnz_before(NN,(nc-n))+(z_at(NN,(nc-n))-nnz))),float) && output==spmm_output_cursor(output@pre,(rows-mc/4),output_stride,(nc-n)) && FloatArray::full(a,Zlength(A),A) * FloatArray::full(weights,Zlength(W),W) * IntArray::full(widx_dmap,Zlength(D),D) * UIntArray::full(nidx_nnzmap,nc,NN) * store(&(params->scalar.min),float,lo) * store(&(params->scalar.max),float,hi) * store(&(vmin.s0),float,lo) * store(&(vmin.s1),float,lo) * store(&(vmin.s2),float,lo) * store(&(vmin.s3),float,lo) * store(&(vmax.s0),float,hi) * store(&(vmax.s1),float,hi) * store(&(vmax.s2),float,hi) * store(&(vmax.s3),float,hi) * StructPredfloat32x4x2_t(&vminmax,tuple_record(cons(vec4(lo,lo,lo,lo),cons(vec4(hi,hi,hi,hi),nil)))) * spmm_output(output@pre,rows,nc,output_stride,(rows-mc/4),(nc-n),4,start,NN,D,A,W,lo,hi) * store(&(vacc0123.s0),float,spmm_acc((z_at(NN,(nc-n))-nnz),(nc-n),(rows-mc/4)+0,start,NN,D,A,W)) * store(&(vacc0123.s1),float,spmm_acc((z_at(NN,(nc-n))-nnz),(nc-n),(rows-mc/4)+1,start,NN,D,A,W)) * store(&(vacc0123.s2),float,spmm_acc((z_at(NN,(nc-n))-nnz),(nc-n),(rows-mc/4)+2,start,NN,D,A,W)) * store(&(vacc0123.s3),float,spmm_acc((z_at(NN,(nc-n))-nnz),(nc-n),(rows-mc/4)+3,start,NN,D,A,W)) */
while (nnz != 0);
      }
      float32x4_t vout0123 = vminq_f32(vacc0123, vmax)
/*@ where a=&vacc0123,b=&vmax */
;
      vout0123 = vmaxq_f32(vout0123, vmin)
/*@ where a=&vout0123,b=&vmin */
;
      
/*@ 0<nc && 0<rows && sizeof(float)==4 && sizeof(int)==4 && sizeof(unsigned int)==4 && mc@pre==4*rows && nc==nc@pre && weights==weights@pre && widx_dmap==widx_dmap@pre && nidx_nnzmap==nidx_nnzmap@pre && output_stride==output_stride@pre && params==params@pre && spmm_shape(rows,nc,start,NN,D,A,W) && spmm_capacity(rows,nc,output_stride,a,weights,widx_dmap,nidx_nnzmap,output@pre,NN,D,A,W) && 0<=mc && mc<=mc@pre && mc%4==0 && 0<mc && 0<=(rows-mc/4) && (rows-mc/4)+4<=rows && output_decrement==word64(word64(output_stride*nc)-16) && 16<=mc && 0<n && n<=nc && output==spmm_output_cursor(output@pre,(rows-mc/4),output_stride,(nc-n)) && spmm_output(output@pre,rows,nc,output_stride,(rows-mc/4),(nc-n),4,start,NN,D,A,W,lo,hi) which implies 0<nc && 0<rows && sizeof(float)==4 && sizeof(int)==4 && sizeof(unsigned int)==4 && mc@pre==4*rows && nc==nc@pre && weights==weights@pre && widx_dmap==widx_dmap@pre && nidx_nnzmap==nidx_nnzmap@pre && output_stride==output_stride@pre && params==params@pre && spmm_shape(rows,nc,start,NN,D,A,W) && spmm_capacity(rows,nc,output_stride,a,weights,widx_dmap,nidx_nnzmap,output@pre,NN,D,A,W) && 0<=mc && mc<=mc@pre && mc%4==0 && 0<mc && 0<=(rows-mc/4) && (rows-mc/4)+4<=rows && output_decrement==word64(word64(output_stride*nc)-16) && 16<=mc && 0<n && n<=nc && output==spmm_output_cursor(output@pre,(rows-mc/4),output_stride,(nc-n)) && spmm_output_hole(output@pre,rows,nc,output_stride,(rows-mc/4),(nc-n),4,start,NN,D,A,W,lo,hi) * FloatArray::undef_full(output,4) */
vst1q_f32(output, vout0123);
      output = (float*) ((uintptr_t) output + output_stride);
      n -= 1;
    } 
/*@ Inv Assert 0<nc && 0<rows && sizeof(float)==4 && sizeof(int)==4 && sizeof(unsigned int)==4 && mc@pre==4*rows && nc==nc@pre && weights==weights@pre && widx_dmap==widx_dmap@pre && nidx_nnzmap==nidx_nnzmap@pre && output_stride==output_stride@pre && params==params@pre && spmm_shape(rows,nc,start,NN,D,A,W) && spmm_capacity(rows,nc,output_stride,a,weights,widx_dmap,nidx_nnzmap,output@pre,NN,D,A,W) && 0<=mc && mc<=mc@pre && mc%4==0 && 0<mc && 0<=(rows-mc/4) && (rows-mc/4)+4<=rows && output_decrement==word64(word64(output_stride*nc)-16) && 16<=mc && 0<=n && n<=nc && w==pointer_offset(weights,bias_index(NN,(nc-n)),float) && dmap==pointer_offset(widx_dmap,nnz_before(NN,(nc-n)),int) && nnzmap==pointer_offset(nidx_nnzmap,(nc-n),unsigned int) && input==pointer_offset(a,input_index(D,start,(rows-mc/4),nnz_before(NN,(nc-n))),float) && output==spmm_output_cursor(output@pre,(rows-mc/4),output_stride,(nc-n)) && FloatArray::full(a,Zlength(A),A) * FloatArray::full(weights,Zlength(W),W) * IntArray::full(widx_dmap,Zlength(D),D) * UIntArray::full(nidx_nnzmap,nc,NN) * store(&(params->scalar.min),float,lo) * store(&(params->scalar.max),float,hi) * store(&(vmin.s0),float,lo) * store(&(vmin.s1),float,lo) * store(&(vmin.s2),float,lo) * store(&(vmin.s3),float,lo) * store(&(vmax.s0),float,hi) * store(&(vmax.s1),float,hi) * store(&(vmax.s2),float,hi) * store(&(vmax.s3),float,hi) * StructPredfloat32x4x2_t(&vminmax,tuple_record(cons(vec4(lo,lo,lo,lo),cons(vec4(hi,hi,hi,hi),nil)))) * spmm_output(output@pre,rows,nc,output_stride,(rows-mc/4),(nc-n),4,start,NN,D,A,W,lo,hi) */
while (n != 0);
    output = (float*) ((uintptr_t) output - output_decrement);
    input += 4;
    mc -= 4 * sizeof(float);
  }
  if XNN_UNLIKELY(mc != 0) {
    output_decrement += 2 * sizeof(float);
    if (mc & (2 * sizeof(float))) {
      const float* w = weights;
      const int32_t* dmap = widx_dmap;
      const uint32_t* nnzmap = nidx_nnzmap;
      size_t n = nc;
      
/*@ Assert 0<nc && 0<rows && sizeof(float)==4 && sizeof(int)==4 && sizeof(unsigned int)==4 && mc@pre==4*rows && nc==nc@pre && weights==weights@pre && widx_dmap==widx_dmap@pre && nidx_nnzmap==nidx_nnzmap@pre && output_stride==output_stride@pre && params==params@pre && spmm_shape(rows,nc,start,NN,D,A,W) && spmm_capacity(rows,nc,output_stride,a,weights,widx_dmap,nidx_nnzmap,output@pre,NN,D,A,W) && 0<=mc && mc<=mc@pre && mc%4==0 && 0<mc && 0<=(rows-mc/4) && (rows-mc/4)+2<=rows && output_decrement==word64(word64(output_stride*nc)-8) && mc<16 && 0<n && n<=nc && w==pointer_offset(weights,bias_index(NN,(nc-n)),float) && dmap==pointer_offset(widx_dmap,nnz_before(NN,(nc-n)),int) && nnzmap==pointer_offset(nidx_nnzmap,(nc-n),unsigned int) && input==pointer_offset(a,input_index(D,start,(rows-mc/4),nnz_before(NN,(nc-n))),float) && output==spmm_output_cursor(output@pre,(rows-mc/4),output_stride,(nc-n)) && FloatArray::full(a,Zlength(A),A) * FloatArray::full(weights,Zlength(W),W) * IntArray::full(widx_dmap,Zlength(D),D) * UIntArray::full(nidx_nnzmap,nc,NN) * store(&(params->scalar.min),float,lo) * store(&(params->scalar.max),float,hi) * store(&(vmin.s0),float,lo) * store(&(vmin.s1),float,lo) * store(&(vmin.s2),float,lo) * store(&(vmin.s3),float,lo) * store(&(vmax.s0),float,hi) * store(&(vmax.s1),float,hi) * store(&(vmax.s2),float,hi) * store(&(vmax.s3),float,hi) * StructPredfloat32x4x2_t(&vminmax,tuple_record(cons(vec4(lo,lo,lo,lo),cons(vec4(hi,hi,hi,hi),nil)))) * spmm_output(output@pre,rows,nc,output_stride,(rows-mc/4),(nc-n),2,start,NN,D,A,W,lo,hi) */
do {
        
/*@ spmm_shape(rows,nc,start,NN,D,A,W) && 0<n && n<=nc && nnzmap==pointer_offset(nidx_nnzmap,(nc-n),unsigned int) && UIntArray::full(nidx_nnzmap,nc,NN) which implies spmm_shape(rows,nc,start,NN,D,A,W) && 0<n && n<=nc && nnzmap==pointer_offset(nidx_nnzmap,(nc-n),unsigned int) && 0<=(nc-n) && (nc-n)<nc && UIntArray::missing_i(nidx_nnzmap,(nc-n),0,nc,NN) * store(nnzmap,unsigned int,NN[(nc-n)]) */
uint32_t nnz = *nnzmap; nnzmap += 1;
        
/*@ spmm_shape(rows,nc,start,NN,D,A,W) && 0<n && n<=nc && w==pointer_offset(weights,bias_index(NN,(nc-n)),float) && FloatArray::full(weights,Zlength(W),W) which implies spmm_shape(rows,nc,start,NN,D,A,W) && 0<n && n<=nc && w==pointer_offset(weights,bias_index(NN,(nc-n)),float) && 0<=bias_index(NN,(nc-n)) && bias_index(NN,(nc-n))+1<=Zlength(W) && FloatArray::full(weights,Zlength(W),W) */
float32x2_t vacc01 = vld1_dup_f32(w)
/*@ where base=weights,len=Zlength(W),j=bias_index(NN,(nc-n)),L=W */
; w += 1;
        if XNN_LIKELY(nnz != 0) {
          do {
            
/*@ spmm_shape(rows,nc,start,NN,D,A,W) && 0<n && n<=nc && 0<nnz && nnz<=NN[(nc-n)] && dmap==pointer_offset(widx_dmap,(nnz_before(NN,(nc-n))+(NN[(nc-n)]-nnz)),int) && IntArray::full(widx_dmap,Zlength(D),D) which implies spmm_shape(rows,nc,start,NN,D,A,W) && 0<n && n<=nc && 0<nnz && nnz<=NN[(nc-n)] && dmap==pointer_offset(widx_dmap,(nnz_before(NN,(nc-n))+(NN[(nc-n)]-nnz)),int) && 0<=(nnz_before(NN,(nc-n))+(NN[(nc-n)]-nnz)) && (nnz_before(NN,(nc-n))+(NN[(nc-n)]-nnz))<Zlength(D) && IntArray::missing_i(widx_dmap,(nnz_before(NN,(nc-n))+(NN[(nc-n)]-nnz)),0,Zlength(D),D) * store(dmap,int,D[(nnz_before(NN,(nc-n))+(NN[(nc-n)]-nnz))]) */
const intptr_t diff = *dmap; dmap += 1;
            
/*@ spmm_shape(rows,nc,start,NN,D,A,W) && 0<n && n<=nc && 0<nnz && nnz<=z_at(NN,(nc-n)) && 0<=(rows-mc/4) && (rows-mc/4)+2<=rows && input==pointer_offset(a,input_index(D,start,(rows-mc/4),(nnz_before(NN,(nc-n))+(z_at(NN,(nc-n))-nnz))),float) && FloatArray::full(a,Zlength(A),A) which implies spmm_shape(rows,nc,start,NN,D,A,W) && 0<n && n<=nc && 0<nnz && nnz<=z_at(NN,(nc-n)) && 0<=(rows-mc/4) && (rows-mc/4)+2<=rows && input==pointer_offset(a,input_index(D,start,(rows-mc/4),(nnz_before(NN,(nc-n))+(z_at(NN,(nc-n))-nnz))),float) && 0<=input_index(D,start,(rows-mc/4),(nnz_before(NN,(nc-n))+(z_at(NN,(nc-n))-nnz))) && input_index(D,start,(rows-mc/4),(nnz_before(NN,(nc-n))+(z_at(NN,(nc-n))-nnz)))+2<=Zlength(A) && FloatArray::full(a,Zlength(A),A) */
const float32x2_t vi01 = vld1_f32(input)
/*@ where base=a,len=Zlength(A),j=input_index(D,start,(rows-mc/4),(nnz_before(NN,(nc-n))+(z_at(NN,(nc-n))-nnz))),L=A */
;
            input = (const float*) ((uintptr_t) input + (uintptr_t) diff);
            
/*@ spmm_shape(rows,nc,start,NN,D,A,W) && 0<n && n<=nc && w==pointer_offset(weights,(bias_index(NN,(nc-n))+1+(z_at(NN,(nc-n))-nnz)),float) && 0<nnz && nnz<=z_at(NN,(nc-n)) && FloatArray::full(weights,Zlength(W),W) which implies spmm_shape(rows,nc,start,NN,D,A,W) && 0<n && n<=nc && w==pointer_offset(weights,(bias_index(NN,(nc-n))+1+(z_at(NN,(nc-n))-nnz)),float) && 0<nnz && nnz<=z_at(NN,(nc-n)) && 0<=(bias_index(NN,(nc-n))+1+(z_at(NN,(nc-n))-nnz)) && (bias_index(NN,(nc-n))+1+(z_at(NN,(nc-n))-nnz))+1<=Zlength(W) && FloatArray::full(weights,Zlength(W),W) */
const float32x2_t vw = vld1_dup_f32(w)
/*@ where base=weights,len=Zlength(W),j=(bias_index(NN,(nc-n))+1+(z_at(NN,(nc-n))-nnz)),L=W */
; w += 1;
            vacc01 = vfma_f32(vacc01, vi01, vw)
/*@ where acc=&vacc01,a=&vi01,b=&vw */
;
            nnz -= 1;
          } 
/*@ Inv Assert 0<nc && 0<rows && sizeof(float)==4 && sizeof(int)==4 && sizeof(unsigned int)==4 && mc@pre==4*rows && nc==nc@pre && weights==weights@pre && widx_dmap==widx_dmap@pre && nidx_nnzmap==nidx_nnzmap@pre && output_stride==output_stride@pre && params==params@pre && spmm_shape(rows,nc,start,NN,D,A,W) && spmm_capacity(rows,nc,output_stride,a,weights,widx_dmap,nidx_nnzmap,output@pre,NN,D,A,W) && 0<=mc && mc<=mc@pre && mc%4==0 && 0<mc && 0<=(rows-mc/4) && (rows-mc/4)+2<=rows && output_decrement==word64(word64(output_stride*nc)-8) && mc<16 && 0<n && n<=nc && 0<=nnz && nnz<=z_at(NN,(nc-n)) && w==pointer_offset(weights,bias_index(NN,(nc-n))+1+(z_at(NN,(nc-n))-nnz),float) && dmap==pointer_offset(widx_dmap,(nnz_before(NN,(nc-n))+(z_at(NN,(nc-n))-nnz)),int) && nnzmap==pointer_offset(nidx_nnzmap,(nc-n)+1,unsigned int) && input==pointer_offset(a,input_index(D,start,(rows-mc/4),(nnz_before(NN,(nc-n))+(z_at(NN,(nc-n))-nnz))),float) && output==spmm_output_cursor(output@pre,(rows-mc/4),output_stride,(nc-n)) && FloatArray::full(a,Zlength(A),A) * FloatArray::full(weights,Zlength(W),W) * IntArray::full(widx_dmap,Zlength(D),D) * UIntArray::full(nidx_nnzmap,nc,NN) * store(&(params->scalar.min),float,lo) * store(&(params->scalar.max),float,hi) * store(&(vmin.s0),float,lo) * store(&(vmin.s1),float,lo) * store(&(vmin.s2),float,lo) * store(&(vmin.s3),float,lo) * store(&(vmax.s0),float,hi) * store(&(vmax.s1),float,hi) * store(&(vmax.s2),float,hi) * store(&(vmax.s3),float,hi) * StructPredfloat32x4x2_t(&vminmax,tuple_record(cons(vec4(lo,lo,lo,lo),cons(vec4(hi,hi,hi,hi),nil)))) * spmm_output(output@pre,rows,nc,output_stride,(rows-mc/4),(nc-n),2,start,NN,D,A,W,lo,hi) * store(&(vacc01.s0),float,spmm_acc((z_at(NN,(nc-n))-nnz),(nc-n),(rows-mc/4)+0,start,NN,D,A,W)) * store(&(vacc01.s1),float,spmm_acc((z_at(NN,(nc-n))-nnz),(nc-n),(rows-mc/4)+1,start,NN,D,A,W)) */
while (nnz != 0);
        }
        float32x2_t vout01 = vmin_f32(vacc01, vget_low_f32(vmax)
/*@ where a=&vmax */
)
/*@ where a=&vacc01,b=0 */
;
        vout01 = vmax_f32(vout01, vget_low_f32(vmin)
/*@ where a=&vmin */
)
/*@ where a=&vout01,b=0 */
;
        
/*@ 0<nc && 0<rows && sizeof(float)==4 && sizeof(int)==4 && sizeof(unsigned int)==4 && mc@pre==4*rows && nc==nc@pre && weights==weights@pre && widx_dmap==widx_dmap@pre && nidx_nnzmap==nidx_nnzmap@pre && output_stride==output_stride@pre && params==params@pre && spmm_shape(rows,nc,start,NN,D,A,W) && spmm_capacity(rows,nc,output_stride,a,weights,widx_dmap,nidx_nnzmap,output@pre,NN,D,A,W) && 0<=mc && mc<=mc@pre && mc%4==0 && 0<mc && 0<=(rows-mc/4) && (rows-mc/4)+2<=rows && output_decrement==word64(word64(output_stride*nc)-8) && mc<16 && 0<n && n<=nc && output==spmm_output_cursor(output@pre,(rows-mc/4),output_stride,(nc-n)) && spmm_output(output@pre,rows,nc,output_stride,(rows-mc/4),(nc-n),2,start,NN,D,A,W,lo,hi) which implies 0<nc && 0<rows && sizeof(float)==4 && sizeof(int)==4 && sizeof(unsigned int)==4 && mc@pre==4*rows && nc==nc@pre && weights==weights@pre && widx_dmap==widx_dmap@pre && nidx_nnzmap==nidx_nnzmap@pre && output_stride==output_stride@pre && params==params@pre && spmm_shape(rows,nc,start,NN,D,A,W) && spmm_capacity(rows,nc,output_stride,a,weights,widx_dmap,nidx_nnzmap,output@pre,NN,D,A,W) && 0<=mc && mc<=mc@pre && mc%4==0 && 0<mc && 0<=(rows-mc/4) && (rows-mc/4)+2<=rows && output_decrement==word64(word64(output_stride*nc)-8) && mc<16 && 0<n && n<=nc && output==spmm_output_cursor(output@pre,(rows-mc/4),output_stride,(nc-n)) && spmm_output_hole(output@pre,rows,nc,output_stride,(rows-mc/4),(nc-n),2,start,NN,D,A,W,lo,hi) * FloatArray::undef_full(output,2) */
vst1_f32(output, vout01);
        output = (float*) ((uintptr_t) output + output_stride);
        n -= 1;
      } 
/*@ Inv Assert 0<nc && 0<rows && sizeof(float)==4 && sizeof(int)==4 && sizeof(unsigned int)==4 && mc@pre==4*rows && nc==nc@pre && weights==weights@pre && widx_dmap==widx_dmap@pre && nidx_nnzmap==nidx_nnzmap@pre && output_stride==output_stride@pre && params==params@pre && spmm_shape(rows,nc,start,NN,D,A,W) && spmm_capacity(rows,nc,output_stride,a,weights,widx_dmap,nidx_nnzmap,output@pre,NN,D,A,W) && 0<=mc && mc<=mc@pre && mc%4==0 && 0<mc && 0<=(rows-mc/4) && (rows-mc/4)+2<=rows && output_decrement==word64(word64(output_stride*nc)-8) && mc<16 && 0<=n && n<=nc && w==pointer_offset(weights,bias_index(NN,(nc-n)),float) && dmap==pointer_offset(widx_dmap,nnz_before(NN,(nc-n)),int) && nnzmap==pointer_offset(nidx_nnzmap,(nc-n),unsigned int) && input==pointer_offset(a,input_index(D,start,(rows-mc/4),nnz_before(NN,(nc-n))),float) && output==spmm_output_cursor(output@pre,(rows-mc/4),output_stride,(nc-n)) && FloatArray::full(a,Zlength(A),A) * FloatArray::full(weights,Zlength(W),W) * IntArray::full(widx_dmap,Zlength(D),D) * UIntArray::full(nidx_nnzmap,nc,NN) * store(&(params->scalar.min),float,lo) * store(&(params->scalar.max),float,hi) * store(&(vmin.s0),float,lo) * store(&(vmin.s1),float,lo) * store(&(vmin.s2),float,lo) * store(&(vmin.s3),float,lo) * store(&(vmax.s0),float,hi) * store(&(vmax.s1),float,hi) * store(&(vmax.s2),float,hi) * store(&(vmax.s3),float,hi) * StructPredfloat32x4x2_t(&vminmax,tuple_record(cons(vec4(lo,lo,lo,lo),cons(vec4(hi,hi,hi,hi),nil)))) * spmm_output(output@pre,rows,nc,output_stride,(rows-mc/4),(nc-n),2,start,NN,D,A,W,lo,hi) */
while (n != 0);
      output = (float*) ((uintptr_t) output - output_decrement);
      input += 2;
    }
    output_decrement += 1 * sizeof(float);
    if (mc & (1 * sizeof(float))) {
      const float* w = weights;
      const int32_t* dmap = widx_dmap;
      const uint32_t* nnzmap = nidx_nnzmap;
      size_t n = nc;
      
/*@ Assert 0<nc && 0<rows && sizeof(float)==4 && sizeof(int)==4 && sizeof(unsigned int)==4 && mc@pre==4*rows && nc==nc@pre && weights==weights@pre && widx_dmap==widx_dmap@pre && nidx_nnzmap==nidx_nnzmap@pre && output_stride==output_stride@pre && params==params@pre && spmm_shape(rows,nc,start,NN,D,A,W) && spmm_capacity(rows,nc,output_stride,a,weights,widx_dmap,nidx_nnzmap,output@pre,NN,D,A,W) && 0<=mc && mc<=mc@pre && mc%4==0 && 0<mc && 0<=(rows-1) && (rows-1)+1<=rows && output_decrement==word64(word64(output_stride*nc)-4) && mc<16 && 0<n && n<=nc && w==pointer_offset(weights,bias_index(NN,(nc-n)),float) && dmap==pointer_offset(widx_dmap,nnz_before(NN,(nc-n)),int) && nnzmap==pointer_offset(nidx_nnzmap,(nc-n),unsigned int) && input==pointer_offset(a,input_index(D,start,(rows-1),nnz_before(NN,(nc-n))),float) && output==spmm_output_cursor(output@pre,(rows-1),output_stride,(nc-n)) && FloatArray::full(a,Zlength(A),A) * FloatArray::full(weights,Zlength(W),W) * IntArray::full(widx_dmap,Zlength(D),D) * UIntArray::full(nidx_nnzmap,nc,NN) * store(&(params->scalar.min),float,lo) * store(&(params->scalar.max),float,hi) * store(&(vmin.s0),float,lo) * store(&(vmin.s1),float,lo) * store(&(vmin.s2),float,lo) * store(&(vmin.s3),float,lo) * store(&(vmax.s0),float,hi) * store(&(vmax.s1),float,hi) * store(&(vmax.s2),float,hi) * store(&(vmax.s3),float,hi) * StructPredfloat32x4x2_t(&vminmax,tuple_record(cons(vec4(lo,lo,lo,lo),cons(vec4(hi,hi,hi,hi),nil)))) * spmm_output(output@pre,rows,nc,output_stride,(rows-1),(nc-n),1,start,NN,D,A,W,lo,hi) */
do {
        
/*@ spmm_shape(rows,nc,start,NN,D,A,W) && 0<n && n<=nc && nnzmap==pointer_offset(nidx_nnzmap,(nc-n),unsigned int) && UIntArray::full(nidx_nnzmap,nc,NN) which implies spmm_shape(rows,nc,start,NN,D,A,W) && 0<n && n<=nc && nnzmap==pointer_offset(nidx_nnzmap,(nc-n),unsigned int) && 0<=(nc-n) && (nc-n)<nc && UIntArray::missing_i(nidx_nnzmap,(nc-n),0,nc,NN) * store(nnzmap,unsigned int,NN[(nc-n)]) */
uint32_t nnz = *nnzmap; nnzmap += 1;
        
/*@ spmm_shape(rows,nc,start,NN,D,A,W) && 0<n && n<=nc && w==pointer_offset(weights,bias_index(NN,(nc-n)),float) && FloatArray::full(weights,Zlength(W),W) which implies spmm_shape(rows,nc,start,NN,D,A,W) && 0<n && n<=nc && w==pointer_offset(weights,bias_index(NN,(nc-n)),float) && 0<=bias_index(NN,(nc-n)) && bias_index(NN,(nc-n))+1<=Zlength(W) && FloatArray::full(weights,Zlength(W),W) */
float32x2_t vacc0 = vld1_dup_f32(w)
/*@ where base=weights,len=Zlength(W),j=bias_index(NN,(nc-n)),L=W */
; w += 1;
        if XNN_LIKELY(nnz != 0) {
          do {
            
/*@ spmm_shape(rows,nc,start,NN,D,A,W) && 0<n && n<=nc && 0<nnz && nnz<=NN[(nc-n)] && dmap==pointer_offset(widx_dmap,(nnz_before(NN,(nc-n))+(NN[(nc-n)]-nnz)),int) && IntArray::full(widx_dmap,Zlength(D),D) which implies spmm_shape(rows,nc,start,NN,D,A,W) && 0<n && n<=nc && 0<nnz && nnz<=NN[(nc-n)] && dmap==pointer_offset(widx_dmap,(nnz_before(NN,(nc-n))+(NN[(nc-n)]-nnz)),int) && 0<=(nnz_before(NN,(nc-n))+(NN[(nc-n)]-nnz)) && (nnz_before(NN,(nc-n))+(NN[(nc-n)]-nnz))<Zlength(D) && IntArray::missing_i(widx_dmap,(nnz_before(NN,(nc-n))+(NN[(nc-n)]-nnz)),0,Zlength(D),D) * store(dmap,int,D[(nnz_before(NN,(nc-n))+(NN[(nc-n)]-nnz))]) */
const intptr_t diff = *dmap; dmap += 1;
            
/*@ spmm_shape(rows,nc,start,NN,D,A,W) && 0<n && n<=nc && 0<nnz && nnz<=z_at(NN,(nc-n)) && 0<=(rows-1) && (rows-1)+1<=rows && input==pointer_offset(a,input_index(D,start,(rows-1),(nnz_before(NN,(nc-n))+(z_at(NN,(nc-n))-nnz))),float) && FloatArray::full(a,Zlength(A),A) which implies spmm_shape(rows,nc,start,NN,D,A,W) && 0<n && n<=nc && 0<nnz && nnz<=z_at(NN,(nc-n)) && 0<=(rows-1) && (rows-1)+1<=rows && input==pointer_offset(a,input_index(D,start,(rows-1),(nnz_before(NN,(nc-n))+(z_at(NN,(nc-n))-nnz))),float) && 0<=input_index(D,start,(rows-1),(nnz_before(NN,(nc-n))+(z_at(NN,(nc-n))-nnz))) && input_index(D,start,(rows-1),(nnz_before(NN,(nc-n))+(z_at(NN,(nc-n))-nnz)))+1<=Zlength(A) && FloatArray::full(a,Zlength(A),A) */
const float32x2_t vi0 = vld1_dup_f32(input)
/*@ where base=a,len=Zlength(A),j=input_index(D,start,(rows-1),(nnz_before(NN,(nc-n))+(z_at(NN,(nc-n))-nnz))),L=A */
;
            input = (const float*) ((uintptr_t) input + (uintptr_t) diff);
            
/*@ spmm_shape(rows,nc,start,NN,D,A,W) && 0<n && n<=nc && w==pointer_offset(weights,(bias_index(NN,(nc-n))+1+(z_at(NN,(nc-n))-nnz)),float) && 0<nnz && nnz<=z_at(NN,(nc-n)) && FloatArray::full(weights,Zlength(W),W) which implies spmm_shape(rows,nc,start,NN,D,A,W) && 0<n && n<=nc && w==pointer_offset(weights,(bias_index(NN,(nc-n))+1+(z_at(NN,(nc-n))-nnz)),float) && 0<nnz && nnz<=z_at(NN,(nc-n)) && 0<=(bias_index(NN,(nc-n))+1+(z_at(NN,(nc-n))-nnz)) && (bias_index(NN,(nc-n))+1+(z_at(NN,(nc-n))-nnz))+1<=Zlength(W) && FloatArray::full(weights,Zlength(W),W) */
const float32x2_t vw = vld1_dup_f32(w)
/*@ where base=weights,len=Zlength(W),j=(bias_index(NN,(nc-n))+1+(z_at(NN,(nc-n))-nnz)),L=W */
; w += 1;
            vacc0 = vfma_f32(vacc0, vi0, vw)
/*@ where acc=&vacc0,a=&vi0,b=&vw */
;
            nnz -= 1;
          } 
/*@ Inv Assert 0<nc && 0<rows && sizeof(float)==4 && sizeof(int)==4 && sizeof(unsigned int)==4 && mc@pre==4*rows && nc==nc@pre && weights==weights@pre && widx_dmap==widx_dmap@pre && nidx_nnzmap==nidx_nnzmap@pre && output_stride==output_stride@pre && params==params@pre && spmm_shape(rows,nc,start,NN,D,A,W) && spmm_capacity(rows,nc,output_stride,a,weights,widx_dmap,nidx_nnzmap,output@pre,NN,D,A,W) && 0<=mc && mc<=mc@pre && mc%4==0 && 0<mc && 0<=(rows-1) && (rows-1)+1<=rows && output_decrement==word64(word64(output_stride*nc)-4) && mc<16 && 0<n && n<=nc && 0<=nnz && nnz<=z_at(NN,(nc-n)) && w==pointer_offset(weights,bias_index(NN,(nc-n))+1+(z_at(NN,(nc-n))-nnz),float) && dmap==pointer_offset(widx_dmap,(nnz_before(NN,(nc-n))+(z_at(NN,(nc-n))-nnz)),int) && nnzmap==pointer_offset(nidx_nnzmap,(nc-n)+1,unsigned int) && input==pointer_offset(a,input_index(D,start,(rows-1),(nnz_before(NN,(nc-n))+(z_at(NN,(nc-n))-nnz))),float) && output==spmm_output_cursor(output@pre,(rows-1),output_stride,(nc-n)) && FloatArray::full(a,Zlength(A),A) * FloatArray::full(weights,Zlength(W),W) * IntArray::full(widx_dmap,Zlength(D),D) * UIntArray::full(nidx_nnzmap,nc,NN) * store(&(params->scalar.min),float,lo) * store(&(params->scalar.max),float,hi) * store(&(vmin.s0),float,lo) * store(&(vmin.s1),float,lo) * store(&(vmin.s2),float,lo) * store(&(vmin.s3),float,lo) * store(&(vmax.s0),float,hi) * store(&(vmax.s1),float,hi) * store(&(vmax.s2),float,hi) * store(&(vmax.s3),float,hi) * StructPredfloat32x4x2_t(&vminmax,tuple_record(cons(vec4(lo,lo,lo,lo),cons(vec4(hi,hi,hi,hi),nil)))) * spmm_output(output@pre,rows,nc,output_stride,(rows-1),(nc-n),1,start,NN,D,A,W,lo,hi) * store(&(vacc0.s0),float,spmm_acc((z_at(NN,(nc-n))-nnz),(nc-n),(rows-1)+0,start,NN,D,A,W)) * store(&(vacc0.s1),float,spmm_acc((z_at(NN,(nc-n))-nnz),(nc-n),(rows-1)+0,start,NN,D,A,W)) */
while (nnz != 0);
        }
        float32x2_t vout0 = vmin_f32(vacc0, vget_low_f32(vmax)
/*@ where a=&vmax */
)
/*@ where a=&vacc0,b=0 */
;
        vout0 = vmax_f32(vout0, vget_low_f32(vmin)
/*@ where a=&vmin */
)
/*@ where a=&vout0,b=0 */
;
        
/*@ 0<nc && 0<rows && sizeof(float)==4 && sizeof(int)==4 && sizeof(unsigned int)==4 && mc@pre==4*rows && nc==nc@pre && weights==weights@pre && widx_dmap==widx_dmap@pre && nidx_nnzmap==nidx_nnzmap@pre && output_stride==output_stride@pre && params==params@pre && spmm_shape(rows,nc,start,NN,D,A,W) && spmm_capacity(rows,nc,output_stride,a,weights,widx_dmap,nidx_nnzmap,output@pre,NN,D,A,W) && 0<=mc && mc<=mc@pre && mc%4==0 && 0<mc && 0<=(rows-1) && (rows-1)+1<=rows && output_decrement==word64(word64(output_stride*nc)-4) && mc<16 && 0<n && n<=nc && output==spmm_output_cursor(output@pre,(rows-1),output_stride,(nc-n)) && spmm_output(output@pre,rows,nc,output_stride,(rows-1),(nc-n),1,start,NN,D,A,W,lo,hi) which implies 0<nc && 0<rows && sizeof(float)==4 && sizeof(int)==4 && sizeof(unsigned int)==4 && mc@pre==4*rows && nc==nc@pre && weights==weights@pre && widx_dmap==widx_dmap@pre && nidx_nnzmap==nidx_nnzmap@pre && output_stride==output_stride@pre && params==params@pre && spmm_shape(rows,nc,start,NN,D,A,W) && spmm_capacity(rows,nc,output_stride,a,weights,widx_dmap,nidx_nnzmap,output@pre,NN,D,A,W) && 0<=mc && mc<=mc@pre && mc%4==0 && 0<mc && 0<=(rows-1) && (rows-1)+1<=rows && output_decrement==word64(word64(output_stride*nc)-4) && mc<16 && 0<n && n<=nc && output==spmm_output_cursor(output@pre,(rows-1),output_stride,(nc-n)) && spmm_output_hole(output@pre,rows,nc,output_stride,(rows-1),(nc-n),1,start,NN,D,A,W,lo,hi) * FloatArray::undef_full(output,1) */
vst1_lane_f32(output, vout0, 0);
        output = (float*) ((uintptr_t) output + output_stride);
        n -= 1;
      } 
/*@ Inv Assert 0<nc && 0<rows && sizeof(float)==4 && sizeof(int)==4 && sizeof(unsigned int)==4 && mc@pre==4*rows && nc==nc@pre && weights==weights@pre && widx_dmap==widx_dmap@pre && nidx_nnzmap==nidx_nnzmap@pre && output_stride==output_stride@pre && params==params@pre && spmm_shape(rows,nc,start,NN,D,A,W) && spmm_capacity(rows,nc,output_stride,a,weights,widx_dmap,nidx_nnzmap,output@pre,NN,D,A,W) && 0<=mc && mc<=mc@pre && mc%4==0 && 0<mc && 0<=(rows-1) && (rows-1)+1<=rows && output_decrement==word64(word64(output_stride*nc)-4) && mc<16 && 0<=n && n<=nc && w==pointer_offset(weights,bias_index(NN,(nc-n)),float) && dmap==pointer_offset(widx_dmap,nnz_before(NN,(nc-n)),int) && nnzmap==pointer_offset(nidx_nnzmap,(nc-n),unsigned int) && input==pointer_offset(a,input_index(D,start,(rows-1),nnz_before(NN,(nc-n))),float) && output==spmm_output_cursor(output@pre,(rows-1),output_stride,(nc-n)) && FloatArray::full(a,Zlength(A),A) * FloatArray::full(weights,Zlength(W),W) * IntArray::full(widx_dmap,Zlength(D),D) * UIntArray::full(nidx_nnzmap,nc,NN) * store(&(params->scalar.min),float,lo) * store(&(params->scalar.max),float,hi) * store(&(vmin.s0),float,lo) * store(&(vmin.s1),float,lo) * store(&(vmin.s2),float,lo) * store(&(vmin.s3),float,lo) * store(&(vmax.s0),float,hi) * store(&(vmax.s1),float,hi) * store(&(vmax.s2),float,hi) * store(&(vmax.s3),float,hi) * StructPredfloat32x4x2_t(&vminmax,tuple_record(cons(vec4(lo,lo,lo,lo),cons(vec4(hi,hi,hi,hi),nil)))) * spmm_output(output@pre,rows,nc,output_stride,(rows-1),(nc-n),1,start,NN,D,A,W,lo,hi) */
while (n != 0);
      output = (float*) ((uintptr_t) output - output_decrement);
      input += 1;
    }
  }
}
