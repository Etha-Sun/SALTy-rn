Lemma rejected_false : False.
Proof. exact I. Qed.
