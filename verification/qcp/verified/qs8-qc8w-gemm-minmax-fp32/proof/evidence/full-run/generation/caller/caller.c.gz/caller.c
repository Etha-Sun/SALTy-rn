/* Public QS8 GEMM spec: exact signed-byte output; all binary32 bit patterns.
 * Both kernel proofs remain pending until complete typed fresh admission. */
typedef unsigned long long size_t;
typedef unsigned long long uintptr_t;
typedef signed char int8_t;
typedef short int16_t;
typedef int int32_t;
typedef unsigned int uint32_t;
struct qs8_fp32_params { float magic_bias; int32_t magic_bias_less_output_zero_point; int8_t output_min; int8_t output_max; };
struct xnn_qs8_qc8w_conv_minmax_params { struct qs8_fp32_params fp32_neon; };
/* Only the named fp32_neon member is used. This is the C-shim representation,
   not a physical union-layout or ABI theorem. */
/* Scalar fields are the candidate C representation, not an ISA ABI proof. */
struct int8x8_t { int8_t s0,s1,s2,s3,s4,s5,s6,s7; };
struct int16x8_t { int16_t s0,s1,s2,s3,s4,s5,s6,s7; };
struct int16x4_t { int16_t s0,s1,s2,s3; };
struct int32x4_t { int32_t s0,s1,s2,s3; };
struct float32x4_t { float s0,s1,s2,s3; };
struct float32x2_t { float s0,s1; };
struct vint8mf2_t { int8_t s0,s1,s2,s3,s4,s5,s6,s7; };
struct vint16m1_t { int16_t s0,s1,s2,s3,s4,s5,s6,s7; };
struct vint32m2_t { int32_t s0,s1,s2,s3,s4,s5,s6,s7; };
struct vfloat32m2_t { float s0,s1,s2,s3,s4,s5,s6,s7; };
struct vbool16_t { int s0,s1,s2,s3,s4,s5,s6,s7; };
typedef struct int8x8_t int8x8_t;
typedef struct int16x8_t int16x8_t;
typedef struct int16x4_t int16x4_t;
typedef struct int32x4_t int32x4_t;
typedef struct float32x4_t float32x4_t;
typedef struct float32x2_t float32x2_t;
typedef struct vint8mf2_t vint8mf2_t;
typedef struct vint16m1_t vint16m1_t;
typedef struct vint32m2_t vint32m2_t;
typedef struct vfloat32m2_t vfloat32m2_t;
typedef struct vbool16_t vbool16_t;
struct uint32x2_t { int8_t s0,s1,s2,s3,s4,s5,s6,s7; };
struct uint16x4_t { int8_t s0,s1,s2,s3,s4,s5,s6,s7; };
typedef struct uint32x2_t uint32x2_t;
typedef struct uint16x4_t uint16x4_t;
/*@ Import Coq Require Import Qs8Gemm.Model Qs8Gemm.Layouts */
/*@ Extern Coq (panel_data :: *) */
/*@ Extern Coq

 (domain_shape:Z -> Z -> Z -> list panel_data -> Prop)
 (data_capacity:Z -> Z -> Z -> Z -> Z -> Prop)
 (packed_matrix:Z -> Z -> list panel_data -> Assertion)
 (a_read_extent:Z -> Z)
 (panel_bytes:Z -> Z)
 (panels:Z -> Z)
 (weights:panel_data -> list Z)
 (panel_at:list panel_data -> Z -> panel_data)
 (qs8_matrix_wf:Z -> list panel_data -> Prop)
 (qs8_bias:Z -> Z -> list panel_data -> Z)
 (qs8_scale:Z -> Z -> list panel_data -> fp32)
 (qs8_char:Z -> Z -> Z -> Z -> list Z -> list panel_data -> Z)
 (qs8_i8_address_ok:Z -> Z -> Z -> Z -> Z -> Z -> Z -> list panel_data -> Prop)
 (qs8_zget:Z -> list Z -> Z)
 (qs8_acc:Z -> Z -> Z -> list Z -> list panel_data -> Z)
 (qs8_output_prefix:Z -> Z -> Z -> Z -> list Z -> list panel_data -> fp32 -> Z -> Z -> Z -> Assertion)
 (qs8_output_ref:Z -> Z -> Z -> list Z -> list panel_data -> fp32 -> Z -> Z -> Z -> Assertion)
 (completed_values:Z -> Z -> list Z -> list panel_data -> fp32 -> Z -> Z -> Z -> list Z)
 (qs8_write_state:Z -> Z -> Z -> list Z -> Assertion)
 (qs8_append:list Z -> list Z -> list Z)
 (qs8_take:Z -> list Z -> list Z)
 (qs8_mac:Z -> Z -> Z -> Z)
 (qs8_lane4:Z -> Z -> Z -> Z -> Z -> Z)
 (qs8_ssub32:Z -> Z -> Z)
 (qs8_narrow16:Z -> Z)
 (qs8_narrow8:Z -> Z)
 (qs8_reinterpret:fp32 -> Z)
 (qs8_uninterpret:Z -> fp32)
 (qs8_or32:Z -> Z -> Z)
 (qs8_and32:Z -> Z -> Z)
 (qs8_merge:Z -> Z -> Z -> Z)
 (qs8_mask_and:Z -> Z -> Z)
 (qs8_gt:Z -> Z -> Z)
 (qs8_eq:Z -> Z -> Z)
 (qs8_nan:fp32 -> Z)
 (qs8_ext:Z -> Z -> list Z -> Z)
 (qs8_active_z:Z -> Z -> Z -> Z -> Prop)
 (qs8_active_f:Z -> Z -> fp32 -> fp32 -> Prop)
 (qs8_final:Z -> Z -> list Z -> list panel_data -> fp32 -> Z -> Z -> Z -> Z)
 (fp32_of_Z:Z -> fp32)
 (f16_arm_mul:fp32 -> fp32 -> fp32)
 (f16_arm_add:fp32 -> fp32 -> fp32)
 (f16_rvv_mul:fp32 -> fp32 -> fp32)
 (f16_rvv_add:fp32 -> fp32 -> fp32) */
/*@ Extern Coq (qs8_min:Z -> Z -> Z) (qs8_max:Z -> Z -> Z) */
/*@ Extern Coq (CharArray::full:Z -> Z -> list Z -> Assertion) (CharArray::undef_full:Z -> Z -> Assertion) (CharArray::missing_i:Z -> Z -> Z -> Z -> list Z -> Assertion) */
void test_neon(size_t mr,size_t nc,size_t kc,const int8_t *a,size_t a_stride,const void *w,int8_t *c,size_t cm_stride,size_t cn_stride,const struct xnn_qs8_qc8w_conv_minmax_params *params)
/*@ With (A:list Z) (Ps:list panel_data) (magic:fp32) (offset:Z) (lo:Z) (hi:Z)
 Require mr==1 && 0<nc && 0<kc && domain_shape(mr,nc,kc,Ps) && data_capacity(nc,kc,a,w,c) && cn_stride==8 && a!=0 && w!=0 && c!=0 && params!=0 && CharArray::full(a,a_read_extent(kc),A) * packed_matrix(kc,w,Ps) * CharArray::undef_full(c,nc) * store(&(params->fp32_neon.magic_bias),float,magic) * store(&(params->fp32_neon.magic_bias_less_output_zero_point),int,offset) * store(&(params->fp32_neon.output_min),char,lo) * store(&(params->fp32_neon.output_max),char,hi)
 Ensure CharArray::full(a@pre,a_read_extent(kc@pre),A) * packed_matrix(kc@pre,w@pre,Ps) * qs8_output_ref(c@pre,nc@pre,kc@pre,A,Ps,magic,offset,lo,hi) * store(&(params->fp32_neon.magic_bias),float,magic) * store(&(params->fp32_neon.magic_bias_less_output_zero_point),int,offset) * store(&(params->fp32_neon.output_min),char,lo) * store(&(params->fp32_neon.output_max),char,hi) */;
void test_rvv(size_t mr,size_t nc,size_t kc,const int8_t *a,size_t a_stride,const void *w,int8_t *c,size_t cm_stride,size_t cn_stride,const struct xnn_qs8_qc8w_conv_minmax_params *params)
/*@ With (A:list Z) (Ps:list panel_data) (magic:fp32) (offset:Z) (lo:Z) (hi:Z)
 Require mr==1 && 0<nc && 0<kc && domain_shape(mr,nc,kc,Ps) && data_capacity(nc,kc,a,w,c) && cn_stride==8 && a!=0 && w!=0 && c!=0 && params!=0 && CharArray::full(a,a_read_extent(kc),A) * packed_matrix(kc,w,Ps) * CharArray::undef_full(c,nc) * store(&(params->fp32_neon.magic_bias),float,magic) * store(&(params->fp32_neon.magic_bias_less_output_zero_point),int,offset) * store(&(params->fp32_neon.output_min),char,lo) * store(&(params->fp32_neon.output_max),char,hi)
 Ensure CharArray::full(a@pre,a_read_extent(kc@pre),A) * packed_matrix(kc@pre,w@pre,Ps) * qs8_output_ref(c@pre,nc@pre,kc@pre,A,Ps,magic,offset,lo,hi) * store(&(params->fp32_neon.magic_bias),float,magic) * store(&(params->fp32_neon.magic_bias_less_output_zero_point),int,offset) * store(&(params->fp32_neon.output_min),char,lo) * store(&(params->fp32_neon.output_max),char,hi) */;
int qs8_compare_outputs(size_t n,const int8_t *left,const int8_t *right)
/*@ With (L:list Z)
 Require 0<n && n<=18446744073709551615 && CharArray::full(left,n,L) * CharArray::full(right,n,L)
 Ensure __return==1 && CharArray::full(left,n,L) * CharArray::full(right,n,L) */
{
 size_t i=0;
 /*@ Inv n==n@pre && left==left@pre && right==right@pre && 0<n && n<=18446744073709551615 && 0<=i && i<=n && CharArray::full(left,n,L) * CharArray::full(right,n,L) */
 while(i<n) {
  /*@ 0<=i && i<n && CharArray::full(left,n,L) * CharArray::full(right,n,L)
    which implies 0<=i && i<n && CharArray::missing_i(left,i,0,n,L) * store(left+i,char,L[i]) * CharArray::missing_i(right,i,0,n,L) * store(right+i,char,L[i]) */
  int8_t x=left[i];
  int8_t y=right[i];
  /*@ 0<=i && i<n && CharArray::missing_i(left,i,0,n,L) * store(left+i,char,L[i]) * CharArray::missing_i(right,i,0,n,L) * store(right+i,char,L[i])
    which implies 0<=i && i<n && CharArray::full(left,n,L) * CharArray::full(right,n,L) */
  if(x!=y)return 0;
  i++;
 }
 return 1;
}
int equivalent(size_t mr,size_t nc,size_t kc,const int8_t *a,const void *w,int8_t *left,int8_t *right,const struct xnn_qs8_qc8w_conv_minmax_params *params)
/*@ With (A:list Z) (Ps:list panel_data) (magic:fp32) (offset:Z) (lo:Z) (hi:Z)
 Require mr==1 && 0<nc && 0<kc && domain_shape(mr,nc,kc,Ps) && data_capacity(nc,kc,a,w,left) && data_capacity(nc,kc,a,w,right) && a!=0 && w!=0 && left!=0 && right!=0 && params!=0 && CharArray::full(a,a_read_extent(kc),A) * packed_matrix(kc,w,Ps) * CharArray::undef_full(left,nc) * CharArray::undef_full(right,nc) * store(&(params->fp32_neon.magic_bias),float,magic) * store(&(params->fp32_neon.magic_bias_less_output_zero_point),int,offset) * store(&(params->fp32_neon.output_min),char,lo) * store(&(params->fp32_neon.output_max),char,hi)
 Ensure exists (L:list Z), __return==1 && CharArray::full(a,a_read_extent(kc),A) * packed_matrix(kc,w,Ps) * CharArray::full(left,nc,L) * CharArray::full(right,nc,L) * store(&(params->fp32_neon.magic_bias),float,magic) * store(&(params->fp32_neon.magic_bias_less_output_zero_point),int,offset) * store(&(params->fp32_neon.output_min),char,lo) * store(&(params->fp32_neon.output_max),char,hi) */
{
 test_neon(mr,nc,kc,a,0,w,left,0,8,params);
 test_rvv(mr,nc,kc,a,0,w,right,0,8,params);
 /*@ 0<kc && qs8_output_ref(left,nc,kc,A,Ps,magic,offset,lo,hi) * qs8_output_ref(right,nc,kc,A,Ps,magic,offset,lo,hi) which implies exists (L:list Z), 0<kc && CharArray::full(left,nc,L) * CharArray::full(right,nc,L) */
 return qs8_compare_outputs(nc,left,right);
}
