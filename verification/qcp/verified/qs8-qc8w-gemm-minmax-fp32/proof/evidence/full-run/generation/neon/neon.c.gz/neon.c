typedef unsigned long long size_t;
typedef unsigned long long uintptr_t;
typedef signed char int8_t;
typedef short int16_t;
typedef int int32_t;
typedef unsigned int uint32_t;
struct qs8_fp32_params { float magic_bias; int32_t magic_bias_less_output_zero_point; int8_t output_min; int8_t output_max; };
struct xnn_qs8_qc8w_conv_minmax_params { struct qs8_fp32_params fp32_neon; };
/* Only the named fp32_neon member is used. This is the C-shim representation,
   not a physical union-layout or ABI theorem. */
/* Scalar fields are the candidate C representation, not an ISA ABI proof. */
struct int8x8_t { int8_t s0,s1,s2,s3,s4,s5,s6,s7; };
struct int16x8_t { int16_t s0,s1,s2,s3,s4,s5,s6,s7; };
struct int16x4_t { int16_t s0,s1,s2,s3; };
struct int32x4_t { int32_t s0,s1,s2,s3; };
struct float32x4_t { float s0,s1,s2,s3; };
struct float32x2_t { float s0,s1; };
struct vint8mf2_t { int8_t s0,s1,s2,s3,s4,s5,s6,s7; };
struct vint16m1_t { int16_t s0,s1,s2,s3,s4,s5,s6,s7; };
struct vint32m2_t { int32_t s0,s1,s2,s3,s4,s5,s6,s7; };
struct vfloat32m2_t { float s0,s1,s2,s3,s4,s5,s6,s7; };
struct vbool16_t { int s0,s1,s2,s3,s4,s5,s6,s7; };
typedef struct int8x8_t int8x8_t;
typedef struct int16x8_t int16x8_t;
typedef struct int16x4_t int16x4_t;
typedef struct int32x4_t int32x4_t;
typedef struct float32x4_t float32x4_t;
typedef struct float32x2_t float32x2_t;
typedef struct vint8mf2_t vint8mf2_t;
typedef struct vint16m1_t vint16m1_t;
typedef struct vint32m2_t vint32m2_t;
typedef struct vfloat32m2_t vfloat32m2_t;
typedef struct vbool16_t vbool16_t;
struct uint32x2_t { int8_t s0,s1,s2,s3,s4,s5,s6,s7; };
struct uint16x4_t { int8_t s0,s1,s2,s3,s4,s5,s6,s7; };
typedef struct uint32x2_t uint32x2_t;
typedef struct uint16x4_t uint16x4_t;
/*@ Import Coq Require Import Qs8Gemm.Model Qs8Gemm.Layouts */
/*@ Extern Coq (panel_data :: *) */
/*@ Extern Coq

 (domain_shape:Z -> Z -> Z -> list panel_data -> Prop)
 (data_capacity:Z -> Z -> Z -> Z -> Z -> Prop)
 (packed_matrix:Z -> Z -> list panel_data -> Assertion)
 (a_read_extent:Z -> Z)
 (panel_bytes:Z -> Z)
 (panels:Z -> Z)
 (weights:panel_data -> list Z)
 (panel_at:list panel_data -> Z -> panel_data)
 (qs8_matrix_wf:Z -> list panel_data -> Prop)
 (qs8_bias:Z -> Z -> list panel_data -> Z)
 (qs8_scale:Z -> Z -> list panel_data -> fp32)
 (qs8_char:Z -> Z -> Z -> Z -> list Z -> list panel_data -> Z)
 (qs8_i8_address_ok:Z -> Z -> Z -> Z -> Z -> Z -> Z -> list panel_data -> Prop)
 (qs8_zget:Z -> list Z -> Z)
 (qs8_acc:Z -> Z -> Z -> list Z -> list panel_data -> Z)
 (qs8_output_prefix:Z -> Z -> Z -> Z -> list Z -> list panel_data -> fp32 -> Z -> Z -> Z -> Assertion)
 (qs8_output_ref:Z -> Z -> Z -> list Z -> list panel_data -> fp32 -> Z -> Z -> Z -> Assertion)
 (completed_values:Z -> Z -> list Z -> list panel_data -> fp32 -> Z -> Z -> Z -> list Z)
 (qs8_write_state:Z -> Z -> Z -> list Z -> Assertion)
 (qs8_append:list Z -> list Z -> list Z)
 (qs8_take:Z -> list Z -> list Z)
 (qs8_mac:Z -> Z -> Z -> Z)
 (qs8_lane4:Z -> Z -> Z -> Z -> Z -> Z)
 (qs8_ssub32:Z -> Z -> Z)
 (qs8_narrow16:Z -> Z)
 (qs8_narrow8:Z -> Z)
 (qs8_reinterpret:fp32 -> Z)
 (qs8_uninterpret:Z -> fp32)
 (qs8_or32:Z -> Z -> Z)
 (qs8_and32:Z -> Z -> Z)
 (qs8_merge:Z -> Z -> Z -> Z)
 (qs8_mask_and:Z -> Z -> Z)
 (qs8_gt:Z -> Z -> Z)
 (qs8_eq:Z -> Z -> Z)
 (qs8_nan:fp32 -> Z)
 (qs8_ext:Z -> Z -> list Z -> Z)
 (qs8_active_z:Z -> Z -> Z -> Z -> Prop)
 (qs8_active_f:Z -> Z -> fp32 -> fp32 -> Prop)
 (qs8_final:Z -> Z -> list Z -> list panel_data -> fp32 -> Z -> Z -> Z -> Z)
 (fp32_of_Z:Z -> fp32)
 (f16_arm_mul:fp32 -> fp32 -> fp32)
 (f16_arm_add:fp32 -> fp32 -> fp32)
 (f16_rvv_mul:fp32 -> fp32 -> fp32)
 (f16_rvv_add:fp32 -> fp32 -> fp32) */
/*@ Extern Coq (qs8_min:Z -> Z -> Z) (qs8_max:Z -> Z -> Z) */
/*@ Extern Coq (CharArray::full:Z -> Z -> list Z -> Assertion) (CharArray::undef_full:Z -> Z -> Assertion) (CharArray::missing_i:Z -> Z -> Z -> Z -> list Z -> Assertion) */
/*@ Extern Coq (panel_data :: *) */
/*@ Import Coq Require Import Qs8Gemm.Model Qs8Gemm.Layouts */
/*@ Extern Coq (UndefStructPredint8x8_t:Z -> Assertion) (UndefStructPredint16x8_t:Z -> Assertion) (UndefStructPredint16x4_t:Z -> Assertion) (UndefStructPredint32x4_t:Z -> Assertion) (UndefStructPredfloat32x4_t:Z -> Assertion) (UndefStructPredfloat32x2_t:Z -> Assertion) (UndefStructPredvint8mf2_t:Z -> Assertion) (UndefStructPredvint16m1_t:Z -> Assertion) (UndefStructPredvint32m2_t:Z -> Assertion) (UndefStructPredvfloat32m2_t:Z -> Assertion) (UndefStructPredvbool16_t:Z -> Assertion) (UndefStructPreduint32x2_t:Z -> Assertion) (UndefStructPreduint16x4_t:Z -> Assertion) (qs8_output_prefix:Z -> Z -> Z -> Z -> list Z -> list panel_data -> fp32 -> Z -> Z -> Z -> Assertion) (completed_values:Z -> Z -> list Z -> list panel_data -> fp32 -> Z -> Z -> Z -> list Z) (qs8_write_state:Z -> Z -> Z -> list Z -> Assertion) */
/*@ include strategies "copy.strategies" */
int16x8_t vmovl_s8(int8x8_t a)
/*@ With (x0:Z) (x1:Z) (x2:Z) (x3:Z) (x4:Z) (x5:Z) (x6:Z) (x7:Z)
 Require store(&(a.s0),char,x0) * store(&(a.s1),char,x1) * store(&(a.s2),char,x2) * store(&(a.s3),char,x3) * store(&(a.s4),char,x4) * store(&(a.s5),char,x5) * store(&(a.s6),char,x6) * store(&(a.s7),char,x7)
 Ensure store(&(__return.s0),short,x0) * store(&(__return.s1),short,x1) * store(&(__return.s2),short,x2) * store(&(__return.s3),short,x3) * store(&(__return.s4),short,x4) * store(&(__return.s5),short,x5) * store(&(__return.s6),short,x6) * store(&(__return.s7),short,x7) */;
int16x4_t vget_low_s16(int16x8_t a)
/*@ With (x0:Z) (x1:Z) (x2:Z) (x3:Z) (x4:Z) (x5:Z) (x6:Z) (x7:Z)
 Require store(&(a.s0),short,x0) * store(&(a.s1),short,x1) * store(&(a.s2),short,x2) * store(&(a.s3),short,x3) * store(&(a.s4),short,x4) * store(&(a.s5),short,x5) * store(&(a.s6),short,x6) * store(&(a.s7),short,x7)
 Ensure store(&(__return.s0),short,x0) * store(&(__return.s1),short,x1) * store(&(__return.s2),short,x2) * store(&(__return.s3),short,x3) */;
int16x4_t vget_high_s16(int16x8_t a)
/*@ With (x0:Z) (x1:Z) (x2:Z) (x3:Z) (x4:Z) (x5:Z) (x6:Z) (x7:Z)
 Require store(&(a.s0),short,x0) * store(&(a.s1),short,x1) * store(&(a.s2),short,x2) * store(&(a.s3),short,x3) * store(&(a.s4),short,x4) * store(&(a.s5),short,x5) * store(&(a.s6),short,x6) * store(&(a.s7),short,x7)
 Ensure store(&(__return.s0),short,x4) * store(&(__return.s1),short,x5) * store(&(__return.s2),short,x6) * store(&(__return.s3),short,x7) */;
int32x4_t vmlal_lane_s16(int32x4_t acc,int16x4_t b,int16x4_t a,int lane)
/*@ With (x0:Z) (x1:Z) (x2:Z) (x3:Z) (y0:Z) (y1:Z) (y2:Z) (y3:Z) (z0:Z) (z1:Z) (z2:Z) (z3:Z)
 Require 0<=lane && lane<4 && store(&(acc.s0),int,x0) * store(&(acc.s1),int,x1) * store(&(acc.s2),int,x2) * store(&(acc.s3),int,x3) * store(&(b.s0),short,y0) * store(&(b.s1),short,y1) * store(&(b.s2),short,y2) * store(&(b.s3),short,y3) * store(&(a.s0),short,z0) * store(&(a.s1),short,z1) * store(&(a.s2),short,z2) * store(&(a.s3),short,z3)
 Ensure store(&(__return.s0),int,qs8_mac(x0,y0,qs8_lane4(lane,z0,z1,z2,z3))) * store(&(__return.s1),int,qs8_mac(x1,y1,qs8_lane4(lane,z0,z1,z2,z3))) * store(&(__return.s2),int,qs8_mac(x2,y2,qs8_lane4(lane,z0,z1,z2,z3))) * store(&(__return.s3),int,qs8_mac(x3,y3,qs8_lane4(lane,z0,z1,z2,z3))) */;
float32x4_t vcvtq_f32_s32(int32x4_t a)
/*@ With (x0:Z) (x1:Z) (x2:Z) (x3:Z)
 Require store(&(a.s0),int,x0) * store(&(a.s1),int,x1) * store(&(a.s2),int,x2) * store(&(a.s3),int,x3)
 Ensure store(&(__return.s0),float,fp32_of_Z(x0)) * store(&(__return.s1),float,fp32_of_Z(x1)) * store(&(__return.s2),float,fp32_of_Z(x2)) * store(&(__return.s3),float,fp32_of_Z(x3)) */;
float32x4_t vmulq_f32(float32x4_t a,float32x4_t b)
/*@ With (x0:fp32) (x1:fp32) (x2:fp32) (x3:fp32) (y0:fp32) (y1:fp32) (y2:fp32) (y3:fp32)
 Require store(&(a.s0),float,x0) * store(&(a.s1),float,x1) * store(&(a.s2),float,x2) * store(&(a.s3),float,x3) * store(&(b.s0),float,y0) * store(&(b.s1),float,y1) * store(&(b.s2),float,y2) * store(&(b.s3),float,y3)
 Ensure store(&(__return.s0),float,f16_arm_mul(x0,y0)) * store(&(__return.s1),float,f16_arm_mul(x1,y1)) * store(&(__return.s2),float,f16_arm_mul(x2,y2)) * store(&(__return.s3),float,f16_arm_mul(x3,y3)) */;
float32x4_t vaddq_f32(float32x4_t a,float32x4_t b)
/*@ With (x0:fp32) (x1:fp32) (x2:fp32) (x3:fp32) (y0:fp32) (y1:fp32) (y2:fp32) (y3:fp32)
 Require store(&(a.s0),float,x0) * store(&(a.s1),float,x1) * store(&(a.s2),float,x2) * store(&(a.s3),float,x3) * store(&(b.s0),float,y0) * store(&(b.s1),float,y1) * store(&(b.s2),float,y2) * store(&(b.s3),float,y3)
 Ensure store(&(__return.s0),float,f16_arm_add(x0,y0)) * store(&(__return.s1),float,f16_arm_add(x1,y1)) * store(&(__return.s2),float,f16_arm_add(x2,y2)) * store(&(__return.s3),float,f16_arm_add(x3,y3)) */;
float32x4_t vdupq_n_f32(float a)
/*@ Require emp
 Ensure store(&(__return.s0),float,a) * store(&(__return.s1),float,a) * store(&(__return.s2),float,a) * store(&(__return.s3),float,a) */;
int32x4_t vdupq_n_s32(int32_t a)
/*@ Require emp
 Ensure store(&(__return.s0),int,a) * store(&(__return.s1),int,a) * store(&(__return.s2),int,a) * store(&(__return.s3),int,a) */;
int8x8_t vdup_n_s8(int8_t a)
/*@ Require emp
 Ensure store(&(__return.s0),char,a) * store(&(__return.s1),char,a) * store(&(__return.s2),char,a) * store(&(__return.s3),char,a) * store(&(__return.s4),char,a) * store(&(__return.s5),char,a) * store(&(__return.s6),char,a) * store(&(__return.s7),char,a) */;
int32x4_t vreinterpretq_s32_f32(float32x4_t a)
/*@ With (x0:fp32) (x1:fp32) (x2:fp32) (x3:fp32)
 Require store(&(a.s0),float,x0) * store(&(a.s1),float,x1) * store(&(a.s2),float,x2) * store(&(a.s3),float,x3)
 Ensure store(&(__return.s0),int,qs8_reinterpret(x0)) * store(&(__return.s1),int,qs8_reinterpret(x1)) * store(&(__return.s2),int,qs8_reinterpret(x2)) * store(&(__return.s3),int,qs8_reinterpret(x3)) */;
int32x4_t vqsubq_s32(int32x4_t a,int32x4_t b)
/*@ With (x0:Z) (x1:Z) (x2:Z) (x3:Z) (y0:Z) (y1:Z) (y2:Z) (y3:Z)
 Require store(&(a.s0),int,x0) * store(&(a.s1),int,x1) * store(&(a.s2),int,x2) * store(&(a.s3),int,x3) * store(&(b.s0),int,y0) * store(&(b.s1),int,y1) * store(&(b.s2),int,y2) * store(&(b.s3),int,y3)
 Ensure store(&(__return.s0),int,qs8_ssub32(x0,y0)) * store(&(__return.s1),int,qs8_ssub32(x1,y1)) * store(&(__return.s2),int,qs8_ssub32(x2,y2)) * store(&(__return.s3),int,qs8_ssub32(x3,y3)) */;
int16x4_t vqmovn_s32(int32x4_t a)
/*@ With (x0:Z) (x1:Z) (x2:Z) (x3:Z)
 Require store(&(a.s0),int,x0) * store(&(a.s1),int,x1) * store(&(a.s2),int,x2) * store(&(a.s3),int,x3)
 Ensure store(&(__return.s0),short,qs8_narrow16(x0)) * store(&(__return.s1),short,qs8_narrow16(x1)) * store(&(__return.s2),short,qs8_narrow16(x2)) * store(&(__return.s3),short,qs8_narrow16(x3)) */;
int16x8_t vqmovn_high_s32(int16x4_t a,int32x4_t b)
/*@ With (x0:Z) (x1:Z) (x2:Z) (x3:Z) (y0:Z) (y1:Z) (y2:Z) (y3:Z)
 Require store(&(a.s0),short,x0) * store(&(a.s1),short,x1) * store(&(a.s2),short,x2) * store(&(a.s3),short,x3) * store(&(b.s0),int,y0) * store(&(b.s1),int,y1) * store(&(b.s2),int,y2) * store(&(b.s3),int,y3)
 Ensure store(&(__return.s0),short,x0) * store(&(__return.s1),short,x1) * store(&(__return.s2),short,x2) * store(&(__return.s3),short,x3) * store(&(__return.s4),short,qs8_narrow16(y0)) * store(&(__return.s5),short,qs8_narrow16(y1)) * store(&(__return.s6),short,qs8_narrow16(y2)) * store(&(__return.s7),short,qs8_narrow16(y3)) */;
int8x8_t vqmovn_s16(int16x8_t a)
/*@ With (x0:Z) (x1:Z) (x2:Z) (x3:Z) (x4:Z) (x5:Z) (x6:Z) (x7:Z)
 Require store(&(a.s0),short,x0) * store(&(a.s1),short,x1) * store(&(a.s2),short,x2) * store(&(a.s3),short,x3) * store(&(a.s4),short,x4) * store(&(a.s5),short,x5) * store(&(a.s6),short,x6) * store(&(a.s7),short,x7)
 Ensure store(&(__return.s0),char,qs8_narrow8(x0)) * store(&(__return.s1),char,qs8_narrow8(x1)) * store(&(__return.s2),char,qs8_narrow8(x2)) * store(&(__return.s3),char,qs8_narrow8(x3)) * store(&(__return.s4),char,qs8_narrow8(x4)) * store(&(__return.s5),char,qs8_narrow8(x5)) * store(&(__return.s6),char,qs8_narrow8(x6)) * store(&(__return.s7),char,qs8_narrow8(x7)) */;
int8x8_t vmax_s8(int8x8_t a,int8x8_t b)
/*@ With (x0:Z) (x1:Z) (x2:Z) (x3:Z) (x4:Z) (x5:Z) (x6:Z) (x7:Z) (y0:Z) (y1:Z) (y2:Z) (y3:Z) (y4:Z) (y5:Z) (y6:Z) (y7:Z)
 Require store(&(a.s0),char,x0) * store(&(a.s1),char,x1) * store(&(a.s2),char,x2) * store(&(a.s3),char,x3) * store(&(a.s4),char,x4) * store(&(a.s5),char,x5) * store(&(a.s6),char,x6) * store(&(a.s7),char,x7) * store(&(b.s0),char,y0) * store(&(b.s1),char,y1) * store(&(b.s2),char,y2) * store(&(b.s3),char,y3) * store(&(b.s4),char,y4) * store(&(b.s5),char,y5) * store(&(b.s6),char,y6) * store(&(b.s7),char,y7)
 Ensure store(&(__return.s0),char,qs8_max(x0,y0)) * store(&(__return.s1),char,qs8_max(x1,y1)) * store(&(__return.s2),char,qs8_max(x2,y2)) * store(&(__return.s3),char,qs8_max(x3,y3)) * store(&(__return.s4),char,qs8_max(x4,y4)) * store(&(__return.s5),char,qs8_max(x5,y5)) * store(&(__return.s6),char,qs8_max(x6,y6)) * store(&(__return.s7),char,qs8_max(x7,y7)) */;
int8x8_t vmin_s8(int8x8_t a,int8x8_t b)
/*@ With (x0:Z) (x1:Z) (x2:Z) (x3:Z) (x4:Z) (x5:Z) (x6:Z) (x7:Z) (y0:Z) (y1:Z) (y2:Z) (y3:Z) (y4:Z) (y5:Z) (y6:Z) (y7:Z)
 Require store(&(a.s0),char,x0) * store(&(a.s1),char,x1) * store(&(a.s2),char,x2) * store(&(a.s3),char,x3) * store(&(a.s4),char,x4) * store(&(a.s5),char,x5) * store(&(a.s6),char,x6) * store(&(a.s7),char,x7) * store(&(b.s0),char,y0) * store(&(b.s1),char,y1) * store(&(b.s2),char,y2) * store(&(b.s3),char,y3) * store(&(b.s4),char,y4) * store(&(b.s5),char,y5) * store(&(b.s6),char,y6) * store(&(b.s7),char,y7)
 Ensure store(&(__return.s0),char,qs8_min(x0,y0)) * store(&(__return.s1),char,qs8_min(x1,y1)) * store(&(__return.s2),char,qs8_min(x2,y2)) * store(&(__return.s3),char,qs8_min(x3,y3)) * store(&(__return.s4),char,qs8_min(x4,y4)) * store(&(__return.s5),char,qs8_min(x5,y5)) * store(&(__return.s6),char,qs8_min(x6,y6)) * store(&(__return.s7),char,qs8_min(x7,y7)) */;
uint32x2_t vreinterpret_u32_s8(int8x8_t a)
/*@ With (x0:Z) (x1:Z) (x2:Z) (x3:Z) (x4:Z) (x5:Z) (x6:Z) (x7:Z)
 Require store(&(a.s0),char,x0) * store(&(a.s1),char,x1) * store(&(a.s2),char,x2) * store(&(a.s3),char,x3) * store(&(a.s4),char,x4) * store(&(a.s5),char,x5) * store(&(a.s6),char,x6) * store(&(a.s7),char,x7)
 Ensure store(&(__return.s0),char,x0) * store(&(__return.s1),char,x1) * store(&(__return.s2),char,x2) * store(&(__return.s3),char,x3) * store(&(__return.s4),char,x4) * store(&(__return.s5),char,x5) * store(&(__return.s6),char,x6) * store(&(__return.s7),char,x7) */;
uint16x4_t vreinterpret_u16_s8(int8x8_t a)
/*@ With (x0:Z) (x1:Z) (x2:Z) (x3:Z) (x4:Z) (x5:Z) (x6:Z) (x7:Z)
 Require store(&(a.s0),char,x0) * store(&(a.s1),char,x1) * store(&(a.s2),char,x2) * store(&(a.s3),char,x3) * store(&(a.s4),char,x4) * store(&(a.s5),char,x5) * store(&(a.s6),char,x6) * store(&(a.s7),char,x7)
 Ensure store(&(__return.s0),char,x0) * store(&(__return.s1),char,x1) * store(&(__return.s2),char,x2) * store(&(__return.s3),char,x3) * store(&(__return.s4),char,x4) * store(&(__return.s5),char,x5) * store(&(__return.s6),char,x6) * store(&(__return.s7),char,x7) */;
int8x8_t qcp_qs8_ext(const int8x8_t *a,const int8x8_t *b,int k)
/*@ With (x0:Z) (x1:Z) (x2:Z) (x3:Z) (x4:Z) (x5:Z) (x6:Z) (x7:Z)
 Require a==b && 0<=k && k<8 && store(&(a->s0),char,x0) * store(&(a->s1),char,x1) * store(&(a->s2),char,x2) * store(&(a->s3),char,x3) * store(&(a->s4),char,x4) * store(&(a->s5),char,x5) * store(&(a->s6),char,x6) * store(&(a->s7),char,x7)
 Ensure store(&(a->s0),char,x0) * store(&(a->s1),char,x1) * store(&(a->s2),char,x2) * store(&(a->s3),char,x3) * store(&(a->s4),char,x4) * store(&(a->s5),char,x5) * store(&(a->s6),char,x6) * store(&(a->s7),char,x7) * store(&(__return.s0),char,qs8_ext(k,0,cons(x0,cons(x1,cons(x2,cons(x3,cons(x4,cons(x5,cons(x6,cons(x7,nil)))))))))) * store(&(__return.s1),char,qs8_ext(k,1,cons(x0,cons(x1,cons(x2,cons(x3,cons(x4,cons(x5,cons(x6,cons(x7,nil)))))))))) * store(&(__return.s2),char,qs8_ext(k,2,cons(x0,cons(x1,cons(x2,cons(x3,cons(x4,cons(x5,cons(x6,cons(x7,nil)))))))))) * store(&(__return.s3),char,qs8_ext(k,3,cons(x0,cons(x1,cons(x2,cons(x3,cons(x4,cons(x5,cons(x6,cons(x7,nil)))))))))) * store(&(__return.s4),char,qs8_ext(k,4,cons(x0,cons(x1,cons(x2,cons(x3,cons(x4,cons(x5,cons(x6,cons(x7,nil)))))))))) * store(&(__return.s5),char,qs8_ext(k,5,cons(x0,cons(x1,cons(x2,cons(x3,cons(x4,cons(x5,cons(x6,cons(x7,nil)))))))))) * store(&(__return.s6),char,qs8_ext(k,6,cons(x0,cons(x1,cons(x2,cons(x3,cons(x4,cons(x5,cons(x6,cons(x7,nil)))))))))) * store(&(__return.s7),char,qs8_ext(k,7,cons(x0,cons(x1,cons(x2,cons(x3,cons(x4,cons(x5,cons(x6,cons(x7,nil)))))))))) */;
int32x4_t vld1q_s32(const void *p)
/*@ With (K:Z) (wb:Z) (tile:Z) (j:Z) (Ps:list panel_data)
 Require 0<K && qs8_matrix_wf(K,Ps) && 0<=tile && tile<Zlength(Ps) && 0<=j && j+4<=8 && p==wb+tile*(64+8*K)+4*j && packed_matrix(K,wb,Ps)
 Ensure packed_matrix(K,wb,Ps) * store(&(__return.s0),int,qs8_bias(tile,j+0,Ps)) * store(&(__return.s1),int,qs8_bias(tile,j+1,Ps)) * store(&(__return.s2),int,qs8_bias(tile,j+2,Ps)) * store(&(__return.s3),int,qs8_bias(tile,j+3,Ps)) */;
float32x4_t vld1q_f32(const void *p)
/*@ With (K:Z) (wb:Z) (tile:Z) (j:Z) (Ps:list panel_data)
 Require 0<K && qs8_matrix_wf(K,Ps) && 0<=tile && tile<Zlength(Ps) && 0<=j && j+4<=8 && p==wb+tile*(64+8*K)+32+8*K+4*j && packed_matrix(K,wb,Ps)
 Ensure packed_matrix(K,wb,Ps) * store(&(__return.s0),float,qs8_scale(tile,j+0,Ps)) * store(&(__return.s1),float,qs8_scale(tile,j+1,Ps)) * store(&(__return.s2),float,qs8_scale(tile,j+2,Ps)) * store(&(__return.s3),float,qs8_scale(tile,j+3,Ps)) */;
int8x8_t vld1_s8(const void *p)
/*@ With (K:Z) (ab:Z) (wb:Z) (tile:Z) (j:Z) (mode:Z) (A:list Z) (Ps:list panel_data)
 Require 0<K && qs8_matrix_wf(K,Ps) && qs8_i8_address_ok(mode,p,ab,wb,K,tile,j,Ps) && CharArray::full(ab,a_read_extent(K),A) * packed_matrix(K,wb,Ps)
 Ensure CharArray::full(ab,a_read_extent(K),A) * packed_matrix(K,wb,Ps) * store(&(__return.s0),char,qs8_char(mode,tile,j,0,A,Ps)) * store(&(__return.s1),char,qs8_char(mode,tile,j,1,A,Ps)) * store(&(__return.s2),char,qs8_char(mode,tile,j,2,A,Ps)) * store(&(__return.s3),char,qs8_char(mode,tile,j,3,A,Ps)) * store(&(__return.s4),char,qs8_char(mode,tile,j,4,A,Ps)) * store(&(__return.s5),char,qs8_char(mode,tile,j,5,A,Ps)) * store(&(__return.s6),char,qs8_char(mode,tile,j,6,A,Ps)) * store(&(__return.s7),char,qs8_char(mode,tile,j,7,A,Ps)) */;
void qcp_qs8_store8(int8_t *p,const int8x8_t *a)
/*@ With (base:Z) (N:Z) (done:Z) (L:list Z) (x0:Z) (x1:Z) (x2:Z) (x3:Z) (x4:Z) (x5:Z) (x6:Z) (x7:Z)
 Require 0<=done && done+8<=N && p==base+done && store(&(a->s0),char,x0) * store(&(a->s1),char,x1) * store(&(a->s2),char,x2) * store(&(a->s3),char,x3) * store(&(a->s4),char,x4) * store(&(a->s5),char,x5) * store(&(a->s6),char,x6) * store(&(a->s7),char,x7) * qs8_write_state(base,N,done,L)
 Ensure store(&(a->s0),char,x0) * store(&(a->s1),char,x1) * store(&(a->s2),char,x2) * store(&(a->s3),char,x3) * store(&(a->s4),char,x4) * store(&(a->s5),char,x5) * store(&(a->s6),char,x6) * store(&(a->s7),char,x7) * qs8_write_state(base,N,done+8,qs8_append(L,cons(x0,cons(x1,cons(x2,cons(x3,cons(x4,cons(x5,cons(x6,cons(x7,nil)))))))))) */;
void qcp_qs8_store_u32(int8_t *p,const uint32x2_t *a,int lane)
/*@ With (base:Z) (N:Z) (done:Z) (L:list Z) (x0:Z) (x1:Z) (x2:Z) (x3:Z) (x4:Z) (x5:Z) (x6:Z) (x7:Z)
 Require lane==0 && 0<=done && done+4<=N && p==base+done && store(&(a->s0),char,x0) * store(&(a->s1),char,x1) * store(&(a->s2),char,x2) * store(&(a->s3),char,x3) * store(&(a->s4),char,x4) * store(&(a->s5),char,x5) * store(&(a->s6),char,x6) * store(&(a->s7),char,x7) * qs8_write_state(base,N,done,L)
 Ensure store(&(a->s0),char,x0) * store(&(a->s1),char,x1) * store(&(a->s2),char,x2) * store(&(a->s3),char,x3) * store(&(a->s4),char,x4) * store(&(a->s5),char,x5) * store(&(a->s6),char,x6) * store(&(a->s7),char,x7) * qs8_write_state(base,N,done+4,qs8_append(L,cons(x0,cons(x1,cons(x2,cons(x3,nil)))))) */;
void qcp_qs8_store_u16(int8_t *p,const uint16x4_t *a,int lane)
/*@ With (base:Z) (N:Z) (done:Z) (L:list Z) (x0:Z) (x1:Z) (x2:Z) (x3:Z) (x4:Z) (x5:Z) (x6:Z) (x7:Z)
 Require lane==0 && 0<=done && done+2<=N && p==base+done && store(&(a->s0),char,x0) * store(&(a->s1),char,x1) * store(&(a->s2),char,x2) * store(&(a->s3),char,x3) * store(&(a->s4),char,x4) * store(&(a->s5),char,x5) * store(&(a->s6),char,x6) * store(&(a->s7),char,x7) * qs8_write_state(base,N,done,L)
 Ensure store(&(a->s0),char,x0) * store(&(a->s1),char,x1) * store(&(a->s2),char,x2) * store(&(a->s3),char,x3) * store(&(a->s4),char,x4) * store(&(a->s5),char,x5) * store(&(a->s6),char,x6) * store(&(a->s7),char,x7) * qs8_write_state(base,N,done+2,qs8_append(L,cons(x0,cons(x1,nil)))) */;
void qcp_qs8_store_lane(int8_t *p,const int8x8_t *a,int lane)
/*@ With (base:Z) (N:Z) (done:Z) (L:list Z) (x0:Z) (x1:Z) (x2:Z) (x3:Z) (x4:Z) (x5:Z) (x6:Z) (x7:Z)
 Require lane==0 && 0<=done && done+1<=N && p==base+done && store(&(a->s0),char,x0) * store(&(a->s1),char,x1) * store(&(a->s2),char,x2) * store(&(a->s3),char,x3) * store(&(a->s4),char,x4) * store(&(a->s5),char,x5) * store(&(a->s6),char,x6) * store(&(a->s7),char,x7) * qs8_write_state(base,N,done,L)
 Ensure store(&(a->s0),char,x0) * store(&(a->s1),char,x1) * store(&(a->s2),char,x2) * store(&(a->s3),char,x3) * store(&(a->s4),char,x4) * store(&(a->s5),char,x5) * store(&(a->s6),char,x6) * store(&(a->s7),char,x7) * qs8_write_state(base,N,done+1,qs8_append(L,cons(x0,nil))) */;
void qcp_assert(int c)
/*@ Require c!=0 && emp Ensure emp */;
/*
union xnn_qs8_qc8w_conv_minmax_params {
  struct {
    int16_t output_zero_point;
    int16_t output_min;
    int16_t output_max;
  } fp32_scalar;
#if XNN_ARCH_ARM
  struct {
    float magic_bias;
    int32_t magic_bias_less_zero_point;
    uint32_t output_min;
    uint32_t output_max;
  } fp32_armsimd32;
#endif  // XNN_ARCH_ARM
#if XNN_ARCH_ARM || XNN_ARCH_ARM64
  struct {
    float magic_bias;
    int32_t magic_bias_less_output_zero_point;
    int8_t output_min;
    int8_t output_max;
  } fp32_neon;
  struct {
    int16_t output_zero_point;
    uint8_t output_min;
    uint8_t output_max;
  } fp32_neonv8;
#endif  // XNN_ARCH_ARM || XNN_ARCH_ARM64
};
*/
void test_neon(
    size_t mr,
    size_t nc,
    size_t kc,
    const int8_t* restrict a,
    size_t a_stride,
    const void* restrict w,
    int8_t* restrict c,
    size_t cm_stride,
    size_t cn_stride,
    const struct xnn_qs8_qc8w_conv_minmax_params* restrict params)
/*@ With (A:list Z) (Ps:list panel_data) (magic:fp32) (offset:Z) (lo:Z) (hi:Z)
 Require mr==1 && 0<nc && 0<kc && domain_shape(mr,nc,kc,Ps) && data_capacity(nc,kc,a,w,c) && cn_stride==8 && a!=0 && w!=0 && c!=0 && params!=0 && CharArray::full(a,a_read_extent(kc),A) * packed_matrix(kc,w,Ps) * CharArray::undef_full(c,nc) * store(&(params->fp32_neon.magic_bias),float,magic) * store(&(params->fp32_neon.magic_bias_less_output_zero_point),int,offset) * store(&(params->fp32_neon.output_min),char,lo) * store(&(params->fp32_neon.output_max),char,hi)
 Ensure CharArray::full(a@pre,a_read_extent(kc@pre),A) * packed_matrix(kc@pre,w@pre,Ps) * qs8_output_ref(c@pre,nc@pre,kc@pre,A,Ps,magic,offset,lo,hi) * store(&(params->fp32_neon.magic_bias),float,magic) * store(&(params->fp32_neon.magic_bias_less_output_zero_point),int,offset) * store(&(params->fp32_neon.output_min),char,lo) * store(&(params->fp32_neon.output_max),char,hi) */
{
  qcp_assert(mr != 0);
  qcp_assert(mr <= 1);
  qcp_assert(nc != 0);
  qcp_assert(kc != 0);
/*@ emp which implies sizeof(int8_t)==1 && kc@pre%sizeof(int8_t)==0 && emp */
qcp_assert(kc % sizeof(int8_t) == 0);
  qcp_assert(a != ((void*)0));
  qcp_assert(w != ((void*)0));
  qcp_assert(c != ((void*)0));
  const int8_t* a0 = a;
  int8_t* c0 = c;
  do {
    int32x4_t vacc0x0123 = vld1q_s32(w)
/*@ where K=kc@pre, wb=w@pre, Ps=Ps, tile=((nc@pre-nc)/8), j=0 */
; w = (const int32_t*) w + 4;
    int32x4_t vacc0x4567 = vld1q_s32(w)
/*@ where K=kc@pre, wb=w@pre, Ps=Ps, tile=((nc@pre-nc)/8), j=4 */
; w = (const int32_t*) w + 4;
    size_t k = kc;
/*@ Inv Assert mr==mr@pre && kc==kc@pre && a==a@pre && c==c@pre && params==params@pre && a_stride==a_stride@pre && cm_stride==cm_stride@pre && cn_stride==8 && mr==1 && 0<kc@pre && 0<nc@pre && domain_shape(1,nc@pre,kc@pre,Ps) && data_capacity(nc@pre,kc@pre,a@pre,w@pre,c@pre) && qs8_matrix_wf(kc@pre,Ps) && sizeof(int8_t)==1 && sizeof(float)==4 && 0<=nc && nc<=nc@pre && 0<nc && (nc@pre-nc)%8==0 && 0<=((nc@pre-nc)/8) && ((nc@pre-nc)/8)<Zlength(Ps) && c0==pointer_offset(c@pre,(nc@pre-nc),char) && 0<=k && k<=kc@pre && (kc@pre-k)%8==0 && a0==pointer_offset(a@pre,(kc@pre-k),char) && w==pointer_offset(w@pre,((nc@pre-nc)/8)*(64+8*kc@pre)+32+8*(kc@pre-k),char) && CharArray::full(a@pre,a_read_extent(kc@pre),A) * packed_matrix(kc@pre,w@pre,Ps) * qs8_output_prefix(c@pre,nc@pre,(nc@pre-nc),kc@pre,A,Ps,magic,offset,lo,hi) * store(&(params->fp32_neon.magic_bias),float,magic) * store(&(params->fp32_neon.magic_bias_less_output_zero_point),int,offset) * store(&(params->fp32_neon.output_min),char,lo) * store(&(params->fp32_neon.output_max),char,hi) * store(&(vacc0x0123.s0),int,qs8_acc((kc@pre-k),((nc@pre-nc)/8),0,A,Ps)) * store(&(vacc0x0123.s1),int,qs8_acc((kc@pre-k),((nc@pre-nc)/8),1,A,Ps)) * store(&(vacc0x0123.s2),int,qs8_acc((kc@pre-k),((nc@pre-nc)/8),2,A,Ps)) * store(&(vacc0x0123.s3),int,qs8_acc((kc@pre-k),((nc@pre-nc)/8),3,A,Ps)) * store(&(vacc0x4567.s0),int,qs8_acc((kc@pre-k),((nc@pre-nc)/8),4,A,Ps)) * store(&(vacc0x4567.s1),int,qs8_acc((kc@pre-k),((nc@pre-nc)/8),5,A,Ps)) * store(&(vacc0x4567.s2),int,qs8_acc((kc@pre-k),((nc@pre-nc)/8),6,A,Ps)) * store(&(vacc0x4567.s3),int,qs8_acc((kc@pre-k),((nc@pre-nc)/8),7,A,Ps)) */
while (k >= 8 * sizeof(int8_t)) {
      const int8x8_t va0 = vld1_s8(a0)
/*@ where K=kc@pre, ab=a@pre, wb=w@pre, Ps=Ps, tile=((nc@pre-nc)/8), mode=0, j=(kc@pre-k), A=A */
; a0 += 8;
      const int16x8_t vxa0 = vmovl_s8(va0)
/*@ where a=&va0 */
;
      const int8x8_t vb01234567c0 = vld1_s8(w)
/*@ where K=kc@pre, ab=a@pre, wb=w@pre, Ps=Ps, tile=((nc@pre-nc)/8), mode=1, j=8*(kc@pre-k)+0, A=A */
; w = (const int8_t*) w + 8;
      const int8x8_t vb01234567c1 = vld1_s8(w)
/*@ where K=kc@pre, ab=a@pre, wb=w@pre, Ps=Ps, tile=((nc@pre-nc)/8), mode=1, j=8*(kc@pre-k)+8, A=A */
; w = (const int8_t*) w + 8;
      const int8x8_t vb01234567c2 = vld1_s8(w)
/*@ where K=kc@pre, ab=a@pre, wb=w@pre, Ps=Ps, tile=((nc@pre-nc)/8), mode=1, j=8*(kc@pre-k)+16, A=A */
; w = (const int8_t*) w + 8;
      const int8x8_t vb01234567c3 = vld1_s8(w)
/*@ where K=kc@pre, ab=a@pre, wb=w@pre, Ps=Ps, tile=((nc@pre-nc)/8), mode=1, j=8*(kc@pre-k)+24, A=A */
; w = (const int8_t*) w + 8;
      const int8x8_t vb01234567c4 = vld1_s8(w)
/*@ where K=kc@pre, ab=a@pre, wb=w@pre, Ps=Ps, tile=((nc@pre-nc)/8), mode=1, j=8*(kc@pre-k)+32, A=A */
; w = (const int8_t*) w + 8;
      const int8x8_t vb01234567c5 = vld1_s8(w)
/*@ where K=kc@pre, ab=a@pre, wb=w@pre, Ps=Ps, tile=((nc@pre-nc)/8), mode=1, j=8*(kc@pre-k)+40, A=A */
; w = (const int8_t*) w + 8;
      const int8x8_t vb01234567c6 = vld1_s8(w)
/*@ where K=kc@pre, ab=a@pre, wb=w@pre, Ps=Ps, tile=((nc@pre-nc)/8), mode=1, j=8*(kc@pre-k)+48, A=A */
; w = (const int8_t*) w + 8;
      const int8x8_t vb01234567c7 = vld1_s8(w)
/*@ where K=kc@pre, ab=a@pre, wb=w@pre, Ps=Ps, tile=((nc@pre-nc)/8), mode=1, j=8*(kc@pre-k)+56, A=A */
; w = (const int8_t*) w + 8;
      const int16x8_t vxb01234567c0 = vmovl_s8(vb01234567c0)
/*@ where a=&vb01234567c0 */
;
      const int16x8_t vxb01234567c1 = vmovl_s8(vb01234567c1)
/*@ where a=&vb01234567c1 */
;
      const int16x8_t vxb01234567c2 = vmovl_s8(vb01234567c2)
/*@ where a=&vb01234567c2 */
;
      const int16x8_t vxb01234567c3 = vmovl_s8(vb01234567c3)
/*@ where a=&vb01234567c3 */
;
      const int16x8_t vxb01234567c4 = vmovl_s8(vb01234567c4)
/*@ where a=&vb01234567c4 */
;
      const int16x8_t vxb01234567c5 = vmovl_s8(vb01234567c5)
/*@ where a=&vb01234567c5 */
;
      const int16x8_t vxb01234567c6 = vmovl_s8(vb01234567c6)
/*@ where a=&vb01234567c6 */
;
      const int16x8_t vxb01234567c7 = vmovl_s8(vb01234567c7)
/*@ where a=&vb01234567c7 */
;
      vacc0x0123 = vmlal_lane_s16(vacc0x0123, vget_low_s16(vxb01234567c0)
/*@ where a=&vxb01234567c0 */
, vget_low_s16(vxa0)
/*@ where a=&vxa0 */
, 0)
/*@ where acc=&vacc0x0123, a=0, b=0 */
;
      vacc0x4567 = vmlal_lane_s16(vacc0x4567, vget_high_s16(vxb01234567c0)
/*@ where a=&vxb01234567c0 */
, vget_low_s16(vxa0)
/*@ where a=&vxa0 */
, 0)
/*@ where acc=&vacc0x4567, a=0, b=0 */
;
      vacc0x0123 = vmlal_lane_s16(vacc0x0123, vget_low_s16(vxb01234567c1)
/*@ where a=&vxb01234567c1 */
, vget_low_s16(vxa0)
/*@ where a=&vxa0 */
, 1)
/*@ where acc=&vacc0x0123, a=0, b=0 */
;
      vacc0x4567 = vmlal_lane_s16(vacc0x4567, vget_high_s16(vxb01234567c1)
/*@ where a=&vxb01234567c1 */
, vget_low_s16(vxa0)
/*@ where a=&vxa0 */
, 1)
/*@ where acc=&vacc0x4567, a=0, b=0 */
;
      vacc0x0123 = vmlal_lane_s16(vacc0x0123, vget_low_s16(vxb01234567c2)
/*@ where a=&vxb01234567c2 */
, vget_low_s16(vxa0)
/*@ where a=&vxa0 */
, 2)
/*@ where acc=&vacc0x0123, a=0, b=0 */
;
      vacc0x4567 = vmlal_lane_s16(vacc0x4567, vget_high_s16(vxb01234567c2)
/*@ where a=&vxb01234567c2 */
, vget_low_s16(vxa0)
/*@ where a=&vxa0 */
, 2)
/*@ where acc=&vacc0x4567, a=0, b=0 */
;
      vacc0x0123 = vmlal_lane_s16(vacc0x0123, vget_low_s16(vxb01234567c3)
/*@ where a=&vxb01234567c3 */
, vget_low_s16(vxa0)
/*@ where a=&vxa0 */
, 3)
/*@ where acc=&vacc0x0123, a=0, b=0 */
;
      vacc0x4567 = vmlal_lane_s16(vacc0x4567, vget_high_s16(vxb01234567c3)
/*@ where a=&vxb01234567c3 */
, vget_low_s16(vxa0)
/*@ where a=&vxa0 */
, 3)
/*@ where acc=&vacc0x4567, a=0, b=0 */
;
      vacc0x0123 = vmlal_lane_s16(vacc0x0123, vget_low_s16(vxb01234567c4)
/*@ where a=&vxb01234567c4 */
, vget_high_s16(vxa0)
/*@ where a=&vxa0 */
, 0)
/*@ where acc=&vacc0x0123, a=0, b=0 */
;
      vacc0x4567 = vmlal_lane_s16(vacc0x4567, vget_high_s16(vxb01234567c4)
/*@ where a=&vxb01234567c4 */
, vget_high_s16(vxa0)
/*@ where a=&vxa0 */
, 0)
/*@ where acc=&vacc0x4567, a=0, b=0 */
;
      vacc0x0123 = vmlal_lane_s16(vacc0x0123, vget_low_s16(vxb01234567c5)
/*@ where a=&vxb01234567c5 */
, vget_high_s16(vxa0)
/*@ where a=&vxa0 */
, 1)
/*@ where acc=&vacc0x0123, a=0, b=0 */
;
      vacc0x4567 = vmlal_lane_s16(vacc0x4567, vget_high_s16(vxb01234567c5)
/*@ where a=&vxb01234567c5 */
, vget_high_s16(vxa0)
/*@ where a=&vxa0 */
, 1)
/*@ where acc=&vacc0x4567, a=0, b=0 */
;
      vacc0x0123 = vmlal_lane_s16(vacc0x0123, vget_low_s16(vxb01234567c6)
/*@ where a=&vxb01234567c6 */
, vget_high_s16(vxa0)
/*@ where a=&vxa0 */
, 2)
/*@ where acc=&vacc0x0123, a=0, b=0 */
;
      vacc0x4567 = vmlal_lane_s16(vacc0x4567, vget_high_s16(vxb01234567c6)
/*@ where a=&vxb01234567c6 */
, vget_high_s16(vxa0)
/*@ where a=&vxa0 */
, 2)
/*@ where acc=&vacc0x4567, a=0, b=0 */
;
      vacc0x0123 = vmlal_lane_s16(vacc0x0123, vget_low_s16(vxb01234567c7)
/*@ where a=&vxb01234567c7 */
, vget_high_s16(vxa0)
/*@ where a=&vxa0 */
, 3)
/*@ where acc=&vacc0x0123, a=0, b=0 */
;
      vacc0x4567 = vmlal_lane_s16(vacc0x4567, vget_high_s16(vxb01234567c7)
/*@ where a=&vxb01234567c7 */
, vget_high_s16(vxa0)
/*@ where a=&vxa0 */
, 3)
/*@ where acc=&vacc0x4567, a=0, b=0 */
;
      k -= 8 * sizeof(int8_t);
    }
    if (k != 0) {
      const int8x8_t va0 = vld1_s8(a0)
/*@ where K=kc@pre, ab=a@pre, wb=w@pre, Ps=Ps, tile=((nc@pre-nc)/8), mode=0, j=(kc@pre-k), A=A */
; a0 = (const int8_t*) ((uintptr_t) a0 + k);
      const int16x8_t vxa0 = vmovl_s8(va0)
/*@ where a=&va0 */
;
      const int8x8_t vb01234567c0 = vld1_s8(w)
/*@ where K=kc@pre, ab=a@pre, wb=w@pre, Ps=Ps, tile=((nc@pre-nc)/8), mode=1, j=8*(kc@pre-k)+0, A=A */
; w = (const int8_t*) w + 8;
      const int16x8_t vxb01234567c0 = vmovl_s8(vb01234567c0)
/*@ where a=&vb01234567c0 */
;
      vacc0x0123 = vmlal_lane_s16(vacc0x0123, vget_low_s16(vxb01234567c0)
/*@ where a=&vxb01234567c0 */
, vget_low_s16(vxa0)
/*@ where a=&vxa0 */
, 0)
/*@ where acc=&vacc0x0123, a=0, b=0 */
;
      vacc0x4567 = vmlal_lane_s16(vacc0x4567, vget_high_s16(vxb01234567c0)
/*@ where a=&vxb01234567c0 */
, vget_low_s16(vxa0)
/*@ where a=&vxa0 */
, 0)
/*@ where acc=&vacc0x4567, a=0, b=0 */
;
      if (k >= 2 * sizeof(int8_t)) {
        const int8x8_t vb01234567c1 = vld1_s8(w)
/*@ where K=kc@pre, ab=a@pre, wb=w@pre, Ps=Ps, tile=((nc@pre-nc)/8), mode=1, j=8*(kc@pre-k)+8, A=A */
; w = (const int8_t*) w + 8;
        const int16x8_t vxb01234567c1 = vmovl_s8(vb01234567c1)
/*@ where a=&vb01234567c1 */
;
        vacc0x0123 = vmlal_lane_s16(vacc0x0123, vget_low_s16(vxb01234567c1)
/*@ where a=&vxb01234567c1 */
, vget_low_s16(vxa0)
/*@ where a=&vxa0 */
, 1)
/*@ where acc=&vacc0x0123, a=0, b=0 */
;
        vacc0x4567 = vmlal_lane_s16(vacc0x4567, vget_high_s16(vxb01234567c1)
/*@ where a=&vxb01234567c1 */
, vget_low_s16(vxa0)
/*@ where a=&vxa0 */
, 1)
/*@ where acc=&vacc0x4567, a=0, b=0 */
;
        if (k > 2 * sizeof(int8_t)) {
          const int8x8_t vb01234567c2 = vld1_s8(w)
/*@ where K=kc@pre, ab=a@pre, wb=w@pre, Ps=Ps, tile=((nc@pre-nc)/8), mode=1, j=8*(kc@pre-k)+16, A=A */
; w = (const int8_t*) w + 8;
          const int16x8_t vxb01234567c2 = vmovl_s8(vb01234567c2)
/*@ where a=&vb01234567c2 */
;
          vacc0x0123 = vmlal_lane_s16(vacc0x0123, vget_low_s16(vxb01234567c2)
/*@ where a=&vxb01234567c2 */
, vget_low_s16(vxa0)
/*@ where a=&vxa0 */
, 2)
/*@ where acc=&vacc0x0123, a=0, b=0 */
;
          vacc0x4567 = vmlal_lane_s16(vacc0x4567, vget_high_s16(vxb01234567c2)
/*@ where a=&vxb01234567c2 */
, vget_low_s16(vxa0)
/*@ where a=&vxa0 */
, 2)
/*@ where acc=&vacc0x4567, a=0, b=0 */
;
          if (k >= 4 * sizeof(int8_t)) {
            const int8x8_t vb01234567c3 = vld1_s8(w)
/*@ where K=kc@pre, ab=a@pre, wb=w@pre, Ps=Ps, tile=((nc@pre-nc)/8), mode=1, j=8*(kc@pre-k)+24, A=A */
; w = (const int8_t*) w + 8;
            const int16x8_t vxb01234567c3 = vmovl_s8(vb01234567c3)
/*@ where a=&vb01234567c3 */
;
            vacc0x0123 = vmlal_lane_s16(vacc0x0123, vget_low_s16(vxb01234567c3)
/*@ where a=&vxb01234567c3 */
, vget_low_s16(vxa0)
/*@ where a=&vxa0 */
, 3)
/*@ where acc=&vacc0x0123, a=0, b=0 */
;
            vacc0x4567 = vmlal_lane_s16(vacc0x4567, vget_high_s16(vxb01234567c3)
/*@ where a=&vxb01234567c3 */
, vget_low_s16(vxa0)
/*@ where a=&vxa0 */
, 3)
/*@ where acc=&vacc0x4567, a=0, b=0 */
;
            if (k > 4 * sizeof(int8_t)) {
              const int8x8_t vb01234567c4 = vld1_s8(w)
/*@ where K=kc@pre, ab=a@pre, wb=w@pre, Ps=Ps, tile=((nc@pre-nc)/8), mode=1, j=8*(kc@pre-k)+32, A=A */
; w = (const int8_t*) w + 8;
              const int16x8_t vxb01234567c4 = vmovl_s8(vb01234567c4)
/*@ where a=&vb01234567c4 */
;
              vacc0x0123 = vmlal_lane_s16(vacc0x0123, vget_low_s16(vxb01234567c4)
/*@ where a=&vxb01234567c4 */
, vget_high_s16(vxa0)
/*@ where a=&vxa0 */
, 0)
/*@ where acc=&vacc0x0123, a=0, b=0 */
;
              vacc0x4567 = vmlal_lane_s16(vacc0x4567, vget_high_s16(vxb01234567c4)
/*@ where a=&vxb01234567c4 */
, vget_high_s16(vxa0)
/*@ where a=&vxa0 */
, 0)
/*@ where acc=&vacc0x4567, a=0, b=0 */
;
              if (k >= 6 * sizeof(int8_t)) {
                const int8x8_t vb01234567c5 = vld1_s8(w)
/*@ where K=kc@pre, ab=a@pre, wb=w@pre, Ps=Ps, tile=((nc@pre-nc)/8), mode=1, j=8*(kc@pre-k)+40, A=A */
; w = (const int8_t*) w + 8;
                const int16x8_t vxb01234567c5 = vmovl_s8(vb01234567c5)
/*@ where a=&vb01234567c5 */
;
                vacc0x0123 = vmlal_lane_s16(vacc0x0123, vget_low_s16(vxb01234567c5)
/*@ where a=&vxb01234567c5 */
, vget_high_s16(vxa0)
/*@ where a=&vxa0 */
, 1)
/*@ where acc=&vacc0x0123, a=0, b=0 */
;
                vacc0x4567 = vmlal_lane_s16(vacc0x4567, vget_high_s16(vxb01234567c5)
/*@ where a=&vxb01234567c5 */
, vget_high_s16(vxa0)
/*@ where a=&vxa0 */
, 1)
/*@ where acc=&vacc0x4567, a=0, b=0 */
;
                if (k > 6 * sizeof(int8_t)) {
                  const int8x8_t vb01234567c6 = vld1_s8(w)
/*@ where K=kc@pre, ab=a@pre, wb=w@pre, Ps=Ps, tile=((nc@pre-nc)/8), mode=1, j=8*(kc@pre-k)+48, A=A */
; w = (const int8_t*) w + 8;
                  const int16x8_t vxb01234567c6 = vmovl_s8(vb01234567c6)
/*@ where a=&vb01234567c6 */
;
                  vacc0x0123 = vmlal_lane_s16(vacc0x0123, vget_low_s16(vxb01234567c6)
/*@ where a=&vxb01234567c6 */
, vget_high_s16(vxa0)
/*@ where a=&vxa0 */
, 2)
/*@ where acc=&vacc0x0123, a=0, b=0 */
;
                  vacc0x4567 = vmlal_lane_s16(vacc0x4567, vget_high_s16(vxb01234567c6)
/*@ where a=&vxb01234567c6 */
, vget_high_s16(vxa0)
/*@ where a=&vxa0 */
, 2)
/*@ where acc=&vacc0x4567, a=0, b=0 */
;
                }
              }
            }
          }
        }
      }
    }
    float32x4_t vfpacc0x0123 = vcvtq_f32_s32(vacc0x0123)
/*@ where a=&vacc0x0123 */
;
    float32x4_t vfpacc0x4567 = vcvtq_f32_s32(vacc0x4567)
/*@ where a=&vacc0x4567 */
;
    const float32x4_t vscale0123 = vld1q_f32((const float*) w)
/*@ where K=kc@pre, wb=w@pre, Ps=Ps, tile=((nc@pre-nc)/8), j=0 */
; w = (const float*) w + 4;
    vfpacc0x0123 = vmulq_f32(vfpacc0x0123, vscale0123)
/*@ where a=&vfpacc0x0123, b=&vscale0123 */
;
    const float32x4_t vscale4567 = vld1q_f32((const float*) w)
/*@ where K=kc@pre, wb=w@pre, Ps=Ps, tile=((nc@pre-nc)/8), j=4 */
; w = (const float*) w + 4;
    vfpacc0x4567 = vmulq_f32(vfpacc0x4567, vscale4567)
/*@ where a=&vfpacc0x4567, b=&vscale4567 */
;
    const float32x4_t vmagic_bias = vdupq_n_f32(params->fp32_neon.magic_bias);
    vacc0x0123 = vreinterpretq_s32_f32(vaddq_f32(vfpacc0x0123, vmagic_bias)
/*@ where a=&vfpacc0x0123, b=&vmagic_bias */
)
/*@ where a=0 */
;
    vacc0x4567 = vreinterpretq_s32_f32(vaddq_f32(vfpacc0x4567, vmagic_bias)
/*@ where a=&vfpacc0x4567, b=&vmagic_bias */
)
/*@ where a=0 */
;
    const int32x4_t vmagic_bias_less_output_zero_point = vdupq_n_s32(params->fp32_neon.magic_bias_less_output_zero_point);
    vacc0x0123 = vqsubq_s32(vacc0x0123, vmagic_bias_less_output_zero_point)
/*@ where a=&vacc0x0123, b=&vmagic_bias_less_output_zero_point */
;
    vacc0x4567 = vqsubq_s32(vacc0x4567, vmagic_bias_less_output_zero_point)
/*@ where a=&vacc0x4567, b=&vmagic_bias_less_output_zero_point */
;
      int16x8_t vacc0x01234567 = vqmovn_high_s32(vqmovn_s32(vacc0x0123)
/*@ where a=&vacc0x0123 */
, vacc0x4567)
/*@ where b=&vacc0x4567, a=0 */
;
      int8x8_t vout0x01234567 = vqmovn_s16(vacc0x01234567)
/*@ where a=&vacc0x01234567 */
;
    const int8x8_t voutput_min = vdup_n_s8(params->fp32_neon.output_min);
    vout0x01234567 = vmax_s8(vout0x01234567, voutput_min)
/*@ where a=&vout0x01234567, b=&voutput_min */
;
    const int8x8_t voutput_max = vdup_n_s8(params->fp32_neon.output_max);
    vout0x01234567 = vmin_s8(vout0x01234567, voutput_max)
/*@ where a=&vout0x01234567, b=&voutput_max */
;
    if (nc >= 8) {
      qcp_qs8_store8((c0 + 0),&(vout0x01234567))
/*@ where base=c@pre, N=nc@pre, done=(nc@pre-nc) */
;
      c0 = (int8_t*) ((uintptr_t) c0 + cn_stride);
      a0 = (const int8_t*) ((uintptr_t) a0 - kc);
      nc -= 8;
    } else {
      if (nc & 4) {
        { uint32x2_t qcp_store_tmp; qcp_store_tmp=(vreinterpret_u32_s8(vout0x01234567) /*@ where a=&vout0x01234567 */); qcp_qs8_store_u32(((void*) c0),&qcp_store_tmp,(0)) /*@ where base=c@pre, N=nc@pre, done=(nc@pre-nc) */; }; c0 += 4;
        vout0x01234567 = qcp_qs8_ext(&(vout0x01234567),&(vout0x01234567),(4));
      }
      if (nc & 2) {
        { uint16x4_t qcp_store_tmp; qcp_store_tmp=(vreinterpret_u16_s8(vout0x01234567) /*@ where a=&vout0x01234567 */); qcp_qs8_store_u16(((void*) c0),&qcp_store_tmp,(0)) /*@ where base=c@pre, N=nc@pre, done=(nc@pre-nc)+(nc&4) */; }; c0 += 2;
        vout0x01234567 = qcp_qs8_ext(&(vout0x01234567),&(vout0x01234567),(2));
      }
      if (nc & 1) {
        qcp_qs8_store_lane((c0),&(vout0x01234567),(0))
/*@ where base=c@pre, N=nc@pre, done=(nc@pre-nc)+(nc&4)+(nc&2) */
;
      }
      nc = 0;
    }
  }
/*@ Inv Assert exists (ap:Z) (wp:Z) (cp:Z), mr==mr@pre && kc==kc@pre && a==a@pre && c==c@pre && params==params@pre && a_stride==a_stride@pre && cm_stride==cm_stride@pre && cn_stride==8 && mr==1 && 0<kc@pre && 0<nc@pre && domain_shape(1,nc@pre,kc@pre,Ps) && data_capacity(nc@pre,kc@pre,a@pre,w@pre,c@pre) && qs8_matrix_wf(kc@pre,Ps) && sizeof(int8_t)==1 && sizeof(float)==4 && 0<=nc && nc<=nc@pre && a0==ap && w==wp && c0==cp && (nc==0 || (0<nc && (nc@pre-nc)%8==0 && 0<=((nc@pre-nc)/8) && ((nc@pre-nc)/8)<Zlength(Ps) && cp==pointer_offset(c@pre,(nc@pre-nc),char) && ap==a@pre && wp==pointer_offset(w@pre,((nc@pre-nc)/8)*(64+8*kc@pre),char))) && CharArray::full(a@pre,a_read_extent(kc@pre),A) * packed_matrix(kc@pre,w@pre,Ps) * qs8_output_prefix(c@pre,nc@pre,(nc@pre-nc),kc@pre,A,Ps,magic,offset,lo,hi) * store(&(params->fp32_neon.magic_bias),float,magic) * store(&(params->fp32_neon.magic_bias_less_output_zero_point),int,offset) * store(&(params->fp32_neon.output_min),char,lo) * store(&(params->fp32_neon.output_max),char,hi) */
while (nc != 0);
}
