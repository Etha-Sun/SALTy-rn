#include "shim/rvv-api.h"
void test_rvv(
    size_t mr,
    size_t nc,
    size_t kc,
    const int8_t* restrict a,
    size_t a_stride,
    const void* restrict w,
    int8_t* restrict c,
    size_t cm_stride,
    size_t cn_stride,
    const union xnn_qs8_qc8w_conv_minmax_params* restrict params) XNN_OOB_READS

/*@ With (A:list Z) (Ps:list panel_data) (magic:fp32) (offset:Z) (lo:Z) (hi:Z)
 Require mr==1 && 0<nc && 0<kc && domain_shape(mr,nc,kc,Ps) && data_capacity(nc,kc,a,w,c) && cn_stride==8 && a!=0 && w!=0 && c!=0 && params!=0 && CharArray::full(a,a_read_extent(kc),A) * packed_matrix(kc,w,Ps) * CharArray::undef_full(c,nc) * store(&(params->fp32_neon.magic_bias),float,magic) * store(&(params->fp32_neon.magic_bias_less_output_zero_point),int,offset) * store(&(params->fp32_neon.output_min),char,lo) * store(&(params->fp32_neon.output_max),char,hi)
 Ensure CharArray::full(a@pre,a_read_extent(kc@pre),A) * packed_matrix(kc@pre,w@pre,Ps) * qs8_output_ref(c@pre,nc@pre,kc@pre,A,Ps,magic,offset,lo,hi) * store(&(params->fp32_neon.magic_bias),float,magic) * store(&(params->fp32_neon.magic_bias_less_output_zero_point),int,offset) * store(&(params->fp32_neon.output_min),char,lo) * store(&(params->fp32_neon.output_max),char,hi) */
{
  assert(mr != 0);
  assert(mr <= 1);
  assert(nc != 0);
  assert(kc != 0);
  
/*@ emp which implies sizeof(int8_t)==1 && kc@pre%sizeof(int8_t)==0 && emp */
assert(kc % sizeof(int8_t) == 0);
  assert(a != NULL);
  assert(w != NULL);
  assert(c != NULL);

  const int8_t* a0 = a;
  int8_t* c0 = c;

  do {
    // The weights are packed in fixed blocks of NR=8:
    //   [8 x i32 bias][kc x 8 x i8][8 x f32 scale]
    size_t vl = __riscv_vsetvl_e32m2(nc < 8 ? nc : 8);

    vint32m2_t vacc = __riscv_vle32_v_i32m2((const int32_t*) w, vl)
/*@ where K=kc@pre, wb=w@pre, tile=((nc@pre-nc)/8), Ps=Ps, j=0 */
;
    w = (const int32_t*) w + 8;

    size_t k = kc;
    do {
      
/*@ a0==pointer_offset(a@pre,(kc@pre-k),char) && 0<=(kc@pre-k) && (kc@pre-k)<a_read_extent(kc@pre) && CharArray::full(a@pre,a_read_extent(kc@pre),A) which implies a0==pointer_offset(a@pre,(kc@pre-k),char) && 0<=(kc@pre-k) && (kc@pre-k)<a_read_extent(kc@pre) && CharArray::missing_i(a@pre,(kc@pre-k),0,a_read_extent(kc@pre),A) * store(a0,char,A[(kc@pre-k)]) */
const int16_t va0 = (int16_t) *a0;
      a0 += 1;

      vint8mf2_t vb = __riscv_vle8_v_i8mf2((const int8_t*) w, vl)
/*@ where K=kc@pre, wb=w@pre, tile=((nc@pre-nc)/8), Ps=Ps, j=8*(kc@pre-k) */
;
      w = (const int8_t*) w + 8;
      vint16m1_t vxb = __riscv_vsext_vf2_i16m1(vb, vl)
/*@ where a=&vb */
;

      vacc = __riscv_vwmacc_vx_i32m2(vacc, va0, vxb, vl)
/*@ where a=&vacc, b=&vxb */
;

      k -= sizeof(int8_t);
    } 
/*@ Inv Assert exists (r0:Z) (r1:Z) (r2:Z) (r3:Z) (r4:Z) (r5:Z) (r6:Z) (r7:Z), mr==mr@pre && kc==kc@pre && a==a@pre && c==c@pre && params==params@pre && a_stride==a_stride@pre && cm_stride==cm_stride@pre && cn_stride==8 && mr==1 && 0<kc@pre && 0<nc@pre && domain_shape(1,nc@pre,kc@pre,Ps) && data_capacity(nc@pre,kc@pre,a@pre,w@pre,c@pre) && qs8_matrix_wf(kc@pre,Ps) && sizeof(int8_t)==1 && sizeof(float)==4 && 0<=nc && nc<=nc@pre && 0<nc && (nc@pre-nc)%8==0 && 0<=((nc@pre-nc)/8) && ((nc@pre-nc)/8)<Zlength(Ps) && c0==pointer_offset(c@pre,(nc@pre-nc),char) && 1<=vl && vl<=8 && vl==qs8_min(nc,8) && 0<=k && k<=kc@pre && a0==pointer_offset(a@pre,(kc@pre-k),char) && w==pointer_offset(w@pre,((nc@pre-nc)/8)*(64+8*kc@pre)+32+8*(kc@pre-k),char) && qs8_active_z(vl,0,r0,qs8_acc((kc@pre-k),((nc@pre-nc)/8),0,A,Ps)) && qs8_active_z(vl,1,r1,qs8_acc((kc@pre-k),((nc@pre-nc)/8),1,A,Ps)) && qs8_active_z(vl,2,r2,qs8_acc((kc@pre-k),((nc@pre-nc)/8),2,A,Ps)) && qs8_active_z(vl,3,r3,qs8_acc((kc@pre-k),((nc@pre-nc)/8),3,A,Ps)) && qs8_active_z(vl,4,r4,qs8_acc((kc@pre-k),((nc@pre-nc)/8),4,A,Ps)) && qs8_active_z(vl,5,r5,qs8_acc((kc@pre-k),((nc@pre-nc)/8),5,A,Ps)) && qs8_active_z(vl,6,r6,qs8_acc((kc@pre-k),((nc@pre-nc)/8),6,A,Ps)) && qs8_active_z(vl,7,r7,qs8_acc((kc@pre-k),((nc@pre-nc)/8),7,A,Ps)) && CharArray::full(a@pre,a_read_extent(kc@pre),A) * packed_matrix(kc@pre,w@pre,Ps) * qs8_output_prefix(c@pre,nc@pre,(nc@pre-nc),kc@pre,A,Ps,magic,offset,lo,hi) * store(&(params->fp32_neon.magic_bias),float,magic) * store(&(params->fp32_neon.magic_bias_less_output_zero_point),int,offset) * store(&(params->fp32_neon.output_min),char,lo) * store(&(params->fp32_neon.output_max),char,hi) * store(&(vacc.s0),int,r0) * store(&(vacc.s1),int,r1) * store(&(vacc.s2),int,r2) * store(&(vacc.s3),int,r3) * store(&(vacc.s4),int,r4) * store(&(vacc.s5),int,r5) * store(&(vacc.s6),int,r6) * store(&(vacc.s7),int,r7) */
while (k != 0);

    vfloat32m2_t vfpacc = __riscv_vfcvt_f_x_v_f32m2(vacc, vl)
/*@ where a=&vacc */
;

    vfloat32m2_t vscale = __riscv_vle32_v_f32m2((const float*) w, vl)
/*@ where K=kc@pre, wb=w@pre, tile=((nc@pre-nc)/8), Ps=Ps, j=0 */
;
    w = (const float*) w + 8;
    vfpacc = __riscv_vfmul_vv_f32m2(vfpacc, vscale, vl)
/*@ where a=&vfpacc, b=&vscale */
;

    // Restore ARM DN=0 NaN bits before reinterpretation to an integer.
    // The integer conversion is finite; only scale can supply a NaN to mul.
    const vbool16_t scale_nan = __riscv_vmfne_vv_f32m2_b16(vscale, vscale, vl);
    const vint32m2_t scale_bits = __riscv_vreinterpret_v_f32m2_i32m2(vscale)
/*@ where a=&vscale */
;
    const vint32m2_t scale_quiet = __riscv_vor_vx_i32m2(scale_bits, 0x00400000, vl)
/*@ where a=&scale_bits */
;
    vint32m2_t product_bits = __riscv_vreinterpret_v_f32m2_i32m2(vfpacc)
/*@ where a=&vfpacc */
;
    product_bits = __riscv_vmerge_vvm_i32m2(product_bits, scale_quiet, scale_nan, vl)
/*@ where a=&product_bits, b=&scale_quiet, m=&scale_nan */
;
    vfpacc = __riscv_vreinterpret_v_i32m2_f32m2(product_bits)
/*@ where a=&product_bits */
;

    const vbool16_t product_nan = __riscv_vmfne_vv_f32m2_b16(vfpacc, vfpacc, vl);
    const vfloat32m2_t magic = __riscv_vfmv_v_f_f32m2(params->fp32_neon.magic_bias, vl);
    const vint32m2_t magic_bits = __riscv_vreinterpret_v_f32m2_i32m2(magic)
/*@ where a=&magic */
;
    const vint32m2_t magic_abs = __riscv_vand_vx_i32m2(magic_bits, 0x7fffffff, vl)
/*@ where a=&magic_bits */
;
    const vbool16_t magic_nan = __riscv_vmsgt_vx_i32m2_b16(magic_abs, 0x7f800000, vl)
/*@ where a=&magic_abs */
;
    const vint32m2_t magic_qbit = __riscv_vand_vx_i32m2(magic_bits, 0x00400000, vl)
/*@ where a=&magic_bits */
;
    const vbool16_t magic_qzero = __riscv_vmseq_vx_i32m2_b16(magic_qbit, 0, vl)
/*@ where a=&magic_qbit */
;
    const vbool16_t magic_snan = __riscv_vmand_mm_b16(magic_nan, magic_qzero, vl)
/*@ where a=&magic_nan, b=&magic_qzero */
;
    const vint32m2_t magic_quiet = __riscv_vor_vx_i32m2(magic_bits, 0x00400000, vl)
/*@ where a=&magic_bits */
;

    // Product NaN has priority over quiet magic; signaling magic has priority
    // over the already quiet product. Invalid finite/Inf arithmetic is canonical.
    vfpacc = __riscv_vfadd_vf_f32m2(vfpacc, params->fp32_neon.magic_bias, vl)
/*@ where a=&vfpacc */
;
    vacc = __riscv_vreinterpret_v_f32m2_i32m2(vfpacc)
/*@ where a=&vfpacc */
;
    vacc = __riscv_vmerge_vvm_i32m2(vacc, magic_quiet, magic_nan, vl)
/*@ where a=&vacc, b=&magic_quiet, m=&magic_nan */
;
    vacc = __riscv_vmerge_vvm_i32m2(vacc, product_bits, product_nan, vl)
/*@ where a=&vacc, b=&product_bits, m=&product_nan */
;
    vacc = __riscv_vmerge_vvm_i32m2(vacc, magic_quiet, magic_snan, vl)
/*@ where a=&vacc, b=&magic_quiet, m=&magic_snan */
;
    vacc = __riscv_vssub_vx_i32m2(vacc, params->fp32_neon.magic_bias_less_output_zero_point, vl)
/*@ where a=&vacc */
;

    vint16m1_t vout16 = __riscv_vnclip_wx_i16m1(vacc, 0, __RISCV_VXRM_RDN, vl)
/*@ where a=&vacc */
;
    vint8mf2_t vout = __riscv_vnclip_wx_i8mf2(vout16, 0, __RISCV_VXRM_RDN, vl)
/*@ where a=&vout16 */
;

    vout = __riscv_vmax_vx_i8mf2(vout, params->fp32_neon.output_min, vl)
/*@ where a=&vout */
;
    vout = __riscv_vmin_vx_i8mf2(vout, params->fp32_neon.output_max, vl)
/*@ where a=&vout */
;

    __riscv_vse8_v_i8mf2(c0, vout, vl)
/*@ where base=c@pre, N=nc@pre, done=(nc@pre-nc) */
;

    c0 = (int8_t*) ((uintptr_t) c0 + cn_stride);
    a0 = (const int8_t*) ((uintptr_t) a0 - kc);
    nc -= vl;
  } 
/*@ Inv Assert exists (ap:Z) (wp:Z) (cp:Z), mr==mr@pre && kc==kc@pre && a==a@pre && c==c@pre && params==params@pre && a_stride==a_stride@pre && cm_stride==cm_stride@pre && cn_stride==8 && mr==1 && 0<kc@pre && 0<nc@pre && domain_shape(1,nc@pre,kc@pre,Ps) && data_capacity(nc@pre,kc@pre,a@pre,w@pre,c@pre) && qs8_matrix_wf(kc@pre,Ps) && sizeof(int8_t)==1 && sizeof(float)==4 && 0<=nc && nc<=nc@pre && a0==ap && w==wp && c0==cp && (nc==0 || (0<nc && (nc@pre-nc)%8==0 && 0<=((nc@pre-nc)/8) && ((nc@pre-nc)/8)<Zlength(Ps) && cp==pointer_offset(c@pre,(nc@pre-nc),char) && ap==a@pre && wp==pointer_offset(w@pre,((nc@pre-nc)/8)*(64+8*kc@pre),char))) && CharArray::full(a@pre,a_read_extent(kc@pre),A) * packed_matrix(kc@pre,w@pre,Ps) * qs8_output_prefix(c@pre,nc@pre,(nc@pre-nc),kc@pre,A,Ps,magic,offset,lo,hi) * store(&(params->fp32_neon.magic_bias),float,magic) * store(&(params->fp32_neon.magic_bias_less_output_zero_point),int,offset) * store(&(params->fp32_neon.output_min),char,lo) * store(&(params->fp32_neon.output_max),char,hi) */
while (nc != 0);
}
