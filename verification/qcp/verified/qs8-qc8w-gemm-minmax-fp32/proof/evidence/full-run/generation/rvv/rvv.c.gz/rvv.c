typedef unsigned long long size_t;
typedef unsigned long long uintptr_t;
typedef signed char int8_t;
typedef short int16_t;
typedef int int32_t;
typedef unsigned int uint32_t;
struct qs8_fp32_params { float magic_bias; int32_t magic_bias_less_output_zero_point; int8_t output_min; int8_t output_max; };
struct xnn_qs8_qc8w_conv_minmax_params { struct qs8_fp32_params fp32_neon; };
/* Only the named fp32_neon member is used. This is the C-shim representation,
   not a physical union-layout or ABI theorem. */
/* Scalar fields are the candidate C representation, not an ISA ABI proof. */
struct int8x8_t { int8_t s0,s1,s2,s3,s4,s5,s6,s7; };
struct int16x8_t { int16_t s0,s1,s2,s3,s4,s5,s6,s7; };
struct int16x4_t { int16_t s0,s1,s2,s3; };
struct int32x4_t { int32_t s0,s1,s2,s3; };
struct float32x4_t { float s0,s1,s2,s3; };
struct float32x2_t { float s0,s1; };
struct vint8mf2_t { int8_t s0,s1,s2,s3,s4,s5,s6,s7; };
struct vint16m1_t { int16_t s0,s1,s2,s3,s4,s5,s6,s7; };
struct vint32m2_t { int32_t s0,s1,s2,s3,s4,s5,s6,s7; };
struct vfloat32m2_t { float s0,s1,s2,s3,s4,s5,s6,s7; };
struct vbool16_t { int s0,s1,s2,s3,s4,s5,s6,s7; };
typedef struct int8x8_t int8x8_t;
typedef struct int16x8_t int16x8_t;
typedef struct int16x4_t int16x4_t;
typedef struct int32x4_t int32x4_t;
typedef struct float32x4_t float32x4_t;
typedef struct float32x2_t float32x2_t;
typedef struct vint8mf2_t vint8mf2_t;
typedef struct vint16m1_t vint16m1_t;
typedef struct vint32m2_t vint32m2_t;
typedef struct vfloat32m2_t vfloat32m2_t;
typedef struct vbool16_t vbool16_t;
struct uint32x2_t { int8_t s0,s1,s2,s3,s4,s5,s6,s7; };
struct uint16x4_t { int8_t s0,s1,s2,s3,s4,s5,s6,s7; };
typedef struct uint32x2_t uint32x2_t;
typedef struct uint16x4_t uint16x4_t;
/*@ Import Coq Require Import Qs8Gemm.Model Qs8Gemm.Layouts */
/*@ Extern Coq (panel_data :: *) */
/*@ Extern Coq

 (domain_shape:Z -> Z -> Z -> list panel_data -> Prop)
 (data_capacity:Z -> Z -> Z -> Z -> Z -> Prop)
 (packed_matrix:Z -> Z -> list panel_data -> Assertion)
 (a_read_extent:Z -> Z)
 (panel_bytes:Z -> Z)
 (panels:Z -> Z)
 (weights:panel_data -> list Z)
 (panel_at:list panel_data -> Z -> panel_data)
 (qs8_matrix_wf:Z -> list panel_data -> Prop)
 (qs8_bias:Z -> Z -> list panel_data -> Z)
 (qs8_scale:Z -> Z -> list panel_data -> fp32)
 (qs8_char:Z -> Z -> Z -> Z -> list Z -> list panel_data -> Z)
 (qs8_i8_address_ok:Z -> Z -> Z -> Z -> Z -> Z -> Z -> list panel_data -> Prop)
 (qs8_zget:Z -> list Z -> Z)
 (qs8_acc:Z -> Z -> Z -> list Z -> list panel_data -> Z)
 (qs8_output_prefix:Z -> Z -> Z -> Z -> list Z -> list panel_data -> fp32 -> Z -> Z -> Z -> Assertion)
 (qs8_output_ref:Z -> Z -> Z -> list Z -> list panel_data -> fp32 -> Z -> Z -> Z -> Assertion)
 (completed_values:Z -> Z -> list Z -> list panel_data -> fp32 -> Z -> Z -> Z -> list Z)
 (qs8_write_state:Z -> Z -> Z -> list Z -> Assertion)
 (qs8_append:list Z -> list Z -> list Z)
 (qs8_take:Z -> list Z -> list Z)
 (qs8_mac:Z -> Z -> Z -> Z)
 (qs8_lane4:Z -> Z -> Z -> Z -> Z -> Z)
 (qs8_ssub32:Z -> Z -> Z)
 (qs8_narrow16:Z -> Z)
 (qs8_narrow8:Z -> Z)
 (qs8_reinterpret:fp32 -> Z)
 (qs8_uninterpret:Z -> fp32)
 (qs8_or32:Z -> Z -> Z)
 (qs8_and32:Z -> Z -> Z)
 (qs8_merge:Z -> Z -> Z -> Z)
 (qs8_mask_and:Z -> Z -> Z)
 (qs8_gt:Z -> Z -> Z)
 (qs8_eq:Z -> Z -> Z)
 (qs8_nan:fp32 -> Z)
 (qs8_ext:Z -> Z -> list Z -> Z)
 (qs8_active_z:Z -> Z -> Z -> Z -> Prop)
 (qs8_active_f:Z -> Z -> fp32 -> fp32 -> Prop)
 (qs8_final:Z -> Z -> list Z -> list panel_data -> fp32 -> Z -> Z -> Z -> Z)
 (fp32_of_Z:Z -> fp32)
 (f16_arm_mul:fp32 -> fp32 -> fp32)
 (f16_arm_add:fp32 -> fp32 -> fp32)
 (f16_rvv_mul:fp32 -> fp32 -> fp32)
 (f16_rvv_add:fp32 -> fp32 -> fp32) */
/*@ Extern Coq (qs8_min:Z -> Z -> Z) (qs8_max:Z -> Z -> Z) */
/*@ Extern Coq (CharArray::full:Z -> Z -> list Z -> Assertion) (CharArray::undef_full:Z -> Z -> Assertion) (CharArray::missing_i:Z -> Z -> Z -> Z -> list Z -> Assertion) */
/*@ Extern Coq (panel_data :: *) */
/*@ Import Coq Require Import Qs8Gemm.Model Qs8Gemm.Layouts */
/*@ Extern Coq (UndefStructPredint8x8_t:Z -> Assertion) (UndefStructPredint16x8_t:Z -> Assertion) (UndefStructPredint16x4_t:Z -> Assertion) (UndefStructPredint32x4_t:Z -> Assertion) (UndefStructPredfloat32x4_t:Z -> Assertion) (UndefStructPredfloat32x2_t:Z -> Assertion) (UndefStructPredvint8mf2_t:Z -> Assertion) (UndefStructPredvint16m1_t:Z -> Assertion) (UndefStructPredvint32m2_t:Z -> Assertion) (UndefStructPredvfloat32m2_t:Z -> Assertion) (UndefStructPredvbool16_t:Z -> Assertion) (UndefStructPreduint32x2_t:Z -> Assertion) (UndefStructPreduint16x4_t:Z -> Assertion) (qs8_output_prefix:Z -> Z -> Z -> Z -> list Z -> list panel_data -> fp32 -> Z -> Z -> Z -> Assertion) (completed_values:Z -> Z -> list Z -> list panel_data -> fp32 -> Z -> Z -> Z -> list Z) (qs8_write_state:Z -> Z -> Z -> list Z -> Assertion) */
/*@ include strategies "copy.strategies" */
vint16m1_t __riscv_vsext_vf2_i16m1(vint8mf2_t a,size_t vl)
/*@ With (x0:Z) (x1:Z) (x2:Z) (x3:Z) (x4:Z) (x5:Z) (x6:Z) (x7:Z)
 Require 1<=vl && vl<=8 && store(&(a.s0),char,x0) * store(&(a.s1),char,x1) * store(&(a.s2),char,x2) * store(&(a.s3),char,x3) * store(&(a.s4),char,x4) * store(&(a.s5),char,x5) * store(&(a.s6),char,x6) * store(&(a.s7),char,x7)
 Ensure exists (r0:Z) (r1:Z) (r2:Z) (r3:Z) (r4:Z) (r5:Z) (r6:Z) (r7:Z), qs8_active_z(vl,0,r0,x0) && qs8_active_z(vl,1,r1,x1) && qs8_active_z(vl,2,r2,x2) && qs8_active_z(vl,3,r3,x3) && qs8_active_z(vl,4,r4,x4) && qs8_active_z(vl,5,r5,x5) && qs8_active_z(vl,6,r6,x6) && qs8_active_z(vl,7,r7,x7) && store(&(__return.s0),short,r0) * store(&(__return.s1),short,r1) * store(&(__return.s2),short,r2) * store(&(__return.s3),short,r3) * store(&(__return.s4),short,r4) * store(&(__return.s5),short,r5) * store(&(__return.s6),short,r6) * store(&(__return.s7),short,r7) */;
vint32m2_t __riscv_vwmacc_vx_i32m2(vint32m2_t a,int16_t s,vint16m1_t b,size_t vl)
/*@ With (x0:Z) (x1:Z) (x2:Z) (x3:Z) (x4:Z) (x5:Z) (x6:Z) (x7:Z) (y0:Z) (y1:Z) (y2:Z) (y3:Z) (y4:Z) (y5:Z) (y6:Z) (y7:Z)
 Require 1<=vl && vl<=8 && store(&(a.s0),int,x0) * store(&(a.s1),int,x1) * store(&(a.s2),int,x2) * store(&(a.s3),int,x3) * store(&(a.s4),int,x4) * store(&(a.s5),int,x5) * store(&(a.s6),int,x6) * store(&(a.s7),int,x7) * store(&(b.s0),short,y0) * store(&(b.s1),short,y1) * store(&(b.s2),short,y2) * store(&(b.s3),short,y3) * store(&(b.s4),short,y4) * store(&(b.s5),short,y5) * store(&(b.s6),short,y6) * store(&(b.s7),short,y7)
 Ensure exists (r0:Z) (r1:Z) (r2:Z) (r3:Z) (r4:Z) (r5:Z) (r6:Z) (r7:Z), qs8_active_z(vl,0,r0,qs8_mac(x0,s,y0)) && qs8_active_z(vl,1,r1,qs8_mac(x1,s,y1)) && qs8_active_z(vl,2,r2,qs8_mac(x2,s,y2)) && qs8_active_z(vl,3,r3,qs8_mac(x3,s,y3)) && qs8_active_z(vl,4,r4,qs8_mac(x4,s,y4)) && qs8_active_z(vl,5,r5,qs8_mac(x5,s,y5)) && qs8_active_z(vl,6,r6,qs8_mac(x6,s,y6)) && qs8_active_z(vl,7,r7,qs8_mac(x7,s,y7)) && store(&(__return.s0),int,r0) * store(&(__return.s1),int,r1) * store(&(__return.s2),int,r2) * store(&(__return.s3),int,r3) * store(&(__return.s4),int,r4) * store(&(__return.s5),int,r5) * store(&(__return.s6),int,r6) * store(&(__return.s7),int,r7) */;
vfloat32m2_t __riscv_vfcvt_f_x_v_f32m2(vint32m2_t a,size_t vl)
/*@ With (x0:Z) (x1:Z) (x2:Z) (x3:Z) (x4:Z) (x5:Z) (x6:Z) (x7:Z)
 Require 1<=vl && vl<=8 && store(&(a.s0),int,x0) * store(&(a.s1),int,x1) * store(&(a.s2),int,x2) * store(&(a.s3),int,x3) * store(&(a.s4),int,x4) * store(&(a.s5),int,x5) * store(&(a.s6),int,x6) * store(&(a.s7),int,x7)
 Ensure exists (r0:fp32) (r1:fp32) (r2:fp32) (r3:fp32) (r4:fp32) (r5:fp32) (r6:fp32) (r7:fp32), qs8_active_f(vl,0,r0,fp32_of_Z(x0)) && qs8_active_f(vl,1,r1,fp32_of_Z(x1)) && qs8_active_f(vl,2,r2,fp32_of_Z(x2)) && qs8_active_f(vl,3,r3,fp32_of_Z(x3)) && qs8_active_f(vl,4,r4,fp32_of_Z(x4)) && qs8_active_f(vl,5,r5,fp32_of_Z(x5)) && qs8_active_f(vl,6,r6,fp32_of_Z(x6)) && qs8_active_f(vl,7,r7,fp32_of_Z(x7)) && store(&(__return.s0),float,r0) * store(&(__return.s1),float,r1) * store(&(__return.s2),float,r2) * store(&(__return.s3),float,r3) * store(&(__return.s4),float,r4) * store(&(__return.s5),float,r5) * store(&(__return.s6),float,r6) * store(&(__return.s7),float,r7) */;
vfloat32m2_t __riscv_vfmul_vv_f32m2(vfloat32m2_t a,vfloat32m2_t b,size_t vl)
/*@ With (x0:fp32) (x1:fp32) (x2:fp32) (x3:fp32) (x4:fp32) (x5:fp32) (x6:fp32) (x7:fp32) (y0:fp32) (y1:fp32) (y2:fp32) (y3:fp32) (y4:fp32) (y5:fp32) (y6:fp32) (y7:fp32)
 Require 1<=vl && vl<=8 && store(&(a.s0),float,x0) * store(&(a.s1),float,x1) * store(&(a.s2),float,x2) * store(&(a.s3),float,x3) * store(&(a.s4),float,x4) * store(&(a.s5),float,x5) * store(&(a.s6),float,x6) * store(&(a.s7),float,x7) * store(&(b.s0),float,y0) * store(&(b.s1),float,y1) * store(&(b.s2),float,y2) * store(&(b.s3),float,y3) * store(&(b.s4),float,y4) * store(&(b.s5),float,y5) * store(&(b.s6),float,y6) * store(&(b.s7),float,y7)
 Ensure exists (r0:fp32) (r1:fp32) (r2:fp32) (r3:fp32) (r4:fp32) (r5:fp32) (r6:fp32) (r7:fp32), qs8_active_f(vl,0,r0,f16_rvv_mul(x0,y0)) && qs8_active_f(vl,1,r1,f16_rvv_mul(x1,y1)) && qs8_active_f(vl,2,r2,f16_rvv_mul(x2,y2)) && qs8_active_f(vl,3,r3,f16_rvv_mul(x3,y3)) && qs8_active_f(vl,4,r4,f16_rvv_mul(x4,y4)) && qs8_active_f(vl,5,r5,f16_rvv_mul(x5,y5)) && qs8_active_f(vl,6,r6,f16_rvv_mul(x6,y6)) && qs8_active_f(vl,7,r7,f16_rvv_mul(x7,y7)) && store(&(__return.s0),float,r0) * store(&(__return.s1),float,r1) * store(&(__return.s2),float,r2) * store(&(__return.s3),float,r3) * store(&(__return.s4),float,r4) * store(&(__return.s5),float,r5) * store(&(__return.s6),float,r6) * store(&(__return.s7),float,r7) */;
vfloat32m2_t __riscv_vfadd_vf_f32m2(vfloat32m2_t a,float s,size_t vl)
/*@ With (x0:fp32) (x1:fp32) (x2:fp32) (x3:fp32) (x4:fp32) (x5:fp32) (x6:fp32) (x7:fp32)
 Require 1<=vl && vl<=8 && store(&(a.s0),float,x0) * store(&(a.s1),float,x1) * store(&(a.s2),float,x2) * store(&(a.s3),float,x3) * store(&(a.s4),float,x4) * store(&(a.s5),float,x5) * store(&(a.s6),float,x6) * store(&(a.s7),float,x7)
 Ensure exists (r0:fp32) (r1:fp32) (r2:fp32) (r3:fp32) (r4:fp32) (r5:fp32) (r6:fp32) (r7:fp32), qs8_active_f(vl,0,r0,f16_rvv_add(x0,s)) && qs8_active_f(vl,1,r1,f16_rvv_add(x1,s)) && qs8_active_f(vl,2,r2,f16_rvv_add(x2,s)) && qs8_active_f(vl,3,r3,f16_rvv_add(x3,s)) && qs8_active_f(vl,4,r4,f16_rvv_add(x4,s)) && qs8_active_f(vl,5,r5,f16_rvv_add(x5,s)) && qs8_active_f(vl,6,r6,f16_rvv_add(x6,s)) && qs8_active_f(vl,7,r7,f16_rvv_add(x7,s)) && store(&(__return.s0),float,r0) * store(&(__return.s1),float,r1) * store(&(__return.s2),float,r2) * store(&(__return.s3),float,r3) * store(&(__return.s4),float,r4) * store(&(__return.s5),float,r5) * store(&(__return.s6),float,r6) * store(&(__return.s7),float,r7) */;
vint32m2_t __riscv_vssub_vx_i32m2(vint32m2_t a,int32_t s,size_t vl)
/*@ With (x0:Z) (x1:Z) (x2:Z) (x3:Z) (x4:Z) (x5:Z) (x6:Z) (x7:Z)
 Require 1<=vl && vl<=8 && store(&(a.s0),int,x0) * store(&(a.s1),int,x1) * store(&(a.s2),int,x2) * store(&(a.s3),int,x3) * store(&(a.s4),int,x4) * store(&(a.s5),int,x5) * store(&(a.s6),int,x6) * store(&(a.s7),int,x7)
 Ensure exists (r0:Z) (r1:Z) (r2:Z) (r3:Z) (r4:Z) (r5:Z) (r6:Z) (r7:Z), qs8_active_z(vl,0,r0,qs8_ssub32(x0,s)) && qs8_active_z(vl,1,r1,qs8_ssub32(x1,s)) && qs8_active_z(vl,2,r2,qs8_ssub32(x2,s)) && qs8_active_z(vl,3,r3,qs8_ssub32(x3,s)) && qs8_active_z(vl,4,r4,qs8_ssub32(x4,s)) && qs8_active_z(vl,5,r5,qs8_ssub32(x5,s)) && qs8_active_z(vl,6,r6,qs8_ssub32(x6,s)) && qs8_active_z(vl,7,r7,qs8_ssub32(x7,s)) && store(&(__return.s0),int,r0) * store(&(__return.s1),int,r1) * store(&(__return.s2),int,r2) * store(&(__return.s3),int,r3) * store(&(__return.s4),int,r4) * store(&(__return.s5),int,r5) * store(&(__return.s6),int,r6) * store(&(__return.s7),int,r7) */;
vint32m2_t __riscv_vor_vx_i32m2(vint32m2_t a,int32_t s,size_t vl)
/*@ With (x0:Z) (x1:Z) (x2:Z) (x3:Z) (x4:Z) (x5:Z) (x6:Z) (x7:Z)
 Require 1<=vl && vl<=8 && store(&(a.s0),int,x0) * store(&(a.s1),int,x1) * store(&(a.s2),int,x2) * store(&(a.s3),int,x3) * store(&(a.s4),int,x4) * store(&(a.s5),int,x5) * store(&(a.s6),int,x6) * store(&(a.s7),int,x7)
 Ensure exists (r0:Z) (r1:Z) (r2:Z) (r3:Z) (r4:Z) (r5:Z) (r6:Z) (r7:Z), qs8_active_z(vl,0,r0,qs8_or32(x0,s)) && qs8_active_z(vl,1,r1,qs8_or32(x1,s)) && qs8_active_z(vl,2,r2,qs8_or32(x2,s)) && qs8_active_z(vl,3,r3,qs8_or32(x3,s)) && qs8_active_z(vl,4,r4,qs8_or32(x4,s)) && qs8_active_z(vl,5,r5,qs8_or32(x5,s)) && qs8_active_z(vl,6,r6,qs8_or32(x6,s)) && qs8_active_z(vl,7,r7,qs8_or32(x7,s)) && store(&(__return.s0),int,r0) * store(&(__return.s1),int,r1) * store(&(__return.s2),int,r2) * store(&(__return.s3),int,r3) * store(&(__return.s4),int,r4) * store(&(__return.s5),int,r5) * store(&(__return.s6),int,r6) * store(&(__return.s7),int,r7) */;
vint32m2_t __riscv_vand_vx_i32m2(vint32m2_t a,int32_t s,size_t vl)
/*@ With (x0:Z) (x1:Z) (x2:Z) (x3:Z) (x4:Z) (x5:Z) (x6:Z) (x7:Z)
 Require 1<=vl && vl<=8 && store(&(a.s0),int,x0) * store(&(a.s1),int,x1) * store(&(a.s2),int,x2) * store(&(a.s3),int,x3) * store(&(a.s4),int,x4) * store(&(a.s5),int,x5) * store(&(a.s6),int,x6) * store(&(a.s7),int,x7)
 Ensure exists (r0:Z) (r1:Z) (r2:Z) (r3:Z) (r4:Z) (r5:Z) (r6:Z) (r7:Z), qs8_active_z(vl,0,r0,qs8_and32(x0,s)) && qs8_active_z(vl,1,r1,qs8_and32(x1,s)) && qs8_active_z(vl,2,r2,qs8_and32(x2,s)) && qs8_active_z(vl,3,r3,qs8_and32(x3,s)) && qs8_active_z(vl,4,r4,qs8_and32(x4,s)) && qs8_active_z(vl,5,r5,qs8_and32(x5,s)) && qs8_active_z(vl,6,r6,qs8_and32(x6,s)) && qs8_active_z(vl,7,r7,qs8_and32(x7,s)) && store(&(__return.s0),int,r0) * store(&(__return.s1),int,r1) * store(&(__return.s2),int,r2) * store(&(__return.s3),int,r3) * store(&(__return.s4),int,r4) * store(&(__return.s5),int,r5) * store(&(__return.s6),int,r6) * store(&(__return.s7),int,r7) */;
vint32m2_t __riscv_vmerge_vvm_i32m2(vint32m2_t a,vint32m2_t b,vbool16_t m,size_t vl)
/*@ With (x0:Z) (x1:Z) (x2:Z) (x3:Z) (x4:Z) (x5:Z) (x6:Z) (x7:Z) (y0:Z) (y1:Z) (y2:Z) (y3:Z) (y4:Z) (y5:Z) (y6:Z) (y7:Z) (z0:Z) (z1:Z) (z2:Z) (z3:Z) (z4:Z) (z5:Z) (z6:Z) (z7:Z)
 Require 1<=vl && vl<=8 && store(&(a.s0),int,x0) * store(&(a.s1),int,x1) * store(&(a.s2),int,x2) * store(&(a.s3),int,x3) * store(&(a.s4),int,x4) * store(&(a.s5),int,x5) * store(&(a.s6),int,x6) * store(&(a.s7),int,x7) * store(&(b.s0),int,y0) * store(&(b.s1),int,y1) * store(&(b.s2),int,y2) * store(&(b.s3),int,y3) * store(&(b.s4),int,y4) * store(&(b.s5),int,y5) * store(&(b.s6),int,y6) * store(&(b.s7),int,y7) * store(&(m.s0),int,z0) * store(&(m.s1),int,z1) * store(&(m.s2),int,z2) * store(&(m.s3),int,z3) * store(&(m.s4),int,z4) * store(&(m.s5),int,z5) * store(&(m.s6),int,z6) * store(&(m.s7),int,z7)
 Ensure exists (r0:Z) (r1:Z) (r2:Z) (r3:Z) (r4:Z) (r5:Z) (r6:Z) (r7:Z), qs8_active_z(vl,0,r0,qs8_merge(x0,y0,z0)) && qs8_active_z(vl,1,r1,qs8_merge(x1,y1,z1)) && qs8_active_z(vl,2,r2,qs8_merge(x2,y2,z2)) && qs8_active_z(vl,3,r3,qs8_merge(x3,y3,z3)) && qs8_active_z(vl,4,r4,qs8_merge(x4,y4,z4)) && qs8_active_z(vl,5,r5,qs8_merge(x5,y5,z5)) && qs8_active_z(vl,6,r6,qs8_merge(x6,y6,z6)) && qs8_active_z(vl,7,r7,qs8_merge(x7,y7,z7)) && store(&(__return.s0),int,r0) * store(&(__return.s1),int,r1) * store(&(__return.s2),int,r2) * store(&(__return.s3),int,r3) * store(&(__return.s4),int,r4) * store(&(__return.s5),int,r5) * store(&(__return.s6),int,r6) * store(&(__return.s7),int,r7) */;
vbool16_t __riscv_vmsgt_vx_i32m2_b16(vint32m2_t a,int32_t s,size_t vl)
/*@ With (x0:Z) (x1:Z) (x2:Z) (x3:Z) (x4:Z) (x5:Z) (x6:Z) (x7:Z)
 Require 1<=vl && vl<=8 && store(&(a.s0),int,x0) * store(&(a.s1),int,x1) * store(&(a.s2),int,x2) * store(&(a.s3),int,x3) * store(&(a.s4),int,x4) * store(&(a.s5),int,x5) * store(&(a.s6),int,x6) * store(&(a.s7),int,x7)
 Ensure exists (r0:Z) (r1:Z) (r2:Z) (r3:Z) (r4:Z) (r5:Z) (r6:Z) (r7:Z), qs8_active_z(vl,0,r0,qs8_gt(x0,s)) && qs8_active_z(vl,1,r1,qs8_gt(x1,s)) && qs8_active_z(vl,2,r2,qs8_gt(x2,s)) && qs8_active_z(vl,3,r3,qs8_gt(x3,s)) && qs8_active_z(vl,4,r4,qs8_gt(x4,s)) && qs8_active_z(vl,5,r5,qs8_gt(x5,s)) && qs8_active_z(vl,6,r6,qs8_gt(x6,s)) && qs8_active_z(vl,7,r7,qs8_gt(x7,s)) && store(&(__return.s0),int,r0) * store(&(__return.s1),int,r1) * store(&(__return.s2),int,r2) * store(&(__return.s3),int,r3) * store(&(__return.s4),int,r4) * store(&(__return.s5),int,r5) * store(&(__return.s6),int,r6) * store(&(__return.s7),int,r7) */;
vbool16_t __riscv_vmseq_vx_i32m2_b16(vint32m2_t a,int32_t s,size_t vl)
/*@ With (x0:Z) (x1:Z) (x2:Z) (x3:Z) (x4:Z) (x5:Z) (x6:Z) (x7:Z)
 Require 1<=vl && vl<=8 && store(&(a.s0),int,x0) * store(&(a.s1),int,x1) * store(&(a.s2),int,x2) * store(&(a.s3),int,x3) * store(&(a.s4),int,x4) * store(&(a.s5),int,x5) * store(&(a.s6),int,x6) * store(&(a.s7),int,x7)
 Ensure exists (r0:Z) (r1:Z) (r2:Z) (r3:Z) (r4:Z) (r5:Z) (r6:Z) (r7:Z), qs8_active_z(vl,0,r0,qs8_eq(x0,s)) && qs8_active_z(vl,1,r1,qs8_eq(x1,s)) && qs8_active_z(vl,2,r2,qs8_eq(x2,s)) && qs8_active_z(vl,3,r3,qs8_eq(x3,s)) && qs8_active_z(vl,4,r4,qs8_eq(x4,s)) && qs8_active_z(vl,5,r5,qs8_eq(x5,s)) && qs8_active_z(vl,6,r6,qs8_eq(x6,s)) && qs8_active_z(vl,7,r7,qs8_eq(x7,s)) && store(&(__return.s0),int,r0) * store(&(__return.s1),int,r1) * store(&(__return.s2),int,r2) * store(&(__return.s3),int,r3) * store(&(__return.s4),int,r4) * store(&(__return.s5),int,r5) * store(&(__return.s6),int,r6) * store(&(__return.s7),int,r7) */;
vbool16_t __riscv_vmand_mm_b16(vbool16_t a,vbool16_t b,size_t vl)
/*@ With (x0:Z) (x1:Z) (x2:Z) (x3:Z) (x4:Z) (x5:Z) (x6:Z) (x7:Z) (y0:Z) (y1:Z) (y2:Z) (y3:Z) (y4:Z) (y5:Z) (y6:Z) (y7:Z)
 Require 1<=vl && vl<=8 && store(&(a.s0),int,x0) * store(&(a.s1),int,x1) * store(&(a.s2),int,x2) * store(&(a.s3),int,x3) * store(&(a.s4),int,x4) * store(&(a.s5),int,x5) * store(&(a.s6),int,x6) * store(&(a.s7),int,x7) * store(&(b.s0),int,y0) * store(&(b.s1),int,y1) * store(&(b.s2),int,y2) * store(&(b.s3),int,y3) * store(&(b.s4),int,y4) * store(&(b.s5),int,y5) * store(&(b.s6),int,y6) * store(&(b.s7),int,y7)
 Ensure exists (r0:Z) (r1:Z) (r2:Z) (r3:Z) (r4:Z) (r5:Z) (r6:Z) (r7:Z), qs8_active_z(vl,0,r0,qs8_mask_and(x0,y0)) && qs8_active_z(vl,1,r1,qs8_mask_and(x1,y1)) && qs8_active_z(vl,2,r2,qs8_mask_and(x2,y2)) && qs8_active_z(vl,3,r3,qs8_mask_and(x3,y3)) && qs8_active_z(vl,4,r4,qs8_mask_and(x4,y4)) && qs8_active_z(vl,5,r5,qs8_mask_and(x5,y5)) && qs8_active_z(vl,6,r6,qs8_mask_and(x6,y6)) && qs8_active_z(vl,7,r7,qs8_mask_and(x7,y7)) && store(&(__return.s0),int,r0) * store(&(__return.s1),int,r1) * store(&(__return.s2),int,r2) * store(&(__return.s3),int,r3) * store(&(__return.s4),int,r4) * store(&(__return.s5),int,r5) * store(&(__return.s6),int,r6) * store(&(__return.s7),int,r7) */;
vfloat32m2_t __riscv_vfmv_v_f_f32m2(float s,size_t vl)
/*@ Require 1<=vl && vl<=8 && emp
 Ensure exists (r0:fp32) (r1:fp32) (r2:fp32) (r3:fp32) (r4:fp32) (r5:fp32) (r6:fp32) (r7:fp32), qs8_active_f(vl,0,r0,s) && qs8_active_f(vl,1,r1,s) && qs8_active_f(vl,2,r2,s) && qs8_active_f(vl,3,r3,s) && qs8_active_f(vl,4,r4,s) && qs8_active_f(vl,5,r5,s) && qs8_active_f(vl,6,r6,s) && qs8_active_f(vl,7,r7,s) && store(&(__return.s0),float,r0) * store(&(__return.s1),float,r1) * store(&(__return.s2),float,r2) * store(&(__return.s3),float,r3) * store(&(__return.s4),float,r4) * store(&(__return.s5),float,r5) * store(&(__return.s6),float,r6) * store(&(__return.s7),float,r7) */;
vint16m1_t __riscv_vnclip_wx_i16m1(vint32m2_t a,unsigned int shift,unsigned int vxrm,size_t vl)
/*@ With (x0:Z) (x1:Z) (x2:Z) (x3:Z) (x4:Z) (x5:Z) (x6:Z) (x7:Z)
 Require 1<=vl && vl<=8 && shift==0 && vxrm==2 && store(&(a.s0),int,x0) * store(&(a.s1),int,x1) * store(&(a.s2),int,x2) * store(&(a.s3),int,x3) * store(&(a.s4),int,x4) * store(&(a.s5),int,x5) * store(&(a.s6),int,x6) * store(&(a.s7),int,x7)
 Ensure exists (r0:Z) (r1:Z) (r2:Z) (r3:Z) (r4:Z) (r5:Z) (r6:Z) (r7:Z), qs8_active_z(vl,0,r0,qs8_narrow16(x0)) && qs8_active_z(vl,1,r1,qs8_narrow16(x1)) && qs8_active_z(vl,2,r2,qs8_narrow16(x2)) && qs8_active_z(vl,3,r3,qs8_narrow16(x3)) && qs8_active_z(vl,4,r4,qs8_narrow16(x4)) && qs8_active_z(vl,5,r5,qs8_narrow16(x5)) && qs8_active_z(vl,6,r6,qs8_narrow16(x6)) && qs8_active_z(vl,7,r7,qs8_narrow16(x7)) && store(&(__return.s0),short,r0) * store(&(__return.s1),short,r1) * store(&(__return.s2),short,r2) * store(&(__return.s3),short,r3) * store(&(__return.s4),short,r4) * store(&(__return.s5),short,r5) * store(&(__return.s6),short,r6) * store(&(__return.s7),short,r7) */;
vint8mf2_t __riscv_vnclip_wx_i8mf2(vint16m1_t a,unsigned int shift,unsigned int vxrm,size_t vl)
/*@ With (x0:Z) (x1:Z) (x2:Z) (x3:Z) (x4:Z) (x5:Z) (x6:Z) (x7:Z)
 Require 1<=vl && vl<=8 && shift==0 && vxrm==2 && store(&(a.s0),short,x0) * store(&(a.s1),short,x1) * store(&(a.s2),short,x2) * store(&(a.s3),short,x3) * store(&(a.s4),short,x4) * store(&(a.s5),short,x5) * store(&(a.s6),short,x6) * store(&(a.s7),short,x7)
 Ensure exists (r0:Z) (r1:Z) (r2:Z) (r3:Z) (r4:Z) (r5:Z) (r6:Z) (r7:Z), qs8_active_z(vl,0,r0,qs8_narrow8(x0)) && qs8_active_z(vl,1,r1,qs8_narrow8(x1)) && qs8_active_z(vl,2,r2,qs8_narrow8(x2)) && qs8_active_z(vl,3,r3,qs8_narrow8(x3)) && qs8_active_z(vl,4,r4,qs8_narrow8(x4)) && qs8_active_z(vl,5,r5,qs8_narrow8(x5)) && qs8_active_z(vl,6,r6,qs8_narrow8(x6)) && qs8_active_z(vl,7,r7,qs8_narrow8(x7)) && store(&(__return.s0),char,r0) * store(&(__return.s1),char,r1) * store(&(__return.s2),char,r2) * store(&(__return.s3),char,r3) * store(&(__return.s4),char,r4) * store(&(__return.s5),char,r5) * store(&(__return.s6),char,r6) * store(&(__return.s7),char,r7) */;
vint8mf2_t __riscv_vmax_vx_i8mf2(vint8mf2_t a,int8_t s,size_t vl)
/*@ With (x0:Z) (x1:Z) (x2:Z) (x3:Z) (x4:Z) (x5:Z) (x6:Z) (x7:Z)
 Require 1<=vl && vl<=8 && store(&(a.s0),char,x0) * store(&(a.s1),char,x1) * store(&(a.s2),char,x2) * store(&(a.s3),char,x3) * store(&(a.s4),char,x4) * store(&(a.s5),char,x5) * store(&(a.s6),char,x6) * store(&(a.s7),char,x7)
 Ensure exists (r0:Z) (r1:Z) (r2:Z) (r3:Z) (r4:Z) (r5:Z) (r6:Z) (r7:Z), qs8_active_z(vl,0,r0,qs8_max(x0,s)) && qs8_active_z(vl,1,r1,qs8_max(x1,s)) && qs8_active_z(vl,2,r2,qs8_max(x2,s)) && qs8_active_z(vl,3,r3,qs8_max(x3,s)) && qs8_active_z(vl,4,r4,qs8_max(x4,s)) && qs8_active_z(vl,5,r5,qs8_max(x5,s)) && qs8_active_z(vl,6,r6,qs8_max(x6,s)) && qs8_active_z(vl,7,r7,qs8_max(x7,s)) && store(&(__return.s0),char,r0) * store(&(__return.s1),char,r1) * store(&(__return.s2),char,r2) * store(&(__return.s3),char,r3) * store(&(__return.s4),char,r4) * store(&(__return.s5),char,r5) * store(&(__return.s6),char,r6) * store(&(__return.s7),char,r7) */;
vint8mf2_t __riscv_vmin_vx_i8mf2(vint8mf2_t a,int8_t s,size_t vl)
/*@ With (x0:Z) (x1:Z) (x2:Z) (x3:Z) (x4:Z) (x5:Z) (x6:Z) (x7:Z)
 Require 1<=vl && vl<=8 && store(&(a.s0),char,x0) * store(&(a.s1),char,x1) * store(&(a.s2),char,x2) * store(&(a.s3),char,x3) * store(&(a.s4),char,x4) * store(&(a.s5),char,x5) * store(&(a.s6),char,x6) * store(&(a.s7),char,x7)
 Ensure exists (r0:Z) (r1:Z) (r2:Z) (r3:Z) (r4:Z) (r5:Z) (r6:Z) (r7:Z), qs8_active_z(vl,0,r0,qs8_min(x0,s)) && qs8_active_z(vl,1,r1,qs8_min(x1,s)) && qs8_active_z(vl,2,r2,qs8_min(x2,s)) && qs8_active_z(vl,3,r3,qs8_min(x3,s)) && qs8_active_z(vl,4,r4,qs8_min(x4,s)) && qs8_active_z(vl,5,r5,qs8_min(x5,s)) && qs8_active_z(vl,6,r6,qs8_min(x6,s)) && qs8_active_z(vl,7,r7,qs8_min(x7,s)) && store(&(__return.s0),char,r0) * store(&(__return.s1),char,r1) * store(&(__return.s2),char,r2) * store(&(__return.s3),char,r3) * store(&(__return.s4),char,r4) * store(&(__return.s5),char,r5) * store(&(__return.s6),char,r6) * store(&(__return.s7),char,r7) */;
vint32m2_t __riscv_vreinterpret_v_f32m2_i32m2(vfloat32m2_t a)
/*@ With (x0:fp32) (x1:fp32) (x2:fp32) (x3:fp32) (x4:fp32) (x5:fp32) (x6:fp32) (x7:fp32)
 Require store(&(a.s0),float,x0) * store(&(a.s1),float,x1) * store(&(a.s2),float,x2) * store(&(a.s3),float,x3) * store(&(a.s4),float,x4) * store(&(a.s5),float,x5) * store(&(a.s6),float,x6) * store(&(a.s7),float,x7)
 Ensure store(&(__return.s0),int,qs8_reinterpret(x0)) * store(&(__return.s1),int,qs8_reinterpret(x1)) * store(&(__return.s2),int,qs8_reinterpret(x2)) * store(&(__return.s3),int,qs8_reinterpret(x3)) * store(&(__return.s4),int,qs8_reinterpret(x4)) * store(&(__return.s5),int,qs8_reinterpret(x5)) * store(&(__return.s6),int,qs8_reinterpret(x6)) * store(&(__return.s7),int,qs8_reinterpret(x7)) */;
vfloat32m2_t __riscv_vreinterpret_v_i32m2_f32m2(vint32m2_t a)
/*@ With (x0:Z) (x1:Z) (x2:Z) (x3:Z) (x4:Z) (x5:Z) (x6:Z) (x7:Z)
 Require store(&(a.s0),int,x0) * store(&(a.s1),int,x1) * store(&(a.s2),int,x2) * store(&(a.s3),int,x3) * store(&(a.s4),int,x4) * store(&(a.s5),int,x5) * store(&(a.s6),int,x6) * store(&(a.s7),int,x7)
 Ensure store(&(__return.s0),float,qs8_uninterpret(x0)) * store(&(__return.s1),float,qs8_uninterpret(x1)) * store(&(__return.s2),float,qs8_uninterpret(x2)) * store(&(__return.s3),float,qs8_uninterpret(x3)) * store(&(__return.s4),float,qs8_uninterpret(x4)) * store(&(__return.s5),float,qs8_uninterpret(x5)) * store(&(__return.s6),float,qs8_uninterpret(x6)) * store(&(__return.s7),float,qs8_uninterpret(x7)) */;
vint32m2_t __riscv_vle32_v_i32m2(const int32_t *p,size_t vl)
/*@ With (K:Z) (wb:Z) (tile:Z) (j:Z) (Ps:list panel_data)
 Require 1<=vl && vl<=8 && 0<K && qs8_matrix_wf(K,Ps) && 0<=tile && tile<Zlength(Ps) && 0<=j && j+vl<=8 && p==wb+tile*(64+8*K)+4*j && packed_matrix(K,wb,Ps)
 Ensure exists (r0:Z) (r1:Z) (r2:Z) (r3:Z) (r4:Z) (r5:Z) (r6:Z) (r7:Z), qs8_active_z(vl,0,r0,qs8_bias(tile,j+0,Ps)) && qs8_active_z(vl,1,r1,qs8_bias(tile,j+1,Ps)) && qs8_active_z(vl,2,r2,qs8_bias(tile,j+2,Ps)) && qs8_active_z(vl,3,r3,qs8_bias(tile,j+3,Ps)) && qs8_active_z(vl,4,r4,qs8_bias(tile,j+4,Ps)) && qs8_active_z(vl,5,r5,qs8_bias(tile,j+5,Ps)) && qs8_active_z(vl,6,r6,qs8_bias(tile,j+6,Ps)) && qs8_active_z(vl,7,r7,qs8_bias(tile,j+7,Ps)) && packed_matrix(K,wb,Ps) * store(&(__return.s0),int,r0) * store(&(__return.s1),int,r1) * store(&(__return.s2),int,r2) * store(&(__return.s3),int,r3) * store(&(__return.s4),int,r4) * store(&(__return.s5),int,r5) * store(&(__return.s6),int,r6) * store(&(__return.s7),int,r7) */;
vfloat32m2_t __riscv_vle32_v_f32m2(const float *p,size_t vl)
/*@ With (K:Z) (wb:Z) (tile:Z) (j:Z) (Ps:list panel_data)
 Require 1<=vl && vl<=8 && 0<K && qs8_matrix_wf(K,Ps) && 0<=tile && tile<Zlength(Ps) && 0<=j && j+vl<=8 && p==wb+tile*(64+8*K)+32+8*K+4*j && packed_matrix(K,wb,Ps)
 Ensure exists (r0:fp32) (r1:fp32) (r2:fp32) (r3:fp32) (r4:fp32) (r5:fp32) (r6:fp32) (r7:fp32), qs8_active_f(vl,0,r0,qs8_scale(tile,j+0,Ps)) && qs8_active_f(vl,1,r1,qs8_scale(tile,j+1,Ps)) && qs8_active_f(vl,2,r2,qs8_scale(tile,j+2,Ps)) && qs8_active_f(vl,3,r3,qs8_scale(tile,j+3,Ps)) && qs8_active_f(vl,4,r4,qs8_scale(tile,j+4,Ps)) && qs8_active_f(vl,5,r5,qs8_scale(tile,j+5,Ps)) && qs8_active_f(vl,6,r6,qs8_scale(tile,j+6,Ps)) && qs8_active_f(vl,7,r7,qs8_scale(tile,j+7,Ps)) && packed_matrix(K,wb,Ps) * store(&(__return.s0),float,r0) * store(&(__return.s1),float,r1) * store(&(__return.s2),float,r2) * store(&(__return.s3),float,r3) * store(&(__return.s4),float,r4) * store(&(__return.s5),float,r5) * store(&(__return.s6),float,r6) * store(&(__return.s7),float,r7) */;
vint8mf2_t __riscv_vle8_v_i8mf2(const int8_t *p,size_t vl)
/*@ With (K:Z) (wb:Z) (tile:Z) (j:Z) (Ps:list panel_data)
 Require 1<=vl && vl<=8 && 0<K && qs8_matrix_wf(K,Ps) && 0<=tile && tile<Zlength(Ps) && 0<=j && j+vl<=8*K && p==wb+tile*(64+8*K)+32+j && packed_matrix(K,wb,Ps)
 Ensure exists (r0:Z) (r1:Z) (r2:Z) (r3:Z) (r4:Z) (r5:Z) (r6:Z) (r7:Z), qs8_active_z(vl,0,r0,qs8_zget(j+0,weights(panel_at(Ps,tile)))) && qs8_active_z(vl,1,r1,qs8_zget(j+1,weights(panel_at(Ps,tile)))) && qs8_active_z(vl,2,r2,qs8_zget(j+2,weights(panel_at(Ps,tile)))) && qs8_active_z(vl,3,r3,qs8_zget(j+3,weights(panel_at(Ps,tile)))) && qs8_active_z(vl,4,r4,qs8_zget(j+4,weights(panel_at(Ps,tile)))) && qs8_active_z(vl,5,r5,qs8_zget(j+5,weights(panel_at(Ps,tile)))) && qs8_active_z(vl,6,r6,qs8_zget(j+6,weights(panel_at(Ps,tile)))) && qs8_active_z(vl,7,r7,qs8_zget(j+7,weights(panel_at(Ps,tile)))) && packed_matrix(K,wb,Ps) * store(&(__return.s0),char,r0) * store(&(__return.s1),char,r1) * store(&(__return.s2),char,r2) * store(&(__return.s3),char,r3) * store(&(__return.s4),char,r4) * store(&(__return.s5),char,r5) * store(&(__return.s6),char,r6) * store(&(__return.s7),char,r7) */;
size_t __riscv_vsetvl_e32m2(size_t n)
/*@ Require 1<=n && n<=8 && emp Ensure __return==n && emp */;
vbool16_t qcp_qs8_self_nan(const vfloat32m2_t *a,const vfloat32m2_t *b,size_t vl)
/*@ With (x0:fp32) (x1:fp32) (x2:fp32) (x3:fp32) (x4:fp32) (x5:fp32) (x6:fp32) (x7:fp32)
 Require a==b && 1<=vl && vl<=8 && store(&(a->s0),float,x0) * store(&(a->s1),float,x1) * store(&(a->s2),float,x2) * store(&(a->s3),float,x3) * store(&(a->s4),float,x4) * store(&(a->s5),float,x5) * store(&(a->s6),float,x6) * store(&(a->s7),float,x7)
 Ensure exists (r0:Z) (r1:Z) (r2:Z) (r3:Z) (r4:Z) (r5:Z) (r6:Z) (r7:Z), qs8_active_z(vl,0,r0,qs8_nan(x0)) && qs8_active_z(vl,1,r1,qs8_nan(x1)) && qs8_active_z(vl,2,r2,qs8_nan(x2)) && qs8_active_z(vl,3,r3,qs8_nan(x3)) && qs8_active_z(vl,4,r4,qs8_nan(x4)) && qs8_active_z(vl,5,r5,qs8_nan(x5)) && qs8_active_z(vl,6,r6,qs8_nan(x6)) && qs8_active_z(vl,7,r7,qs8_nan(x7)) && store(&(a->s0),float,x0) * store(&(a->s1),float,x1) * store(&(a->s2),float,x2) * store(&(a->s3),float,x3) * store(&(a->s4),float,x4) * store(&(a->s5),float,x5) * store(&(a->s6),float,x6) * store(&(a->s7),float,x7) * store(&(__return.s0),int,r0) * store(&(__return.s1),int,r1) * store(&(__return.s2),int,r2) * store(&(__return.s3),int,r3) * store(&(__return.s4),int,r4) * store(&(__return.s5),int,r5) * store(&(__return.s6),int,r6) * store(&(__return.s7),int,r7) */;
void qcp_qs8_rvv_store(int8_t *p,const vint8mf2_t *a,size_t vl)
/*@ With (base:Z) (N:Z) (done:Z) (L:list Z) (x0:Z) (x1:Z) (x2:Z) (x3:Z) (x4:Z) (x5:Z) (x6:Z) (x7:Z)
 Require 1<=vl && vl<=8 && 0<=done && done+vl<=N && p==base+done && store(&(a->s0),char,x0) * store(&(a->s1),char,x1) * store(&(a->s2),char,x2) * store(&(a->s3),char,x3) * store(&(a->s4),char,x4) * store(&(a->s5),char,x5) * store(&(a->s6),char,x6) * store(&(a->s7),char,x7) * qs8_write_state(base,N,done,L)
 Ensure store(&(a->s0),char,x0) * store(&(a->s1),char,x1) * store(&(a->s2),char,x2) * store(&(a->s3),char,x3) * store(&(a->s4),char,x4) * store(&(a->s5),char,x5) * store(&(a->s6),char,x6) * store(&(a->s7),char,x7) * qs8_write_state(base,N,done+vl,qs8_append(L,qs8_take(vl,cons(x0,cons(x1,cons(x2,cons(x3,cons(x4,cons(x5,cons(x6,cons(x7,nil))))))))))) */;
void qcp_assert(int c)
/*@ Require c!=0 && emp Ensure emp */;
void test_rvv(
    size_t mr,
    size_t nc,
    size_t kc,
    const int8_t* restrict a,
    size_t a_stride,
    const void* restrict w,
    int8_t* restrict c,
    size_t cm_stride,
    size_t cn_stride,
    const struct xnn_qs8_qc8w_conv_minmax_params* restrict params)
/*@ With (A:list Z) (Ps:list panel_data) (magic:fp32) (offset:Z) (lo:Z) (hi:Z)
 Require mr==1 && 0<nc && 0<kc && domain_shape(mr,nc,kc,Ps) && data_capacity(nc,kc,a,w,c) && cn_stride==8 && a!=0 && w!=0 && c!=0 && params!=0 && CharArray::full(a,a_read_extent(kc),A) * packed_matrix(kc,w,Ps) * CharArray::undef_full(c,nc) * store(&(params->fp32_neon.magic_bias),float,magic) * store(&(params->fp32_neon.magic_bias_less_output_zero_point),int,offset) * store(&(params->fp32_neon.output_min),char,lo) * store(&(params->fp32_neon.output_max),char,hi)
 Ensure CharArray::full(a@pre,a_read_extent(kc@pre),A) * packed_matrix(kc@pre,w@pre,Ps) * qs8_output_ref(c@pre,nc@pre,kc@pre,A,Ps,magic,offset,lo,hi) * store(&(params->fp32_neon.magic_bias),float,magic) * store(&(params->fp32_neon.magic_bias_less_output_zero_point),int,offset) * store(&(params->fp32_neon.output_min),char,lo) * store(&(params->fp32_neon.output_max),char,hi) */
{
  qcp_assert(mr != 0);
  qcp_assert(mr <= 1);
  qcp_assert(nc != 0);
  qcp_assert(kc != 0);
/*@ emp which implies sizeof(int8_t)==1 && kc@pre%sizeof(int8_t)==0 && emp */
qcp_assert(kc % sizeof(int8_t) == 0);
  qcp_assert(a != ((void*)0));
  qcp_assert(w != ((void*)0));
  qcp_assert(c != ((void*)0));
  const int8_t* a0 = a;
  int8_t* c0 = c;
  do {
    // The weights are packed in fixed blocks of NR=8:
    //   [8 x i32 bias][kc x 8 x i8][8 x f32 scale]
    size_t vl = __riscv_vsetvl_e32m2(nc < 8 ? nc : 8);
    vint32m2_t vacc = __riscv_vle32_v_i32m2((const int32_t*) w, vl)
/*@ where K=kc@pre, wb=w@pre, tile=((nc@pre-nc)/8), Ps=Ps, j=0 */
;
    w = (const int32_t*) w + 8;
    size_t k = kc;
    do {
/*@ a0==pointer_offset(a@pre,(kc@pre-k),char) && 0<=(kc@pre-k) && (kc@pre-k)<a_read_extent(kc@pre) && CharArray::full(a@pre,a_read_extent(kc@pre),A) which implies a0==pointer_offset(a@pre,(kc@pre-k),char) && 0<=(kc@pre-k) && (kc@pre-k)<a_read_extent(kc@pre) && CharArray::missing_i(a@pre,(kc@pre-k),0,a_read_extent(kc@pre),A) * store(a0,char,A[(kc@pre-k)]) */
const int16_t va0 = (int16_t) *a0;
      a0 += 1;
      vint8mf2_t vb = __riscv_vle8_v_i8mf2((const int8_t*) w, vl)
/*@ where K=kc@pre, wb=w@pre, tile=((nc@pre-nc)/8), Ps=Ps, j=8*(kc@pre-k) */
;
      w = (const int8_t*) w + 8;
      vint16m1_t vxb = __riscv_vsext_vf2_i16m1(vb, vl)
/*@ where a=&vb */
;
      vacc = __riscv_vwmacc_vx_i32m2(vacc, va0, vxb, vl)
/*@ where a=&vacc, b=&vxb */
;
      k -= sizeof(int8_t);
    }
/*@ Inv Assert exists (r0:Z) (r1:Z) (r2:Z) (r3:Z) (r4:Z) (r5:Z) (r6:Z) (r7:Z), mr==mr@pre && kc==kc@pre && a==a@pre && c==c@pre && params==params@pre && a_stride==a_stride@pre && cm_stride==cm_stride@pre && cn_stride==8 && mr==1 && 0<kc@pre && 0<nc@pre && domain_shape(1,nc@pre,kc@pre,Ps) && data_capacity(nc@pre,kc@pre,a@pre,w@pre,c@pre) && qs8_matrix_wf(kc@pre,Ps) && sizeof(int8_t)==1 && sizeof(float)==4 && 0<=nc && nc<=nc@pre && 0<nc && (nc@pre-nc)%8==0 && 0<=((nc@pre-nc)/8) && ((nc@pre-nc)/8)<Zlength(Ps) && c0==pointer_offset(c@pre,(nc@pre-nc),char) && 1<=vl && vl<=8 && vl==qs8_min(nc,8) && 0<=k && k<=kc@pre && a0==pointer_offset(a@pre,(kc@pre-k),char) && w==pointer_offset(w@pre,((nc@pre-nc)/8)*(64+8*kc@pre)+32+8*(kc@pre-k),char) && qs8_active_z(vl,0,r0,qs8_acc((kc@pre-k),((nc@pre-nc)/8),0,A,Ps)) && qs8_active_z(vl,1,r1,qs8_acc((kc@pre-k),((nc@pre-nc)/8),1,A,Ps)) && qs8_active_z(vl,2,r2,qs8_acc((kc@pre-k),((nc@pre-nc)/8),2,A,Ps)) && qs8_active_z(vl,3,r3,qs8_acc((kc@pre-k),((nc@pre-nc)/8),3,A,Ps)) && qs8_active_z(vl,4,r4,qs8_acc((kc@pre-k),((nc@pre-nc)/8),4,A,Ps)) && qs8_active_z(vl,5,r5,qs8_acc((kc@pre-k),((nc@pre-nc)/8),5,A,Ps)) && qs8_active_z(vl,6,r6,qs8_acc((kc@pre-k),((nc@pre-nc)/8),6,A,Ps)) && qs8_active_z(vl,7,r7,qs8_acc((kc@pre-k),((nc@pre-nc)/8),7,A,Ps)) && CharArray::full(a@pre,a_read_extent(kc@pre),A) * packed_matrix(kc@pre,w@pre,Ps) * qs8_output_prefix(c@pre,nc@pre,(nc@pre-nc),kc@pre,A,Ps,magic,offset,lo,hi) * store(&(params->fp32_neon.magic_bias),float,magic) * store(&(params->fp32_neon.magic_bias_less_output_zero_point),int,offset) * store(&(params->fp32_neon.output_min),char,lo) * store(&(params->fp32_neon.output_max),char,hi) * store(&(vacc.s0),int,r0) * store(&(vacc.s1),int,r1) * store(&(vacc.s2),int,r2) * store(&(vacc.s3),int,r3) * store(&(vacc.s4),int,r4) * store(&(vacc.s5),int,r5) * store(&(vacc.s6),int,r6) * store(&(vacc.s7),int,r7) */
while (k != 0);
    vfloat32m2_t vfpacc = __riscv_vfcvt_f_x_v_f32m2(vacc, vl)
/*@ where a=&vacc */
;
    vfloat32m2_t vscale = __riscv_vle32_v_f32m2((const float*) w, vl)
/*@ where K=kc@pre, wb=w@pre, tile=((nc@pre-nc)/8), Ps=Ps, j=0 */
;
    w = (const float*) w + 8;
    vfpacc = __riscv_vfmul_vv_f32m2(vfpacc, vscale, vl)
/*@ where a=&vfpacc, b=&vscale */
;
    // Restore ARM DN=0 NaN bits before reinterpretation to an integer.
    // The integer conversion is finite; only scale can supply a NaN to mul.
    const vbool16_t scale_nan = qcp_qs8_self_nan(&(vscale),&(vscale),(vl));
    const vint32m2_t scale_bits = __riscv_vreinterpret_v_f32m2_i32m2(vscale)
/*@ where a=&vscale */
;
    const vint32m2_t scale_quiet = __riscv_vor_vx_i32m2(scale_bits, 0x00400000, vl)
/*@ where a=&scale_bits */
;
    vint32m2_t product_bits = __riscv_vreinterpret_v_f32m2_i32m2(vfpacc)
/*@ where a=&vfpacc */
;
    product_bits = __riscv_vmerge_vvm_i32m2(product_bits, scale_quiet, scale_nan, vl)
/*@ where a=&product_bits, b=&scale_quiet, m=&scale_nan */
;
    vfpacc = __riscv_vreinterpret_v_i32m2_f32m2(product_bits)
/*@ where a=&product_bits */
;
    const vbool16_t product_nan = qcp_qs8_self_nan(&(vfpacc),&(vfpacc),(vl));
    const vfloat32m2_t magic = __riscv_vfmv_v_f_f32m2(params->fp32_neon.magic_bias, vl);
    const vint32m2_t magic_bits = __riscv_vreinterpret_v_f32m2_i32m2(magic)
/*@ where a=&magic */
;
    const vint32m2_t magic_abs = __riscv_vand_vx_i32m2(magic_bits, 0x7fffffff, vl)
/*@ where a=&magic_bits */
;
    const vbool16_t magic_nan = __riscv_vmsgt_vx_i32m2_b16(magic_abs, 0x7f800000, vl)
/*@ where a=&magic_abs */
;
    const vint32m2_t magic_qbit = __riscv_vand_vx_i32m2(magic_bits, 0x00400000, vl)
/*@ where a=&magic_bits */
;
    const vbool16_t magic_qzero = __riscv_vmseq_vx_i32m2_b16(magic_qbit, 0, vl)
/*@ where a=&magic_qbit */
;
    const vbool16_t magic_snan = __riscv_vmand_mm_b16(magic_nan, magic_qzero, vl)
/*@ where a=&magic_nan, b=&magic_qzero */
;
    const vint32m2_t magic_quiet = __riscv_vor_vx_i32m2(magic_bits, 0x00400000, vl)
/*@ where a=&magic_bits */
;
    // Product NaN has priority over quiet magic; signaling magic has priority
    // over the already quiet product. Invalid finite/Inf arithmetic is canonical.
    vfpacc = __riscv_vfadd_vf_f32m2(vfpacc, params->fp32_neon.magic_bias, vl)
/*@ where a=&vfpacc */
;
    vacc = __riscv_vreinterpret_v_f32m2_i32m2(vfpacc)
/*@ where a=&vfpacc */
;
    vacc = __riscv_vmerge_vvm_i32m2(vacc, magic_quiet, magic_nan, vl)
/*@ where a=&vacc, b=&magic_quiet, m=&magic_nan */
;
    vacc = __riscv_vmerge_vvm_i32m2(vacc, product_bits, product_nan, vl)
/*@ where a=&vacc, b=&product_bits, m=&product_nan */
;
    vacc = __riscv_vmerge_vvm_i32m2(vacc, magic_quiet, magic_snan, vl)
/*@ where a=&vacc, b=&magic_quiet, m=&magic_snan */
;
    vacc = __riscv_vssub_vx_i32m2(vacc, params->fp32_neon.magic_bias_less_output_zero_point, vl)
/*@ where a=&vacc */
;
    vint16m1_t vout16 = __riscv_vnclip_wx_i16m1(vacc, 0, 2, vl)
/*@ where a=&vacc */
;
    vint8mf2_t vout = __riscv_vnclip_wx_i8mf2(vout16, 0, 2, vl)
/*@ where a=&vout16 */
;
    vout = __riscv_vmax_vx_i8mf2(vout, params->fp32_neon.output_min, vl)
/*@ where a=&vout */
;
    vout = __riscv_vmin_vx_i8mf2(vout, params->fp32_neon.output_max, vl)
/*@ where a=&vout */
;
    qcp_qs8_rvv_store((c0),&(vout),(vl))
/*@ where base=c@pre, N=nc@pre, done=(nc@pre-nc) */
;
    c0 = (int8_t*) ((uintptr_t) c0 + cn_stride);
    a0 = (const int8_t*) ((uintptr_t) a0 - kc);
    nc -= vl;
  }
/*@ Inv Assert exists (ap:Z) (wp:Z) (cp:Z), mr==mr@pre && kc==kc@pre && a==a@pre && c==c@pre && params==params@pre && a_stride==a_stride@pre && cm_stride==cm_stride@pre && cn_stride==8 && mr==1 && 0<kc@pre && 0<nc@pre && domain_shape(1,nc@pre,kc@pre,Ps) && data_capacity(nc@pre,kc@pre,a@pre,w@pre,c@pre) && qs8_matrix_wf(kc@pre,Ps) && sizeof(int8_t)==1 && sizeof(float)==4 && 0<=nc && nc<=nc@pre && a0==ap && w==wp && c0==cp && (nc==0 || (0<nc && (nc@pre-nc)%8==0 && 0<=((nc@pre-nc)/8) && ((nc@pre-nc)/8)<Zlength(Ps) && cp==pointer_offset(c@pre,(nc@pre-nc),char) && ap==a@pre && wp==pointer_offset(w@pre,((nc@pre-nc)/8)*(64+8*kc@pre),char))) && CharArray::full(a@pre,a_read_extent(kc@pre),A) * packed_matrix(kc@pre,w@pre,Ps) * qs8_output_prefix(c@pre,nc@pre,(nc@pre-nc),kc@pre,A,Ps,magic,offset,lo,hi) * store(&(params->fp32_neon.magic_bias),float,magic) * store(&(params->fp32_neon.magic_bias_less_output_zero_point),int,offset) * store(&(params->fp32_neon.output_min),char,lo) * store(&(params->fp32_neon.output_max),char,hi) */
while (nc != 0);
}
