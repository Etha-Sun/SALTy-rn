# 展示文件包

本包包含此前推荐的 8 个文件，适合阅读和演示，不包含独立编译所需的全部证明库和依赖。

- memcpy.s：上游 Arm 逐字节复制函数的完整汇编。
- memcpy.v：上游该函数的规格、循环不变量与证明。
- a800001c6.isla：我们提取的 vsetvli 原始符号 trace。
- a800001c6.v：同一 trace 转成的 Coq 数据。
- VsetProof.v：vsetvli 的规格与已通过检查的证明。
- InstructionProof.v：vredsum.vs 的已通过检查的证明（指定配置、64 lanes、任意数据）。
- ReductionSpec.v：完整 reduction 的目标契约及数学引理；完整机器码满足契约尚未证明。
- PRESENTATION.zh-CN.md：展示提纲。原文中的相对链接按工作区目录组织，部分目标未包含在本精简包中。

注意：当前成果不包含完整任意长度 reduction、NEON↔RVV 等价性或全 VLEN 证明。memcpy 是上游案例，不能算作我们的新增成果。

上游来源：https://github.com/rems-project/islaris
